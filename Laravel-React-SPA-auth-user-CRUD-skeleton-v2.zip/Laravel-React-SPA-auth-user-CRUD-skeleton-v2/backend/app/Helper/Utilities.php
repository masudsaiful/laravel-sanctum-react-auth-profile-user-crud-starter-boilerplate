<?php

namespace App\Helper;

class Utilities
{
    /**
     * Check if the first three characters of one string match another string.
     *
     * @param string $matchingWhat The string to match from.
     * @param string $matchingWith The string to match against.
     * @return bool True if the first three characters match, case-insensitively.
     */
    public static function matchString($matchingWhat, $matchingWith)
    {
        // Case-insensitive check if $matchingWith starts with the first
        // three characters of $matchingWhat.
        return stripos($matchingWith, substr($matchingWhat, 0, 3)) === 0;
    }
}

// OLD
// namespace App\Helper;

// class Utilities
// {
//     public static function matchString($matchingWhat, $matchingWith)
//     {
//         // If first three characters of $matchingWhat match $matchingWith
//         // (case-insensitive)
//         return stripos($matchingWith, substr($matchingWhat, 0, 3)) === 0;
//     }
// }
