<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Exceptions\CustomException;

use App\Models\User\User;
use App\Http\Requests\Auth\AuthRegisterRequest;

class AuthController extends Controller
{
    /**
     * Register a new user and return the created user's data.
     *
     * @param AuthRegisterRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function register(AuthRegisterRequest $request)
    {
        // Create a new user with provided validated data
        $user = User::create([
            'name' => $request->name,
            'username' => $request->username,
            'email' => $request->email,
            'password' => bcrypt($request->password),
        ]);
 
        // Set created_by field to the user's own ID
        // Created by field should be nullable though it is later updated
        // Suitable for external user registration
        $user->created_by = $user->id; 
        $user->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Require login to access',
            'user' => $user,
        ], 201);
    }

    /**
     * Authenticate user based on provided credentials and return an access token.
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @throws CustomException
     */
    public function login(Request $request)
    {
        $request->validate([
            'email_or_username' => 'required|string',
            'password' => 'required|string',
        ]);

        // Determine if login credential is email or username
        $login_type = filter_var($request->input('email_or_username'), FILTER_VALIDATE_EMAIL) ? 'email' : 'username';
        $credentials = [$login_type => $request->input('email_or_username'), 'password' => $request->input('password')];

        // Attempt to authenticate user
        if (!Auth::attempt($credentials)) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Invalid login details, credentials mismatched.',
            ], 401);
        }
        
        $user = User::where($login_type, $request->input('email_or_username'))->firstOrFail();
        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'status' => 'success',
            'message' => 'Access authorized',
            'access_token' => $token, 
            'token_type' => 'Bearer',
            'user' => $user
        ], 200);
    }

    /**
     * Log the user out by deleting the current access token.
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        // or
        // Auth::user()->currentAccessToken()->delete();

        // If auth:sanctum middleware no need to send response
        // return response()->json([
        //     'status' => 'success',
        //     'message' => 'Logged out successfully'
        // ]);
    }
}

// OLD
// namespace App\Http\Controllers\Auth;

// use Illuminate\Http\Request;
// use App\Http\Controllers\Controller;
// use Illuminate\Support\Facades\Auth;
// use App\Exceptions\CustomException;

// use App\Models\User\User;
// use App\Http\Requests\Auth\AuthRegisterRequest;

// class AuthController extends Controller
// {
//     public function register(AuthRegisterRequest $request)
//     {
//         // $request->validate([
//         //     'name' => 'required|string|max:255',
//         //     'username' => 'required|string|max:255|unique:users',
//         //     'email' => 'required|string|email|max:255|unique:users',
//         //     'password' => 'required|string|min:8|confirmed',
//         // ]);

//         $user = User::create([
//             'name' => $request->name,
//             'username' => $request->username,
//             'email' => $request->email,
//             'password' => bcrypt($request->password),
//         ]);
 
//         // Set 'created_by' field type to nullable for later update when external registration
//         $user->created_by = $user->id; 
//         $user->save();

//         return response()->json([
//             'status' => 'success',
//             'message' => 'Require login to access',
//             'user' => $user,
//         ], 201);
//     }

//     public function login(Request $request)
//     {
//         // $request->validate([
//         //     'email' => 'required|string|email',
//         //     'password' => 'required|string',
//         // ]);

//         // if (!Auth::attempt($request->only('email', 'password'))) {
//         //     return response()->json(['message' => 'Invalid login details'], 401);
//         // }

//         // $user = User::where('email', $request->email)->firstOrFail();
//         // $token = $user->createToken('auth_token')->plainTextToken;

//         $request->validate([
//             'email_or_username' => 'required|string',
//             'password' => 'required|string',
//         ]);

//         $login_type = filter_var($request->input('email_or_username'), FILTER_VALIDATE_EMAIL) ? 'email' : 'username';
//         $credentials = [$login_type => $request->input('email_or_username'), 'password' => $request->input('password')];

//         if (!Auth::attempt($credentials)) {
//             // return response()->json([
//             //     'status' => 'failed',
//             //     'message' => 'Invalid login details'
//             // ], 401);
//             throw new CustomException([
//                 'status' => 'failed',
//                 'message' => 'Invalid login details, credentials mismatched.',
//             ], 401);
//         }
        
//         $user = User::where($login_type, $request->input('email_or_username'))->firstOrFail();
//         $token = $user->createToken('auth_token')->plainTextToken;

//         return response()->json([
//             'status' => 'success',
//             'message' => 'Access authorized',
//             'access_token' => $token, 
//             'token_type' => 'Bearer',
//             'user' => $user
//         ], 200);
//     }

//     public function logout(Request $request)
//     {
//         $request->user()->currentAccessToken()->delete();

//         return response()->json([
//             'status' => 'success',
//             'message' => 'Logged out successfully'
//         ]);
//     }
// }
