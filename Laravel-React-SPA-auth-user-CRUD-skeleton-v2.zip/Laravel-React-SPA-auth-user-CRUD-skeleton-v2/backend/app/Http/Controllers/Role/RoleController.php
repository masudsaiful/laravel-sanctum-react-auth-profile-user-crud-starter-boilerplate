<?php

namespace App\Http\Controllers\Role;

use App\Exceptions\CustomException;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;

use App\Helper\Utilities;
use App\Models\Role\Role;
use App\Http\Requests\Role\RoleRequest;

class RoleController extends Controller
{
    /**
     * Display a paginated listing of resource with optional filtering and sorting.
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(Request $request)
    {
        try{
            $page = $request->input('page', 1);
            $pageSize = $request->input('pageSize', 20);

            $query = Role::query();
            $allQuery = Role::roleStatusScope(1);

            // db:seed artisan at the beginning will create superadmin user/role 1
            // Exclude SuperAdmin for non-superadmin users
            if (Auth::id() != 1) {
                $query->where('id', '!=', 1);  
                $allQuery->where('id', '!=', 1);
            }
                
            // Sorting
            if ($request->has('sortModel')) {
                $this->applySorting($query, $request->input('sortModel'));
            }

            // Filtering
            if ($request->has('filterModel')) {
                $this->applyFiltering($query, $request->input('filterModel'));
            }

            $roles = $query->paginate($pageSize, ['*'], 'page', $page);
            $allRoles = $allQuery->get();

            // $roles = $query->paginate($request->get('pageSize', 20));
            // Cache::put($cacheKey, $response, 60); // Cache for 60 minutes

            return response()->json([
                'status' => 'success',
                'message' => 'Roles loaded successfully',
                'role' => $roles->items(),
                'allRoles' => $allRoles,
                'total' => $roles->total(),
                'current_page' => $roles->currentPage(),
                'last_page' => $roles->lastPage(),
            ], 200); // 200, successfully retrieved

        }  catch (\Throwable $e) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Roles couldn\'t be loaded, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param RoleRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(RoleRequest $request)
    {
        DB::beginTransaction();
        try {
            $role = new Role();

            // Handle status field
            // $status = $request->input('status');
            // if (is_array($status)) {
            //     $status = $status[0]; // or any appropriate serialization method
            // }

            // Collect and merge resource fillable data with creator information.
            $roleFillableData = collect($request->only($role->getFillable()));
            $createdByFillableData = collect(['created_by' => Auth::id()])->only($role->getFillable());
            $roleData = $createdByFillableData->merge($roleFillableData)->all();
            $role->fill($roleData)->save();
            $role->save();
            // $roleFillableData = $request->only($role->getFillable());
            // $role->fill($roleFillableData)->save();
            // $role->save();

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'Role created successfully',
                'role' => $role,
            ], 201); // 201, successfully created

        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Role couldn\'t be created, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }

    /**
     * Display the specified resource.
     *
     * @param string $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show(string $id)
    {
        try {
            $role = Role::whereId($id)->firstOrFail();
            return response()->json([
                'status' => 'success',
                'message' => 'Role loaded successfully',
                'role' => $role,
            ], 200); // 200, successfully retrieved

        } catch (\Throwable $e) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Role couldn\'t be loaded, '. $e->getMessage(),
            ], 404); // 404, resource couldn't be found
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param RoleRequest $request
     * @param string $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(RoleRequest $request, string $id)
    {
        DB::beginTransaction();
        try {
            $role = Role::whereId($id)->firstOrFail();

            // Handle array status field
            // $status = $request->input('status');
            // if (is_array($status)) {
            //     $status = $status[0]; // or any appropriate serialization method
            // }

            // Merge user fillable data with updater information.
            $roleFillableData = collect($request->only($role->getFillable()));
            $createdByFillableData = collect(['created_by' => Auth::id()])->only($role->getFillable());
            $roleData = $createdByFillableData->merge($roleFillableData)->all();
            $role->fill($roleData);
            $role->save();
            // $roleFillableData = $request->only($role->getFillable());
            // $role->fill($roleFillableData);
            // $role->save();

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'Role updated successfully',
                'role' => $role,
            ], 200); // 200, successfully retrieved and updated

        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Role couldn\'t be updated, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }

    /**
     * Remove the specified resource from storage.
     * Simple and non nested relationships deleting in here.
     * Complex or nested relationships deleting in model's boot method.
     *
     * @param string $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(string $id)
    {
        DB::beginTransaction();
        try {
            $role = Role::findOrFail($id);
            $userIds = $role->users->pluck('id');
            $role->users()->detach($userIds->toArray()); 
            // // or
            // $role->users()->detach($userIds->all());
            // // or
            // $role->users()->detach();
            $role->delete();
    
            DB::commit();
    
            return response()->json([
                'status' => 'success',
                'message' => 'Role deleted successfully',
            ], 200); // successfully deleted, returned contents (status, message etc.)
    
        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Role couldn\'t be deleted, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }

    /**
     * Apply sorting to the query based on the sort model.
     * 
     * @param collection $query
     * @param array <$sortModel>
     */
    private function applySorting($query, $sortModel)
    {
        $sortModel = json_decode($sortModel, true);
        // Check if sortModel is a non-empty array
        if (is_array($sortModel) && count($sortModel) > 0) {
            foreach ($sortModel as $sort) {
                if (isset($sort['field']) && isset($sort['sort'])) {
                    $query->orderBy($sort['field'], $sort['sort']);
                }
            }
        } else {
            // Default sorting: latest to oldest
            $query->orderBy('created_at', 'desc');
        }
    }

    /**
     * Apply filtering to the query based on the filter model.
     * 
     * @param collection $query
     * @param array <$filterModel>
     */
    private function applyFiltering($query, $filterModel)
    {
        $filterModel = json_decode($filterModel, true);
        if (isset($filterModel['items'])) {
            foreach ($filterModel['items'] as $filter) {
                // Check if keys exist
                if (isset($filter['field']) && isset($filter['value'])) {
                    if ($filter['field'] === 'status') {
                        if ($filter['value'] !== '') {
                            if(Utilities::matchString($filter['value'], 'Disable')) {
                                $query->whereJsonContains($filter['field'], 2);
                            } elseif(Utilities::matchString($filter['value'], 'Enable')) {
                                $query->whereJsonContains($filter['field'], 1);
                            }
                        }
                    } else {
                        $query->where($filter['field'], 'like', '%' . $filter['value'] . '%');
                    }
                }
            }
        }
    }
}

// OLD
// namespace App\Http\Controllers\Role;

// use App\Exceptions\CustomException;
// use App\Http\Controllers\Controller;
// use Illuminate\Support\Facades\Auth;
// use Illuminate\Validation\Rule;
// use Illuminate\Http\Request;
// use Illuminate\Support\Facades\DB;
// use Illuminate\Support\Facades\Cache;

// use App\Helper\Utilities;
// use App\Models\Role\Role;
// use App\Http\Requests\Role\RoleRequest;

// class RoleController extends Controller
// {
//     /**
//      * Display a listing of the resource.
//      */
//     public function index(Request $request)
//     {
//         try{
//             $page = $request->input('page', 1);
//             $pageSize = $request->input('pageSize', 20);

//             // $cacheKey = "roles_page_{$page}_pageSize_{$pageSize}";

//             // if (Cache::has($cacheKey)) {
//             //     return Cache::get($cacheKey);
//             // }

//             $query = Role::query();

//             // db:seed artisan at the beginning will create superadmin user/role 1
//             // All roles except superadmin 
//             if (Auth::id() != 1) {
//                 $query->where('id', '!=', 1);  
//             }
                
//             if ($request->has('sortModel')) {
//                 $sortModel = json_decode($request->sortModel, true);
                
//                 // Check if sortModel is a non-empty array
//                 if (is_array($sortModel) && count($sortModel) > 0) {
//                     foreach ($sortModel as $sort) {
//                         if (isset($sort['field']) && isset($sort['sort'])) {
//                             $query->orderBy($sort['field'], $sort['sort']);
//                         }
//                     }
//                 }else {
//                     // Default sorting: latest to oldest
//                     $query->orderBy('created_at', 'desc');
//                 }
//             }

//             // Filtering
//             if ($request->has('filterModel')) {
//                 $filterModel = json_decode($request->filterModel, true);
//                 if (isset($filterModel['items'])) {
//                     foreach ($filterModel['items'] as $filter) {
//                         // Check if keys exist
//                         if (isset($filter['field']) && isset($filter['value'])) {  
//                             if($filter['field'] === 'status') {
//                                 if ($filter['value'] !== '') {
//                                     if(Utilities::matchString($filter['value'], 'Disable')) {
//                                         $query->whereJsonContains($filter['field'], 2);
//                                     } elseif(Utilities::matchString($filter['value'], 'Enable')) {
//                                         $query->whereJsonContains($filter['field'], 1);
//                                     }
//                                 }
//                             } else {
//                                 $query->where($filter['field'], 'like', '%' . $filter['value'] . '%');
//                             }
//                         }
//                     }
//                 }
//             }

//             $roles = $query->paginate($pageSize, ['*'], 'page', $page);
//             // $roles = $query->paginate($request->get('pageSize', 20));

//             // Cache::put($cacheKey, $response, 60); // Cache for 60 minutes

//             return response()->json([
//                 'status' => 'success',
//                 'message' => 'Role(s) has been loaded',
//                 'role' => $roles->items(),
//                 'total' => $roles->total(),
//                 'current_page' => $roles->currentPage(),
//                 'last_page' => $roles->lastPage(),
//             ], 200);

//         }  catch (\Throwable $e) {
//             throw new CustomException([
//                 'status' => 'failed',
//                 'message' => 'Role can\'t be loaded, '. $e->getMessage(),
//             ], 422);
//         }
//     }

//     /**
//      * Store a newly created resource in storage.
//      */
//     public function store(RoleRequest $request)
//     {
//         // $request->validate([
//         //     'name' => 'required|string|max:255',
//         //     'rolename' => 'required|string|max:255|unique:roles',
//         //     'email' => 'required|string|email|max:255|unique:roles',
//         //     'password' => 'required|string|min:8|confirmed',
//         // ]);

//         DB::beginTransaction();
//         try {
//             //Insert data into roles table
//             $role = new Role();

//             // Handle status field
//             // $status = $request->input('status');
//             // if (is_array($status)) {
//             //     $status = $status[0]; // or any appropriate serialization method
//             // }
            
//             /*
//             * Status field is cast at role model
//             */

//             $roleFillableData = collect($request->only($role->getFillable()));
//             $createdByFillableData = collect(['created_by' => Auth::id()])->only($role->getFillable());
//             $roleData = $createdByFillableData->merge($roleFillableData)->all();
//             $role->fill($roleData)->save();
//             $role->save();
//             // $roleFillableData = $request->only($role->getFillable());
//             // $role->fill($roleFillableData)->save();
//             // $role->save();

//             DB::commit();

//             return response()->json([
//                 'status' => 'success',
//                 'message' => 'Role has been created',
//                 'role' => $role,
//             ], 201);

//         } catch (\Throwable $e) {
//             DB::rollback();
//             throw new CustomException([
//                 'status' => 'failed',
//                 'message' => 'Role can\'t be created, '. $e->getMessage(),
//             ], 422);
//         }
//     }

//     /**
//      * Display the specified resource.
//      */
//     public function show(string $id)
//     {
//         try {
//             $role = Role::whereId($id)->firstOrFail();
//             return response()->json([
//                 'status' => 'success',
//                 'message' => 'Role has been loaded',
//                 'role' => $role,
//             ], 201);

//         } catch (\Throwable $e) {
//             throw new CustomException([
//                 'status' => 'failed',
//                 'message' => 'Role can\'t be loaded, '. $e->getMessage(),
//             ], 422);
//         }
//     }

//     /**
//      * Update the specified resource in storage.
//      */
//     public function update(RoleRequest $request, string $id)
//     {
//         // $request->validate([
//         //     'name' => 'required|string|max:255',
//         //     'rolename' => 'required|string|max:255|unique:roles',
//         //     'email' => ['required', 'string', 'email', 'max:255', 'unique:roles', Rule::unique('roles','email')->ignore($request->input('id'),'id')],
//         //     'password' => 'string|min:8|confirmed',
//         // ]);

//         DB::beginTransaction();
//         try {
//             $role = Role::whereId($id)->firstOrFail();

//             // Handle array status field
//             // $status = $request->input('status');
//             // if (is_array($status)) {
//             //     $status = $status[0]; // or any appropriate serialization method
//             // }

//             $roleFillableData = collect($request->only($role->getFillable()));
//             $createdByFillableData = collect(['created_by' => Auth::id()])->only($role->getFillable());
//             $roleData = $createdByFillableData->merge($roleFillableData)->all();
//             $role->fill($roleData);
//             $role->save();
//             // $roleFillableData = $request->only($role->getFillable());
//             // $role->fill($roleFillableData);
//             // $role->save();

//             DB::commit();

//             return response()->json([
//                 'status' => 'success',
//                 'message' => 'Role has been updated',
//                 'role' => $role,
//             ], 201);

//         } catch (\Throwable $e) {
//             DB::rollback();
//             throw new CustomException([
//                 'status' => 'failed',
//                 'message' => 'Role can\'t be updated, '. $e->getMessage(),
//             ], 422);
//         }
//     }

//     /**
//      * Remove the specified resource from storage.
//      */
//     public function destroy(string $id)
//     {
//         DB::beginTransaction();
//         try {
//             $role = Role::findOrFail($id);
//             $role->delete();
    
//             DB::commit();
    
//             return response()->json([
//                 'status' => 'success',
//                 'message' => 'Role has been deleted',
//             ], 200);
    
//         } catch (\Throwable $e) {
//             DB::rollback();
//             throw new CustomException([
//                 'status' => 'failed',
//                 'message' => 'Role can\'t be deleted, '. $e->getMessage(),
//             ], 422);
//         }
//     }
// }
