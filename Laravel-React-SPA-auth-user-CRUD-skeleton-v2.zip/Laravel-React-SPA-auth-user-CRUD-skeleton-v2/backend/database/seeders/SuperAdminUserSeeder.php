<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class SuperAdminUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = new \App\Models\User\User();
        $user = $user->create([
            'name'=>'Super Admin',
            'username'=>'superadmin',
            'email'=>'superadmin@crystalcode.com',
            'password'=> 12345678,
            'created_by' => 1,
            'status' => [1],
        ]);

        $role = new \App\Models\Role\Role();
        $role = $role->create([
            'title'=>'Super Admin',
            'name'=>'superadmin',
            'created_by' => 1,
            'status' => [1],
        ]);

        // Attaching with additional data in 'created_by' column
        $role->users()->attach($user->id, ['created_by' => 1]);
        // or
        // $user->roles()->attach($role->id, ['created_by' => 1]);

        // $userInfo = new \App\Models\User\UserInfo();
        // $userInfo->create([
        //     'user_id'=>$user->id,
        //     'company_name'=>'default',
        //     'company_tag'=>'default',
        // ]);
    }
}
