<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\BulkAction\BulkDetachController;

/*
|--------------------------------------------------------------------------
| API Bulk Action Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
| dynamic route parameter ({resource}) to capture the URL segment e.g, 'users'
| dynamic route parameter ({resource}) to capture the URL segment e.g, 'users'
|
*/

// Route::prefix('{resource}/{resourceType}')
//   ->middleware('auth:sanctum')
//   ->namespace('BulkAction')
//   ->group(function () {
//     Route::post('bulkDelete', [BulkDetachController::class, 'bulkDelete']);
//     Route::get('bulkActionAttach', [BulkActionAttachController::class, 'bulkActionAttach']);
//     Route::get('bulkActionDetach', [BulkActionDetachController::class, 'bulkActionDetach']);
//   });

  Route::prefix('{resource}/{relationAction}')
  ->middleware('auth:sanctum')
  ->namespace('BulkAction')
  ->group(function () {
      Route::match(['post'], 'bulkDelete', function ($resource, $relationAction) {
          if ($relationAction === 'detach') {
              return app(BulkDetachController::class)->bulkDelete(request(), $resource, $relationAction);
          }

          if ($relationAction === 'single') {
              return app(BulkSingleController::class)->bulkDelete(request(), $resource, $relationAction);
          }
      });
  });
