const chart1 = async (data) => {
    return data
}

const chart2 = async () => {
    return {id:2, item:'chart2'}
}

export  {chart1, chart2}