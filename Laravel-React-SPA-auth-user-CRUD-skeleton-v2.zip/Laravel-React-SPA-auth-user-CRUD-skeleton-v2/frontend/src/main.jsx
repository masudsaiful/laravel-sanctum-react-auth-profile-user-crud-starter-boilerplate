import React from "react";
import ReactDOM from "react-dom/client";
import App from "src/App";

import AuthProvider from "auths/contexts/authContext"
import ErrorProvider from "errors/errorContext";
import { RoleProvider } from "components/roles/roleContext";
import { MessageProvider } from "messages/messageContext";

import "src/index.css";



ReactDOM.createRoot(document.getElementById("root")).render (
  <React.StrictMode>


        <ErrorProvider>
          
          <AuthProvider>
          <RoleProvider>
          <MessageProvider>
              <App />
              </MessageProvider>
              </RoleProvider>
              </AuthProvider>
          
        </ErrorProvider>


  </React.StrictMode>
);
