const keywordsInArrCheck = (arr, keys) => keys.some(key => arr.includes(key))
export default keywordsInArrCheck;