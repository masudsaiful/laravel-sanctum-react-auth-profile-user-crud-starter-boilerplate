<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Throwable;

class Handler extends ExceptionHandler
{
    /**
     * Inputs that are never flashed to the session on validation exceptions.
     *
     * @var array<int, string>
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     *
     * This method allows customization of exception reporting and rendering.
     */
    public function register(): void
    {
        $this->reportable(function (Throwable $e) {
            // Custom logic for reporting exceptions, if needed.
            // Custom reporting in the reportable function, such as logging specific exception types.
        });

        $this->renderable(function (CustomException $e, $request) {
            // Handle CustomException by calling its render method.
            return $e->render($request);
        });
    }
}


// OLD
// namespace App\Exceptions;

// use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
// use Throwable;

// class Handler extends ExceptionHandler
// {
//     /**
//      * The list of the inputs that are never flashed to the session on validation exceptions.
//      *
//      * @var array<int, string>
//      */
//     protected $dontFlash = [
//         'current_password',
//         'password',
//         'password_confirmation',
//     ];

//     /**
//      * Register the exception handling callbacks for the application.
//      */
//     public function register(): void
//     {
//         $this->reportable(function (Throwable $e) {
//             //
//         });

//         $this->renderable(function (CustomException $e, $request) {
//             return $e->render($request);
//         });
//     }
// }
