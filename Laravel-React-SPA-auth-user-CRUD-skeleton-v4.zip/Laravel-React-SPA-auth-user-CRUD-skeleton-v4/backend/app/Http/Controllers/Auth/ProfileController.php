<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Exceptions\CustomException;

use App\Models\User\User;

class ProfileController extends Controller
{
    /**
     * Retrieve the authenticated user's profile.
     *
     * @return \Illuminate\Http\JsonResponse
     * @throws CustomException
     */
    public function profile()
    {
        // Check if user is authenticated
        if (!Auth::check()) {
            // throw new CustomException([
            //     'status' => 'unauthenticated', 
            //     'message' => 'profile anauthenticated message'
            // ], 401);

            return response()->json([
                'status' => 'unauthenticated',
                'message' => 'profile unauthenticate message'
            ]);

        } else {
            // Expected exceptions
            // return response()->json([
            //     'status' => 'unauthenticated',
            //     'message' => 'profile unauthenticate message'
            // ]);

            $user = Auth::user();

            // Validate that $user is an instance of the User model
            if (!$user instanceof User) {
                throw new CustomException([
                    'status' => 'failed', 
                    'message' => 'Profile failed message, auth user instance of User model check failed'
                ], 500);
            }
    
            // Decode JSON format of status field to an associative array if necessary
            if (is_string($user->status)) {
                $user->status = json_decode($user->status, true);
            }
    
            // Hide sensitive fields like password and remember_token
            $user->makeHidden(['password', 'remember_token']);
    
            // lazy eager loading of selected fields of roles table 
            // $user->load('roles:id,name,title,created_by');
            if (Auth::id() != 1) {
                $user->load(['roles' => function($query) {
                    $query->where('roles.id', '!=', 1)
                    ->whereJsonContains('status', 1)
                    ->select('roles.id', 'roles.name', 'roles.title', 'roles.status', 'roles.created_by');
                }]);
            } else {
                $user->load(['roles' => function($query) {
                    $query->whereJsonContains('status', 1)
                    ->select('roles.id', 'roles.name', 'roles.title', 'roles.status', 'roles.created_by');
                }]);
            }
    
            return response()->json([
                'status' => 'success',
                'message' => 'Found profile',
                'profile' => $user, 
            ], 200);
        }

        
    }
}

// OLD
// namespace App\Http\Controllers\Auth;

// use Illuminate\Http\Request;
// use App\Models\User\User;
// use Illuminate\Support\Facades\Auth;
// use App\Http\Controllers\Controller;
// use App\Exceptions\CustomException;

// class ProfileController extends Controller
// {
//     /**
//      * Handle unauthenticated user.
//      * Dependencies to Authenticate Middleware
//      * Dependencies to CustomUnauthenticateException
//      * Dpendencies to Exceptions Handler
//      */

//     public function profile()
//     {
//         // if(Auth::user()) {
//         //     return response()->json(Auth::user());
//         // } else {
//         //     return null;
//         // }

//         if (!Auth::check()) {
//             throw new CustomException([
//                 'status' => 'profile controller failed', 
//                 'message' => 'Profile controller exception occured, auth check failed'
//             ], 401);
//         }

//         $user = Auth::user();

//         // Lazy eager loading after retrieved User
//         // $user->load('roles'); 

//         // Ensure $user is an instance of the User model
//         if (!$user instanceof User) {
//             throw new CustomException([
//                 'status' => 'profile controller failed', 
//                 'message' => 'Profile controller exception occured, auth user instance of user model check failed'
//             ], 500);
//         }

//         // Decode status field from dB json format to PHP assoc array
//         if (is_string($user->status)) {
//             $user->status = json_decode($user->status, true);
//         }

//         // Exclude password and other sensitive fields
//         $user->makeHidden(['password', 'remember_token']);

//         // lazy eager loading of selected fields of roles table 
//         $user->load('roles:id,name,title,created_by');

//         return response()->json([
//             'status' => 'success',
//             'message' => 'Found profile',
//             'profile' => $user, 
//         ], 200);
//     }
// }