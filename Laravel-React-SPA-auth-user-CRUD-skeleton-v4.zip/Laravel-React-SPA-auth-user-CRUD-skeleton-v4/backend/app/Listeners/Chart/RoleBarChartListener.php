<?php

namespace App\Listeners\Chart;

use Illuminate\Contracts\Queue\ShouldQueue;

use App\Services\Chart\RoleBarChartUpdateService;

class RoleBarChartListener implements ShouldQueue
{
    protected $service;

    /**
     * Create the event listener.
     */
    public function __construct(RoleBarChartUpdateService $service) {
        $this->service = $service;
    }

    /**
     * Handle the event.
     */
    public function handle($event): void
    {
        // $month = now()->month;
        // $year = now()->year;

        // if ($event instanceof UserEvent) {
        //     foreach ($event->user->roles as $role) {
        //         $this->service->updateRoleBarChart($role->id, $month, $year);
        //     }
        // } elseif ($event instanceof RoleEvent) {
        //     $this->service->updateRoleBarChart($event->role->id, $month, $year);
        // }

        $this->service->updateRoleBarChart($event);
    }
}
