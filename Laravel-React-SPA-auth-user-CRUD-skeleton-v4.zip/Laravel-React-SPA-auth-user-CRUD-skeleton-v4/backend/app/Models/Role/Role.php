<?php

namespace App\Models\Role;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Builder;

use App\Models\User\User;
use App\Observers\Role\RoleObserver;

class Role extends Model
{
    use SoftDeletes, HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'title',
        'name',
        'created_by',
        'status',
    ];

    /**
     * The attributes that should be cast.
     * status field as json field type in dB
     * 
     * @var array<string, string>
     */
    protected $casts = [
        'status' => 'array',
    ];

    /**
     * The attributes that should be hidden for serialization.
     * Will not be visible in collections
     *
     * @var array<int, string>
     */
    protected $hidden = ['pivot'];

    /**
     * Define a many-to-many relationship with the associated model.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'role_user', 'role_id', 'user_id')
        ->withPivot('created_by')
        ->withTimeStamps();
    }

    /**
     * Scope a query to filter resource by status.
     * Automatically filter json array field '[1]' format using whereJsonContains with simply '1'
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param int $status
     */
    public function scopeRoleStatusScope(Builder $query, $status)
    {
        $query->whereJsonContains('status', $status);
    }

    /**
     * Bootstrap any application services.
     */
    protected static function boot()
    {
        parent::boot();

        // Observer can also be registered in boot method of AppServiceProvider
        Role::observe(RoleObserver::class);

        // // Listen to the deleting event
        // static::deleting(function ($role) {
        //     // Detach users associated with this role
        //     $role->users()->detach();
        // });
    }
}

// OLD
// namespace App\Models\Role;

// // use Illuminate\Contracts\Auth\MustVerifyEmail;
// use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Illuminate\Database\Eloquent\SoftDeletes;
// use Illuminate\Notifications\Notifiable;
// use Laravel\Sanctum\HasApiTokens;
// use Illuminate\Database\Eloquent\Model;
// use Illuminate\Database\Eloquent\Relations\BelongsToMany;
// use Illuminate\Database\Eloquent\Builder;

// use App\Models\User\User;

// class Role extends Model
// {
//     use SoftDeletes, HasApiTokens, HasFactory, Notifiable;

//     /**
//      * The attributes that are mass assignable.
//      *
//      * @var array<int, string>
//      */
//     protected $fillable = [
//         'title',
//         'name',
//         'created_by',
//         'status',
//     ];

//     /**
//      * The attributes that should be cast.
//      *
//      * @var array<string, string>
//      */
//     protected $casts = [
//         'status' => 'array', // status field as json column type
//     ];

//     protected $hidden = ['pivot'];

//     public function users(): BelongsToMany
//     {
//         return $this->belongsToMany(User::class, 'role_user', 'user_id', 'role_id')
//         ->withPivot('created_by')
//         ->withTimeStamps();
//     }

//     // Common query pattern of status query using 'scope'
//     // Automatically filter json array field '[1]' format using whereJsonContains with simply '1'
//     public function scopeRoleStatusScope(Builder $query, $status)
//     {
//         $query->whereJsonContains('status', $status);
//     }
// }
