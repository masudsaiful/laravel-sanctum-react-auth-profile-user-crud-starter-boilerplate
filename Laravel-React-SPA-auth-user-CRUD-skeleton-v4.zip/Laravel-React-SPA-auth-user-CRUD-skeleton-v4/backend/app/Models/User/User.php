<?php

namespace App\Models\User;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

use App\Models\Role\Role;
use App\Observers\User\UserObserver;

class User extends Authenticatable
{
    use SoftDeletes, HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'username',
        'password',
        'created_by',
        'status',
    ];

    /**
     * The attributes that should be cast.
     * status field as json field type in dB
     * 
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'status' => 'array',
    ];

    /**
     * The attributes that should be hidden for serialization.
     * Will not be visible in collections
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    public function setPasswordAttribute($value)
    {
        if ($value) {
            $this->attributes['password'] = bcrypt($value);
        }
    }

    /**
     * Define a many-to-many relationship with the associated model.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class, 'role_user', 'user_id', 'role_id')
        ->withPivot('created_by')
        ->withTimeStamps();
    }

    /**
     * Scope a query to filter resource by status.
     * Automatically filter json array field '[1]' format using whereJsonContains with simply '1'
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param int $status
     */
    public function scopeUserStatusScope(Builder $query, $status)
    {
        $query->whereJsonContains('status', $status);
    }

    /**
     * Bootstrap any application services.
     */
    protected static function boot()
    {
        parent::boot();

        // Observer can also be registered in boot method of AppServiceProvider
        User::observe(UserObserver::class);
        
        // // Listen to the deleting event
        // static::deleting(function ($user) {
        //     // Detach roles associated with this user
        //     $user->roles()->detach();
        // });
    }

    // Common query pattern of relationship query using 'scope'
    // Common query pattern of relationship status query using 'scope'
    // Automatically filter json array field '[1]' format using whereJsonContains with simply '1'
    // public function scopeRoleRelScope(Builder $query, $relation, $status)
    // {
    //     $query->with([$relation => function($query) use($status) {
    //         $query->roleStatusScope($status);
    //     }]);
    // }

    /**
     * Scope apply for super admin
     * db:seed artisan at the beginning will create superadmin user/role id:1
     * Scope a query to filter resource by 'with', 'whereHas'.
     * Scope a query to filter resource by status.
     * Automatically filter json array field '[1]' format using whereJsonContains with simply '1'
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param string $method
     * @param string $relation
     * @param int $status
     * @param string $field
     * @param string $fieldValue
     */
    public function scopeRoleRelSuperAdminScope(Builder $query, $method, $relation, $status, $field = null, $fieldValue = null)
    {
        // if ($method === 'with') {
        //     $query->with([$relation => function($q) use($status) {
        //         $q->roleStatusScope($status)
        //           ->select('roles.id', 'roles.name', 'roles.title', 'roles.created_by');
        //     }]);

        
        if ($method === 'with') {
            $query->{$method}([$relation => function ($q) use ($relation, $status) {
                $q->roleStatusScope($status)
                ->select("{$relation}.id", "{$relation}.name", "{$relation}.title", "{$relation}.created_by");
            }]);
        }

        if ($method === 'whereHas') {
            $query->{$method}($relation, function(Builder $q) use($status, $field, $fieldValue) {
                $q->where($field, 'like', '%' . $fieldValue . '%');
                $q->roleStatusScope($status);
            });
        }
    }

    /**
     * Scope apply for non super admin
     * Scope a query to filter resource by 'with', 'whereHas'.
     * Scope a query to filter resource by status.
     * Automatically filter json array field '[1]' format using whereJsonContains with simply '1'
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param string $method
     * @param string $relation
     * @param int $status
     * @param string $field
     * @param string $fieldValue
     */
    public function scopeRoleRelNonSuperAdminScope(Builder $query, $method, $relation, $status, $field = null, $fieldValue = null)
    {
        if ($method === 'with') {
            $query->{$method}([$relation => function ($q) use ($relation, $status) {
                $q->roleStatusScope($status)
                ->where("{$relation}.id", '!=', 1)
                ->select("{$relation}.id", "{$relation}.name", "{$relation}.title", "{$relation}.created_by");
            }]);
        }

        if ($method === 'whereHas') {
            $query->{$method}($relation, function(Builder $q) use($relation, $status, $field, $fieldValue) {
                $q->where($field, 'like', '%' . $fieldValue . '%');
                $q->where("{$relation}.id", '!=', 1);
                $q->roleStatusScope($status);
            });
        }
    }

    /**
     * Scope a query to filter resource except own id, superadmin id.
     * Scope to exclude specific users by their IDs.
     * 
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param int $userId
     * @param int $excludedId
     */
    public function scopeUserExcludeScope(Builder $query, $userId, $excludedId)
    {
        $query->where('id', '!=', $userId);
        $query->where('id', '!=', $excludedId);
    }
}

// OLD
// namespace App\Models\User;

// // use Illuminate\Contracts\Auth\MustVerifyEmail;
// use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Illuminate\Foundation\Auth\User as Authenticatable;
// use Illuminate\Database\Eloquent\SoftDeletes;
// use Illuminate\Notifications\Notifiable;
// use Laravel\Sanctum\HasApiTokens;
// use Illuminate\Database\Eloquent\Builder;
// use Illuminate\Database\Eloquent\Relations\BelongsToMany;

// use App\Models\Role\Role;

// class User extends Authenticatable
// {
//     use SoftDeletes, HasApiTokens, HasFactory, Notifiable;

//     /**
//      * The attributes that are mass assignable.
//      *
//      * @var array<int, string>
//      */
//     protected $fillable = [
//         'name',
//         'email',
//         'username',
//         'password',
//         'created_by',
//         'status',
//     ];

//     /**
//      * The attributes that should be hidden for serialization.
//      *
//      * @var array<int, string>
//      */
//     protected $hidden = [
//         'password',
//         'remember_token',
//     ];

//     /**
//      * The attributes that should be cast.
//      *
//      * @var array<string, string>
//      */
//     protected $casts = [
//         'email_verified_at' => 'datetime',
//         'password' => 'hashed',
//         'status' => 'array', // status field as json column type
//     ];

//     public function setPasswordAttribute($value)
//     {
//         if ($value) {
//             $this->attributes['password'] = bcrypt($value);
//         }
//     }

//     public function roles(): BelongsToMany
//     {
//         return $this->belongsToMany(Role::class, 'role_user', 'user_id', 'role_id')
//         ->withPivot('created_by')
//         ->withTimeStamps();
//     }

//     // Common query pattern of status query using 'scope'
//     // Automatically filter json array field '[1]' format using whereJsonContains with simply '1'
//     public function scopeUserStatusScope(Builder $query, $status)
//     {
//         $query->whereJsonContains('status', $status);
//     }

//     // Common query pattern of relationship query using 'scope'
//     // Common query pattern of relationship status query using 'scope'
//     // Automatically filter json array field '[1]' format using whereJsonContains with simply '1'
//     // public function scopeRoleRelScope(Builder $query, $relation, $status)
//     // {
//     //     $query->with([$relation => function($query) use($status) {
//     //         $query->roleStatusScope($status);
//     //     }]);
//     // }

//     public function scopeRoleRelScope(Builder $query, $method, $relation, $status, $field = null, $fieldValue = null)
//     {
//         // if ($method === 'with') {
//         //     $query->with([$relation => function($q) use($status) {
//         //         $q->roleStatusScope($status)
//         //           ->select('roles.id', 'roles.name', 'roles.title', 'roles.created_by');
//         //     }]);

//         if ($method === 'with') {
//             $query->{$method}([$relation => function ($q) use ($status) {
//                 $q->roleStatusScope($status)
//                 ->select('roles.id', 'roles.name', 'roles.title', 'roles.created_by');
//             }]);
//         }

//         if ($method === 'whereHas') {
//             $query->{$method}($relation, function(Builder $q) use($status, $field, $fieldValue) {
//                 $q->where($field, 'like', '%' . $fieldValue . '%');
//                 $q->roleStatusScope($status);
//             });
//         }
//     }

//     // Common query pattern of relationship query using 'scope'
//     // Common query pattern of relationship status query using 'scope'
//     // Automatically filter json array field '[1]' format using whereJsonContains with simply '1'
//     public function ScopeUserExcludeScope(Builder $query, $param1, $param2)
//     {
//         $query->where('id', '!=', $param1);
//         $query->where('id', '!=', $param2);
//     }
// }
