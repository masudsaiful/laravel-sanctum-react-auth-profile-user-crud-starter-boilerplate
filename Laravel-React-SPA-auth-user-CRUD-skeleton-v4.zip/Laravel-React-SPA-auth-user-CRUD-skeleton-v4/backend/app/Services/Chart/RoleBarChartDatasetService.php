<?php

namespace App\Services\Chart;

use Illuminate\Support\Facades\DB;
use App\Models\Chart\RoleBarChart;
use App\Models\Role\Role;

class RoleBarChartDatasetService
{
    /**
     * Fetch dataset based on roles, period, and years.
     */
    public function getDataset(array $requestData)
    {
        $roles = $requestData['roles'] ?? [];
        $period = $requestData['period'][0];
        $years = $requestData['years'] ?? [];

        // Default to current year for "Month" period if no year is specified
        if ($period == 1 && empty($years)) {
            $years = [date('Y')];
        }

        return $period == 1
            ? $this->monthlyData($roles, $years)
            : $this->yearlyData($roles, $years);
    }

    /**
     * Fetch role titles in a role-title map for transforming role IDs to names.
     */
    protected function getRoleTitleMap(): array
    {
        return Role::pluck('title', 'id')->toArray();
    }

    /**
     * Fetch monthly data for the given roles and years.
     */
    protected function monthlyData(array $roles, array $years)
    {
        $selectedYear = $years[0] ?? date('Y'); // Default to current year
        $roleTitles = $this->getRoleTitleMap();

        // Include all roles if none are specified
        $roles = $roles ?: array_keys($roleTitles);

        $data = RoleBarChart::whereIn('role_id', $roles)
            ->where('year', $selectedYear)
            ->select(DB::raw('role_id, month, SUM(user_count) as user_count'))
            ->groupBy('role_id', 'month')
            ->get()
            ->mapToGroups(function ($item) {
                return [$item->month => [$item->role_id => (int)$item->user_count]];
            });

        return $this->transformMonthlyDataWithTitles($data, $roleTitles);
    }

     /**
     * Transform monthly data to include role titles and fill missing months.
     */
    protected function transformMonthlyDataWithTitles($data, $roleTitles)
    {
        $formattedData = [];
        foreach ($data as $month => $roleCounts) {
            $formattedItem = ['month' => date('M', mktime(0, 0, 0, $month, 10))];
    
            foreach ($roleCounts as $roleCount) {
                foreach ($roleCount as $roleId => $count) {
                    $title = $roleTitles[$roleId] ?? $roleId;
                    $formattedItem[$title] = $count;
                }
            }
    
            $formattedData[] = $formattedItem;
        }
    
        $allRoles = array_unique(array_merge(...array_map('array_keys', $formattedData)));
        $allRoles = array_diff($allRoles, ['year', 'month']); // Remove 'year' and 'month' from keys

        // Sort role keys alphabetically
        sort($allRoles);

        // Define the correct month order for sorting
        $monthOrder = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']; 

        // Add missing keys to each entry and move 'year' or 'month' to the end
        foreach ($formattedData as &$data) {
            // Add missing roles with 0 and order them alphabetically
            $data = array_merge(array_fill_keys($allRoles, 0), $data);

            // Sort 'month' to appear in correct order if present, then add 'year' or 'month' at the end
            // Keep original month value for easier sorting later
            if (isset($data['month'])) {
                $data['month'] = $data['month']; 
            }

            // Move 'year' or 'month' to the end if it exists
            foreach (['year', 'month'] as $timeKey) {
                if (isset($data[$timeKey])) {
                    $timeValue = $data[$timeKey];
                    unset($data[$timeKey]); // Remove time key from current position
                    $data[$timeKey] = $timeValue; // Add time key at the end
                }
            }
        }
        unset($data); // Break reference

        // Step 4: Sort the entire dataset by month order if 'month' is present
        usort($formattedData, function ($a, $b) use ($monthOrder) {
            // Only compare 'month' if it exists in both arrays
            if (isset($a['month']) && isset($b['month'])) {
                return array_search($a['month'], $monthOrder) <=> array_search($b['month'], $monthOrder);
            }
            return 0;
        });

        return $formattedData;
    }

    /**
     * Fetch yearly data for the given roles and years.
     */
    protected function yearlyData(array $roles, array $years)
    {
        $roleTitles = $this->getRoleTitleMap();

        // Include all years if none are specified
        if (empty($years)) {
            $years = $this->getAvailableYears();
        }

        // Include all roles if none are specified
        $roles = $roles ?: array_keys($roleTitles);

        $data = RoleBarChart::whereIn('role_id', $roles)
            ->whereIn('year', $years)
            ->select(DB::raw('role_id, year, SUM(user_count) as user_count'))
            ->groupBy('role_id', 'year')
            ->get()
            ->mapToGroups(function ($item) {
                return [$item->year => [$item->role_id => (int)$item->user_count]];
            });

        return $this->transformYearlyDataWithTitles($data, $roleTitles, $years);
    }

    /**
     * Transform yearly data to include role titles and fill missing years.
     */
    protected function transformYearlyDataWithTitles($data, $roleTitles)
    {
        $formattedData = [];
        foreach ($data as $year => $roleCounts) {
            $formattedItem = ['year' => $year];
    
            foreach ($roleCounts as $roleCount) {
                foreach ($roleCount as $roleId => $count) {
                    $title = $roleTitles[$roleId] ?? $roleId;
                    $formattedItem[$title] = $count;
                }
            }
    
            $formattedData[] = $formattedItem;
        }
    
        // Dataset arranging for same length of items
        // Collect unique role keys (ignoring 'year' and 'month')
        $allRoles = array_unique(array_merge(...array_map('array_keys', $formattedData)));
        $allRoles = array_diff($allRoles, ['year', 'month']); // Remove 'year' and 'month' from keys

        // Sort role keys alphabetically
        sort($allRoles);

        // Add missing keys to each entry and move 'year' or 'month' to the end
        foreach ($formattedData as &$data) {
            // Add missing roles with 0 and order them alphabetically
            $data = array_merge(array_fill_keys($allRoles, 0), $data);

            // Move 'year' or 'month' to the end if it exists
            foreach (['year', 'month'] as $timeKey) {
                if (isset($data[$timeKey])) {
                    $timeValue = $data[$timeKey];
                    unset($data[$timeKey]); // Remove time key from current position
                    $data[$timeKey] = $timeValue; // Add time key at the end
                }
            }
        }
        unset($data); // Break reference

        return $formattedData;
    }

    /**
     * Fetch all available years from the RoleBarChart table.
     */
    public function getAvailableYears(): array
    {
        return RoleBarChart::distinct()->orderBy('year', 'asc')->pluck('year')->toArray();
    }
}
