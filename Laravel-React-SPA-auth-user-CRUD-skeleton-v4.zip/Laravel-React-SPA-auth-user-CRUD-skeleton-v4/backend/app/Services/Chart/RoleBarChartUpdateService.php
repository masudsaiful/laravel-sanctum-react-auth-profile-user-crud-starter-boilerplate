<?php

namespace App\Services\Chart;

use App\Models\Chart\RoleBarChart;

use App\Events\Role\RoleEvent;
use App\Events\User\UserEvent;
use App\Events\Chart\RoleBarChartDetachEvent;

class RoleBarChartUpdateService
{
    /**
     * Function to update role_bar_charts table.
     *
     * @var array<int, int, int>
     */
    public function updateRoleBarChart($event)
    {
        if ($event instanceof RoleEvent) {
            $this->handleRoleEvent($event);
        } elseif ($event instanceof UserEvent) {
            $this->handleUserEvent($event);
        } elseif ($event instanceof RoleBarChartDetachEvent) {
            $this->handleRoleBarChartDetachEvent($event);
        }
    }

    /**
     * Handle RoleEvent by updating the role chart for role-based events.
     */
    protected function handleRoleEvent(RoleEvent $event)
    {
        // role_bar_charts table update if role enabled, updated and has attached users
        // Though status field is json array field type, use [] and whereJsonContains
        $role = $event->role;
        if ($role->users()->exists()) {
            if ($role->status === [1]) {
                $userCount = $role->users()->whereJsonContains('status', 1)->count();
                $this->storeRoleData($role->id, date('Y'), date('m'), $userCount);
            } elseif ($role->status === [2]) {
                $this->storeRoleData($role->id, date('Y'), date('m'), 0);
            }
        } else {
            $this->storeRoleData($role->id, date('Y'), date('m'), 0);
        }
    }

    /**
     * Handle UserEvent by updating the role chart for user-based events.
     */
    protected function handleUserEvent(UserEvent $event)
    {
        // role_bar_charts table update if user hase status and user has attached role
        // Though status field is json array field type, use [] and whereJsonContains
        $user = $event->user;
        if ($user->roles()->exists()) {
            if ($user->status === [1]) {
                foreach ($user->roles as $role) {
                    if ($role->users()->exists()) {
                        if ($role->status === [1]) {
                            $userCount = $role->users()->whereJsonContains('status', 1)->count();
                            $this->storeRoleData($role->id, date('Y'), date('m'), $userCount);
                        }
                    }
                }
            } elseif ($user->status === [2]) {
                foreach ($user->roles as $role) {
                    if ($role->users()->exists()) {
                        if ($role->status === [1]) {
                            $userCount = $role->users()->whereJsonContains('status', 1)->count();
                            // Adjust count for deleted user if status enabled only
                            // $userCount = max(0, $userCount - 1);
                            $this->storeRoleData($role->id, date('Y'), date('m'), $userCount);
                        }
                    }
                }
            }
        }

        // role_bar_charts table update if user hase status and user has attached role
        // Though status field is json array field type, use [] and whereJsonContains
        // $user = $event->user;
        // if ($user->status === [1] && $user->roles()->exists()) {
        //     foreach ($user->roles as $role) {
        //         if ($role->status === [1] && $role->users()->exists()) {
        //             $userCount = $role->users()->whereJsonContains('status', 1)->count();
        //             $this->storeRoleData($role->id, date('Y'), date('m'), $userCount);
        //         } else {
        //             $this->storeRoleData($role->id, date('Y'), date('m'), 0);
        //         }
                
        //         // // Check if the user event is a delete event
        //         // if ($user->wasDeleted) {
        //         //     // Adjust count for deleted user if status enabled only
        //         //     $userCount = max(0, $userCount - 1);
        //         // }

        //         // $this->storeRoleData($role->id, date('Y'), date('m'), $userCount);
        //     }
        // } else {
        //     foreach ($user->roles as $role) {
        //         if ($role->status === [1] && $role->users()->exists()) {
        //             $userCount = $role->users()->whereJsonContains('status', 1)->count();
        //             $this->storeRoleData($role->id, date('Y'), date('m'), $userCount);
        //         } else {
        //             $this->storeRoleData($role->id, date('Y'), date('m'), 0);
        //         }
        //     }
        // }
    }

    /**
     * Handle UserEvent by updating the role chart for user-based events.
     */
    protected function handleRoleBarChartDetachEvent(RoleBarChartDetachEvent $event)
    {
        // Only status enabled data will be populated in role_bar_charts table
        // Though status field is json array field type, use [] and whereJsonContains
        $user = $event->user;
        if ($user->roles()->exists()) {
            if ($user->status === [1]) { 
                foreach ($user->roles as $role) {
                    if ($role->users()->exists()) { 
                        if ($role->status === [1]) {
                            $userCount = $role->users()->whereJsonContains('status', 1)->count();
                            $userCount = max(0, $userCount - 1);
                            $this->storeRoleData($role->id, date('Y'), date('m'), $userCount);
                        }
                    }
                }
            }
        }
    }

    /**
     * Store or update the role chart data based on the role, year, and month.
     */
    protected function storeRoleData(int $roleId, string $year, string $month, int $userCount)
    {
        RoleBarChart::updateOrCreate(
            ['role_id' => $roleId, 'year' => $year, 'month' => $month],
            ['user_count' => $userCount]
        );
    }
}
