<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Chart\DynamicChartController;

/*
|--------------------------------------------------------------------------
| API Chat Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Route::prefix('{resource}/{resourceType}')
//   ->middleware('auth:sanctum')
//   ->namespace('BulkAction')
//   ->group(function () {
//     Route::post('bulkDelete', [BulkDetachController::class, 'bulkDelete']);
//     Route::get('bulkActionAttach', [BulkActionAttachController::class, 'bulkActionAttach']);
//     Route::get('bulkActionDetach', [BulkActionDetachController::class, 'bulkActionDetach']);
//   });

// Route::prefix('{resource}/{chartName}')
//     ->middleware('auth:sanctum')
//     ->group(function () {
//         Route::post('chart', function ($resource, $chartName) {
//             // Construct the controller name dynamically
//             $model = Str::studly(Str::singular($resource));
//             $param = Str::studly(Str::singular($chartName));
//             $controllerName = 'App\\Http\\Controllers\\Chart\\' . $model . $param . 'ChartController';

//             // Use the controller name dynamically with the chart method
//             return app()->make($controllerName)->chart(app(ChartRequest::class), $resource, $chartName);
//         });
//     });

Route::prefix('{resource}/{chartName}')
    ->namespace('Chart')
    ->middleware('auth:sanctum')
    ->group(function () {
        Route::post('charts', [DynamicChartController::class, 'handle']);
        Route::get('charts', [DynamicChartController::class, 'handle']);
    });
