import React from "react";
import { Outlet, useLoaderData } from "react-router-dom";



const About = () => {




  return (
    <div>
      <Outlet />
      <h2>About</h2>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>
      <p>This is the about page.</p>

    </div>
  );
};

export default About;
