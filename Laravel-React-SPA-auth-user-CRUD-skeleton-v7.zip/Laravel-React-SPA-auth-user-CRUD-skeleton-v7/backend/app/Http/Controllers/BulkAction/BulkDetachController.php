<?php

namespace App\Http\Controllers\BulkAction;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Exceptions\CustomException;
use Illuminate\Support\Facades\DB;
//Laravel's Str helper to format the string and app() to dynamically resolve the model.
use Illuminate\Support\Str;


class BulkDetachController extends Controller
{
    /**
     * Store a newly created resource in storage.
     * Param ($resource) value from Route::prefix('{resource}').
     * app() to dynamically resolve the model.
     * app($modelName) resolves the model instance dynamically.
     * Str::studly() capitalizes the first letter.
     * Str::singular($resource) converts "users" to "user".
     * 'App\\Models\\' . $modelName . '\\'. $modelName creates the full model class path
     * 
     */
    public function bulkDelete(Request $request, $resource, $relationAction)
    {
        // Assumes 'ids' is an array of IDs to delete
        $ids = $request->ids;
        
        // This should be e.g, 'users' or other plural resource name
        $resourceName = $resource;
        // or
        // $resourceName = $request->route('resource');

        // This should be the relationship method name like 'roles'
        $relationMethodName = $request->relationMethod;

        // Convert resource to model class name, e.g., 'users' to 'User'.
        $model = Str::studly(Str::singular($resourceName));
        $modelName = 'App\\Models\\' . $model . '\\'. $model;

        // Check if the model class exists, e.g., 'User'.
        if (!class_exists($modelName)) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Model not found, model: '. $model,
            ], 404); // 404, Not found
        }

        DB::beginTransaction();
        try {
            if (is_array($ids)) {
                // Use the dynamically resolved model to perform the delete operation
                $modelInstance = app($modelName);
                $records = $modelInstance::whereIn('id', $ids);

                // $users = User::whereIn('id', $ids);
                // foreach ($users->get() as $user) {
                //     $user->roles()->detach();
                // }
                // $users->delete();

                // Example: Detach the specified relationship before deletion (if it exists)
                foreach ($records->get() as $record) {
                    // Check if the relationship method name exists defining by the $record e.g, User model
                    if ($relationMethodName && method_exists($record, $relationMethodName)) { 
                        // Detach the relationship by using relation method name before deleting the record
                        $record->{$relationMethodName}()->detach(); 
                    }
                }

                // Delete the records
                $records->delete();
            }

            DB::commit();
    
            return response()->json([
                'status' => 'success',
                'message' => $model . '(s) has been deleted',
            ], 200); // successfully deleted, returned contents (status, message etc.)
    
        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => $model . '(s) can\'t be deleted, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }
}
