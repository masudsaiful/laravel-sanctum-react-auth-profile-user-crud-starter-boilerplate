<?php

namespace App\Http\Controllers\Chart;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
//Laravel's Str helper to format the string and app() to dynamically resolve the model.
use Illuminate\Support\Str;
use App\Exceptions\CustomException;
use Illuminate\Support\Facades\DB;

use App\Http\Requests\Chart\ChartRequest;


class DynamicChartController extends Controller
{
    /**
     * Store a newly created resource in storage.
     * Param ($resource) value from Route::prefix('{resource}').
     * app() to dynamically resolve the model.
     * app($modelName) resolves the model instance dynamically.
     * Str::studly() capitalizes the first letter.
     * Str::singular($resource) converts "users" to "user".
     * 'App\\Models\\' . $modelName . '\\'. $modelName creates the full model class path
     * 
     */
    public function handle(ChartRequest $request, $resource, $chartName)
    {
        // Assumes 'type' || 'period' is an array
        $type = $request->type;
        $period = $request->period;
        
        // This should be e.g, 'users' or other plural resource name
        $resourceName = $resource;
        // or
        // $resourceName = $request->route('resource');

        // Convert `{resource}` and `{chartName}` to the appropriate controller class name
        // e.g., 'roles' -> 'Role'
        // e.g., 'bar' -> 'Bar
        $model = Str::studly(Str::singular($resourceName));
        $param = Str::studly(Str::singular($chartName));

        // Dynamically generate the controller class name
        $controllerName = "App\\Http\\Controllers\\Chart\\{$model}{$param}ChartController";

        // Check if the controller class exists, e.g., 'UserBarChartController'.
        if (!class_exists($controllerName)) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Controller not found, controller: ' . $model,
            ], 404); // 404, Not found
        }

        // Instantiate the controller class
        $controllerInstance = app($controllerName);

        if ($request->isMethod('post')) {
            // Call the 'getDataset' method on the instance
            return $controllerInstance->getDataset($request, $resourceName, $chartName);

        } elseif ($request->isMethod('get')) {
            // Call the 'getDatacolumn' method on the instance
            return $controllerInstance->getDatacolumn($request, $resourceName, $chartName);
        }
    }
}
