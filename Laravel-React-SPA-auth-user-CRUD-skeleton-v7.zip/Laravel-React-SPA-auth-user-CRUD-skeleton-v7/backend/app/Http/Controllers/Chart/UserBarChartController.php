<?php

namespace App\Http\Controllers\Chart;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
//Laravel's Str helper to format the string and app() to dynamically resolve the model.
use Illuminate\Support\Str;
use App\Exceptions\CustomException;
use Illuminate\Support\Facades\DB;

use App\Http\Requests\Chart\ChartRequest;
use App\Services\Chart\RoleBarChartDatasetService;


class UserBarChartController extends Controller
{
    protected $service;

    public function __construct(RoleBarChartDatasetService $service)
    {
        $this->service = $service;
    }

    /**
     * Store a newly created resource in storage.
     * Param ($resource) value from Route::prefix('{resource}').
     * app() to dynamically resolve the model.
     * app($modelName) resolves the model instance dynamically.
     * Str::studly() capitalizes the first letter.
     * Str::singular($resource) converts "users" to "user".
     * 'App\\Models\\' . $modelName . '\\'. $modelName creates the full model class path
     * 
     */
    public function getDataset(ChartRequest $request, $resource, $chartName)
    {
        // Assumes 'type' || 'period' is an array
        $type = $request->type;
        $period = $request->period;
        $particulars = $request->particulars;
        $year = $request->years;
        
        // This should be e.g, 'users' or other plural resource name
        $resourceName = $resource;
        // or
        // $resourceName = $request->route('resource');

        // Convert resource to model class name, e.g., 'users' to 'User'.
        $model = Str::studly(Str::singular($resourceName));
        $param = Str::studly(Str::singular($chartName));

        // Dynamically generate the class name
        $modelName = 'App\\Models\\' . $model . '\\'. $model;
        $chartModelName = "App\\Models\\Chart\\{$model}{$param}Chart";

        // Check if the model class exists, e.g., 'User'.
        if (!class_exists($modelName)) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Model not found, model: ' . $model,
            ], 404); // 404, Not found
        }

        // Check if the chart model class exists, e.g., 'UserBarChart'.
        if (!class_exists($chartModelName)) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Model not found, model: ' . $chartModelName,
            ], 404); // 404, Not found
        }

        DB::beginTransaction();
        try {
            if (is_array($type) && is_array($period)) {
                // Use the dynamically resolved model to perform the delete operation
                // $modelInstance = app($modelName);
                // $records = $modelInstance::roleStatusScope(2)->distinct('title')->pluck('title');

                $records = $this->service->getDataset($request->all());
                // return response()->json($data);

                DB::commit();
    
                // successfully deleted, returned contents (status, message etc.)
                return response()->json([
                    'status' => 'success',
                    'message' => $model . ' has been found',
                    'dataset' => $records,
                ], 200); 
            }
        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => $model . ' not found, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }

    public function getDatacolumn(ChartRequest $request, $resource, $chartName)
    {
        // This should be e.g, 'users' or other plural resource name
        $resourceName = $resource;
        // or
        // $resourceName = $request->route('resource');

        // Convert resource to model class name, e.g., 'users' to 'User'.
        $model = Str::studly(Str::singular($resourceName));
        $param = Str::studly(Str::singular($chartName));

        // Dynamically generate the class name
        $modelName = 'App\\Models\\' . $model . '\\'. $model;
        $chartModelName = "App\\Models\\Chart\\{$model}{$param}Chart";

        // Check if the model class exists, e.g., 'User'.
        if (!class_exists($modelName)) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Model not found, model: ' . $model,
            ], 404); // 404, Not found
        }

        // Check if the chart model class exists, e.g., 'UserBarChart'.
        if (!class_exists($chartModelName)) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Model not found, model: ' . $chartModelName,
            ], 404); // 404, Not found
        }

        // Instantiate the controller class
        $modelInstance = app($modelName);
        $chartModelInstance = app($chartModelName);

        try{
            $allChartUserTypes = $chartModelInstance->distinct()->pluck('user_type');
            $allChartUserTypeYears = $chartModelInstance->distinct()->pluck('year');

            return response()->json([
                'status' => 'success',
                'message' => 'Chart roles loaded successfully',
                'allChartRecords' => $allChartUserTypes,
                'allChartYearRecords' => $allChartUserTypeYears,
            ], 200); // 200, successfully retrieved

        }  catch (\Throwable $e) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Chart user types couldn\'t be loaded, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }
}
