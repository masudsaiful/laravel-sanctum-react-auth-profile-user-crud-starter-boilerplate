<?php

namespace App\Http\Controllers\Chart;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
//Laravel's Str helper to format the string and app() to dynamically resolve the model.
use Illuminate\Support\Str;
use App\Exceptions\CustomException;
use Illuminate\Support\Facades\DB;

use App\Http\Requests\Chart\ChartRequest;


class UserPieChartController extends Controller
{
    public function getDatacolumn(ChartRequest $request, $resource, $chartName)
    {
        // This should be e.g, 'users' or other plural resource name
        $resourceName = $resource;
        // or
        // $resourceName = $request->route('resource');

        // Convert resource to model class name, e.g., 'users' to 'User'.
        $model = Str::studly(Str::singular($resourceName));
        $param = Str::studly(Str::singular($chartName));

        // Dynamically generate the class name
        $modelName = 'App\\Models\\' . $model . '\\'. $model;
        $chartModelName = "App\\Models\\Chart\\{$model}{$param}Chart";

        // Check if the model class exists, e.g., 'User'.
        if (!class_exists($modelName)) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Model not found, model: ' . $model,
            ], 404); // 404, Not found
        }

        // Check if the chart model class exists, e.g., 'UserBarChart'.
        if (!class_exists($chartModelName)) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Model not found, model: ' . $chartModelName,
            ], 404); // 404, Not found
        }

        // Instantiate the controller class
        $modelInstance = app($modelName);
        $chartModelInstance = app($chartModelName);

        try{
            // Define default dataset
            $userDefaultPieChartDatas = [
                'total_users' => 0,
                'deleted_users' => 0,
                'existing_users' => 0,
                'deleted_user_percent' => 0,
                'existing_user_percent' => 0,
                'deleted_enable_user_percent' => 0,
                'existing_enable_user_percent' => 0,
                'deleted_disable_user_percent' => 0,
                'existing_disable_user_percent' => 0,
            ];

            $userPieChartDatas = $chartModelInstance->latest()->first();
            $pieChartDatas = collect($userDefaultPieChartDatas)->merge($userPieChartDatas ? $userPieChartDatas : [])->all();

            $data = [
                ['label' => 'Users', 'value' => $pieChartDatas['total_users']],
                ['label' => 'Deleted', 'value' => $pieChartDatas['deleted_users']],
                ['label' => 'Existing', 'value' => $pieChartDatas['existing_users']],
                ['label' => 'Deleted %', 'value' => $pieChartDatas['deleted_user_percent']],
                ['label' => 'Existing %', 'value' => $pieChartDatas['existing_user_percent']],
                ['label' => 'Deleted Enbl %', 'value' => $pieChartDatas['deleted_enable_user_percent']],
                ['label' => 'Exsting Enbl %', 'value' => $pieChartDatas['existing_enable_user_percent']],
                ['label' => 'Deleted Disbl %', 'value' => $pieChartDatas['deleted_disable_user_percent']],
                ['label' => 'Existing Disbl %', 'value' => $pieChartDatas['existing_disable_user_percent']],
            ];

            return response()->json([
                'status' => 'success',
                'message' => 'Chart datas loaded successfully',
                'dataset' => $data,
            ], 200); // 200, successfully retrieved

        }  catch (\Throwable $e) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Chart datas couldn\'t be loaded, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }
}
