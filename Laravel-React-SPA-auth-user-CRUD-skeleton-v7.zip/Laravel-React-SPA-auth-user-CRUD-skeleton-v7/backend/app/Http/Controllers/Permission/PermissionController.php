<?php

namespace App\Http\Controllers\Permission;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

use App\Models\Role\Role;
use App\Exceptions\CustomException;
use App\Models\Permission\Permission;
use App\http\Requests\Permission\PermissionRequest;
use App\Services\Permission\PermissionModelCollectService;

class PermissionController extends Controller
{
    protected $service;

    public function __construct(PermissionModelCollectService $service)
    {
        $this->service = $service;
    }
    
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try{
            $query = Permission::select(
                'id',
                'uuid', 
                'title', 
                'note', 
                'create', 
                'update', 
                'delete', 
                'role_id', 
                'model', 
                'user_id'
            );
            $modelQuery = $this->service->handleModelCollections();

            if (Auth::id() != 1) {
                $query->whereNot('role_id', 1);
            }
            $permissions = $query->get();
            $permissionModels = $modelQuery;
            
            return response()->json([
                'status' => 'success',
                'message' => 'Permissions loaded successfully',
                'permissions' => $permissions,
                'permissionModels' => $permissionModels,
            ], 200); // 200, successfully retrieved

        }  catch (\Throwable $e) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Permissions couldn\'t be loaded, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(PermissionRequest $request)
    {
        DB::beginTransaction();
        try {
            $permission = new Permission();

            // Collect and merge resource fillable data with creator information.
            $permissionFillableData = collect($request->only($permission->getFillable()));
            $createdByFillableData = collect(['created_by' => Auth::id()])->only($permission->getFillable());
            $permissionData = $createdByFillableData->merge($permissionFillableData)->all();
            $permission->fill($permissionData)->save();

            $permission->role()->associate($request->role_id);
            // Handle the `role` field from the payload
            // If role not array from payload (like used in user/role controller) then need to validate
            // $roles = is_array($request->role) ? $request->role : [$request->role];
            // $validRoles = Role::whereIn('id', $roles)->pluck('id')->toArray();

            // if (empty($validRoles)) {
            //     throw new CustomException([
            //         'status' => 'failed',
            //         'message' => 'Invalid or non-existent roles provided.',
            //     ], 422);
            // }

            // Attaching with additional 'created_by' column in the role_permission table
            // $permission->roles()->detach();
            // $permission->roles()->attach($request->roles, ['created_by' => Auth::id()]);
            // $permission->roles()->syncWithPivotValues([$request->role], ['created_by' => Auth::id()]);

            // Role assigned to permission record track for role chart table
            // event(new UserEvent($permission)); or
            // UserEvent::dispatch($permission);

            $permission->save();

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'Permission has been created',
                'permission' => $permission,
            ], 201); // 201, successfully created

        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Permission can\'t be created, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(PermissionRequest $permission)
    {
        try {
            $permissionModels = $this->service->handleModelCollections();
            $permissions = Permission::whereId($permission->id)->findOrFail();
            return response()->json([
                'status' => 'success',
                'message' => 'Role loaded successfully',
                'permissionModels' => $permissionModels,
                'permissions' => $permissions,
            ], 200); // 200, successfully retrieved

        } catch (\Throwable $e) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Permissions or Permission models couldn\'t be loaded, '. $e->getMessage(),
            ], 404); // 404, resource couldn't be found
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(PermissionRequest $request, Permission $permission)
    {
        DB::beginTransaction();
        try {
            $permission = $permission::whereId($permission->id)->firstOrFail();

            // Handle array status field
            // $status = $request->input('status');
            // if (is_array($status)) {
            //     $status = $status[0]; // or any appropriate serialization method
            // }

            // Merge user fillable data with updater information.
            $fillableData = collect($request->only($permission->getFillable()));
            $createdByFillableData = collect(['created_by' => Auth::id()])->only($permission->getFillable());
            $datas = $createdByFillableData->merge($fillableData)->all();
            $permission->fill($datas);

            $permission->role()->associate($request->role_id);

            // Role assigned to user record track for role chart table
            // event(new UserEvent($user)); or
            // UserEvent::dispatch($user);

            $permission->save();
            // $userFillableData = $request->only($user->getFillable());
            // $user->fill($userFillableData);
            // $user->save();

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'Permission has been updated',
                'permission' => $permission,
            ], 200); // 200, successfully retrieved and updated

        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Permission can\'t be updated, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Permission $permission)
    {
        //
    }
}
