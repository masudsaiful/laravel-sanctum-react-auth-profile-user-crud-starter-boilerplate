<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Builder;

use App\Exceptions\CustomException;
use App\Models\User\User;
use App\Http\Requests\User\UserRequest;
use App\Helper\Utilities;
use App\Events\User\UserEvent;
use App\Events\Chart\RoleBarChartDetachEvent;
use App\Services\Permission\PermissionDatasetService;

class UserController extends Controller
{
    protected $service;

    public function __construct(PermissionDatasetService $service)
    {
        $this->service = $service;
    }

    /**
     * Display a paginated listing of resource with optional filtering and sorting.
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(Request $request)
    {
        try {
            $page = $request->input('page', 1);
            $pageSize = $request->input('pageSize', 20);

            $query = User::query();
            $allQuery = User::userStatusScope(1);
    
            // db:seed artisan at the beginning will create superadmin user/role 1
            // Exclude SuperAdmin for non-superadmin users
            if (Auth::id() != 1) {
                $query->roleRelNonSuperAdminScope('with', 'roles', 1);
                $query->userExcludeScope(Auth::id(), 1);
                $allQuery->roleRelNonSuperAdminScope('with', 'roles', 1);
                $allQuery->userExcludeScope(Auth::id(), 1);
            } else {
                $query->roleRelSuperAdminScope('with', 'roles', 1)
                ->userExcludeScope(Auth::id(), 1);
                $allQuery->roleRelSuperAdminScope('with', 'roles', 1)
                ->userExcludeScope(Auth::id(), 1);
            }
    
            // // Sorting
            if ($request->has('sortModel')) {
                $this->applySorting($query, $request->input('sortModel'));
            }

            // // Filtering
            if ($request->has('filterModel')) {
                $this->applyFiltering($query, $request->input('filterModel'));
            }
            
            $users = $query->paginate($pageSize, ['*'], 'page', $page);
            $allUsers = $allQuery->get();
    
            return response()->json([
                'status' => 'success',
                'message' => 'User(s) has been loaded',
                'user' => $users->items(),
                'allUsers' => $allUsers,
                'total' => $users->total(),
                'current_page' => $users->currentPage(),
                'last_page' => $users->lastPage(),
                'permissionDataset' =>  $this->service->getDataset(),
            ], 200); // 200, successfully retrieved

        } catch (\Throwable $e) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'User couldn\'t be loaded, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param UserRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(UserRequest $request)
    {
        DB::beginTransaction();
        try {
            $user = new User();

            // Collect and merge resource fillable data with creator information.
            $userFillableData = collect($request->only($user->getFillable()));
            $createdByFillableData = collect(['created_by' => Auth::id()])->only($user->getFillable());
            $userData = $createdByFillableData->merge($userFillableData)->all();
            $user->fill($userData)->save();

            // Attaching with additional 'created_by' column in the role_user table
            // $user->roles()->detach();
            // $user->roles()->attach($request->roles, ['created_by' => Auth::id()]);
            $user->roles()->syncWithPivotValues($request->roles, ['created_by' => Auth::id()]);

            // Role assigned to user record track for role chart table
            // event(new UserEvent($user)); or
            // UserEvent::dispatch($user);

            $user->save();

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'User has been created',
                'user' => $user,
            ], 201); // 201, successfully created

        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => 'User can\'t be created, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }

    /**
     * Display the specified resource by id.
     *
     * @param string $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show(string $id)
    {
        try {
            // Lazy eager loading not working with common pattern query
            // Lazy loading work with common pattern query (roleRelScope)
            if (Auth::id() != 1) {
                $user = User::roleRelNonSuperAdminScope('with', 'roles', 1)
                ->whereId($id)
                ->firstOrFail();
            } else {
                $user = User::roleRelSuperAdminScope('with', 'roles', 1)
                ->whereId($id)
                ->firstOrFail();
            }


            // lazy eager loading of selected fields of roles table 
            // $user->load('roles:id,name,title,created_by');

            // $user = User::whereId($id)->firstOrFail();
            // $user->load(['roles' => function ($query) {
            //     $query->roleStatusScope(1)
            //     ->select('roles.id', 'roles.name', 'roles.title', 'roles.created_by');
            // }]);

            return response()->json([
                'status' => 'success',
                'message' => 'User has been loaded',
                'user' => $user,
            ], 200); // 200, successfully retrieved

        } catch (\Throwable $e) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'User can\'t be loaded, '. $e->getMessage(),
            ], 404); // 404, resource couldn't be found
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UserRequest $request
     * @param string $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(UserRequest $request, string $id)
    {
        DB::beginTransaction();
        try {
            $user = User::whereId($id)->firstOrFail();

            // Handle array status field
            // $status = $request->input('status');
            // if (is_array($status)) {
            //     $status = $status[0]; // or any appropriate serialization method
            // }

            // Merge user fillable data with updater information.
            $userFillableData = collect($request->only($user->getFillable()));
            $createdByFillableData = collect(['created_by' => Auth::id()])->only($user->getFillable());
            $userData = $createdByFillableData->merge($userFillableData)->all();
            $user->fill($userData);

            // Data count tracking before new attaching
            // event(new RoleBarChartDetachEvent($user)); or
            RoleBarChartDetachEvent::dispatch($user);

            // Sync with additional 'created_by' column in role_user table
            $user->roles()->syncWithPivotValues($request->roles, ['created_by' => Auth::id()]);

            // Role assigned to user record track for role chart table
            // event(new UserEvent($user)); or
            // UserEvent::dispatch($user);

            $user->save();
            // $userFillableData = $request->only($user->getFillable());
            // $user->fill($userFillableData);
            // $user->save();

            // Disabled users token deleted not to login when status disable
            if ($request->status === [2]) {
                $user->sanctumPersonalAccessTokens()->delete();
            }

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'User has been updated',
                'user' => $user,
            ], 200); // 200, successfully retrieved and updated

        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => 'User can\'t be updated, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }

    /**
     * Remove the specified resource from storage.
     * Simple and non nested relationships deleting in here.
     * Complex or nested relationships deleting in model's boot method.
     *
     * @param string $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(string $id)
    {
        DB::beginTransaction();
        try {
            $user = User::findOrFail($id);
            $roleIds = $user->roles->pluck('id');

            RoleBarChartDetachEvent::dispatch($user);

            $user->roles()->detach($roleIds->toArray()); 
            // // or
            // $user->roles()->detach($roleIds->all());
            // // or
            // $user->roles()->detach();
            $user->delete();

            DB::commit();
    
            return response()->json([
                'status' => 'success',
                'message' => 'User has been deleted',
            ], 200); // successfully deleted, returned contents (status, message etc.)
    
        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => 'User can\'t be deleted, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }

    /**
     * Apply sorting to the query based on the sort model.
     * 
     * @param collection $query
     * @param array <$sortModel>
     */
    private function applySorting($query, $sortModel)
    {
        $sortModel = json_decode($sortModel, true);
        // Check if sortModel is a non-empty array
        if (is_array($sortModel) && count($sortModel) > 0) {
            foreach ($sortModel as $sort) {
                if (isset($sort['field']) && isset($sort['sort'])) {
                    if($sort['field'] === 'roles') {
                        $query->whereHas($sort['field'], function(Builder $query) use($sort) {
                            $query->orderBy('title', $sort['sort']);
                        });
                    } else {
                        $query->orderBy($sort['field'], $sort['sort']);
                    }
                }
            }
        }else {
            // Default sorting: latest to oldest
            $query->orderBy('created_at', 'desc');
        }
    }

    /**
     * Apply filtering to the query based on the filter model.
     * Relational scope 'roleRelScope' defined in related model.
     * 
     * @param collection $query
     * @param array <$filterModel>
     */
    private function applyFiltering($query, $filterModel)
    {
        $filterModel = json_decode($filterModel, true);
        if (isset($filterModel['items'])) {
            foreach ($filterModel['items'] as $filter) {
                // Check if keys exist
                if (isset($filter['field']) && isset($filter['value'])) {  
                    if($filter['field'] === 'status') {
                        if ($filter['value'] !== '') {
                            if(Utilities::matchString($filter['value'], 'Disable')) {
                                $query->userStatusScope(2);
                            } elseif(Utilities::matchString($filter['value'], 'Enable')) {
                                $query->userStatusScope(1);
                            }
                        }
                    } elseif ($filter['field'] === 'roles') {
                        if ($filter['value'] !== '') {
                            if (Auth::id() != 1 ) {
                                $query->roleRelNonSuperAdminScope('whereHas', $filter['field'], 1, 'title', $filter['value']);
                            } else {
                                $query->roleRelSuperAdminScope('whereHas', $filter['field'], 1, 'title', $filter['value']);
                            }
                        }
                    } else {
                        $query->where($filter['field'], 'like', '%' . $filter['value'] . '%');
                    }
                }
            }
        }
    }
}

