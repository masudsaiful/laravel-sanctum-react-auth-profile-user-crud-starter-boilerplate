<?php

namespace App\Http\Requests\Auth;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;
use App\Exceptions\CustomException;

class AuthRegisterRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return $this->authRegisterRules();
    }

    /**
     * Validation rules for the POST method.
     *
     * @return array
     */
    private function postRules() {
        $rules = [
            'name' => 'required|string|max:255',
            'username' => 'required|string|max:255|unique:users,username',
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
            'password' => 'required|string|min:8|confirmed',
        ];
        return $rules;
    }

    /**
     * Combination of validation rules depending on the request method.
     *
     * @return array
     */
    private function combinationRules() {
        if (Request::isMethod('post')) {
            $rules = $this->postRules();
            return $rules;
        }
    }

    /**
     * Get the authentication registration rules.
     *
     * @return array
     */
    private function authRegisterRules()
    {
        $rules = $this->combinationRules();
        return $rules;
    }

    /**
     * Get the custom error messages for validation rules.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'name.required' => 'The name field is required',
            'name.string' => 'The name field should be string',
        ];
    }

    /**
     * Filters to be applied to the input before validation.
     *
     * @return array
     */
    public function filters(): array
    {
        return [
            'email' => 'trim|lower', // Filter to trim and convert email to lowercase.
            'name' => 'trim|capitalize', // Filter to trim and capitalize name.
            'username' => 'trim|lower', // Filter to trim and capitalize name.
        ];
    }

    // Directly handling valdation response from form request using HttpResponseException
    // protected function failedValidation(Validator $validator)
    // {
    //     $response = response()->json([
    //         'status' => 'failed',
    //         'message' => 'Validation failed.',
    //         'errors' => $validator->errors(),
    //     ], 422);

    //     throw new HttpResponseException($response);
    // }
    
    /**
     * Handle a failed validation attempt by throwing a CustomException.
     *
     * @param Validator $validator
     * @throws CustomException
     */
    protected function failedValidation(Validator $validator)
    {
        throw new CustomException([
            'status' => 'failed',
            'message' => 'User can\'t be registered',
            'errors' => $validator->errors(),
        ], 422);
    }
}

// OLD
// namespace App\Http\Requests\Auth;

// use Illuminate\Http\Request;
// use Illuminate\Validation\Rule;
// use Illuminate\Foundation\Http\FormRequest;
// use Illuminate\Contracts\Validation\Validator;
// use Illuminate\Http\Exceptions\HttpResponseException;
// use App\Exceptions\CustomException;

// class AuthRegisterRequest extends FormRequest
// {
//     /**
//      * Determine if the user is authorized to make this request.
//      */
//     public function authorize(): bool
//     {
//         return true;
//     }

//     /**
//      * Get the validation rules that apply to the request.
//      *
//      * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
//      */
//     public function rules(): array
//     {
//         return $this->authRegisterRules();
//     }

//     private function postRules() {
//         $rules = [
//             'name' => 'required|string|max:255',
//             'username' => 'required|string|max:255|unique:users,username',
//             'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
//             'password' => 'required|string|min:8|confirmed',
//         ];
//         return $rules;
//     }

//     private function combinationRules() {
//         if (Request::isMethod('post')) {
//             $rules = $this->postRules();
//             return $rules;
//         }
//     }

//     private function authRegisterRules()
//     {
//         $rules = $this->combinationRules();
//         return $rules;
//     }

//     /**
//      * Get the custom error messages for the defined validation rules.
//      *
//      * @return array<string, string>
//      */
//     public function messages(): array
//     {
//         return [
//             'name.required' => 'The name field is required',
//             'name.string' => 'The name field should be string',
//         ];
//     }

//     // Directly handling valdation response from form request using HttpResponseException
//     // protected function failedValidation(Validator $validator)
//     // {
//     //     $response = response()->json([
//     //         'status' => 'failed',
//     //         'message' => 'Validation failed.',
//     //         'errors' => $validator->errors(),
//     //     ], 422);

//     //     throw new HttpResponseException($response);
//     // }

//     // Directly handling valdation response from form request using CustomException
//     protected function failedValidation(Validator $validator)
//     {
//         throw new CustomException([
//             'status' => 'failed',
//             'message' => 'User can\'t be registered',
//             'errors' => $validator->errors(),
//         ], 422);
//     }
// }