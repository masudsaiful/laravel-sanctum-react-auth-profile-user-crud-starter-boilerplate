<?php

namespace App\Http\Requests\Permission;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;

class PermissionRequest extends FormRequest
{
    /**
     * Determine if the model is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return $this->permissionRules();
    }

    /**
     * Define rules for POST requests (creating a new role).
     *
     * @return array
     */
    private function postRules() {
        $rules = [
            'user_id' => [ 'nullable','sometimes', 'array'], // user_id must be an array with at least one item when provide.
            'user_id.*' => ['nullable','sometimes','integer', 'numeric', 'exists:users,id'], // user_id must be valid users table IDs.
            'uuid' => ['string', 'required'],
            'role_id' => [
                'integer', 
                'numeric', 
                'required', 
                'exists:roles,id', // role must be valid roles table IDs.
                // Rule::unique('permissions')->where(function ($query) {
                //     return $query->where('model', request('model')); // Matching the 'model' field and uniqueness (role_id + model). Can't occured twice.
                // }),
                // Rule::unique('permissions')->where(function ($query) {
                //     $userIds = request('user_id', []);
                //     $query->where('role_id', request('role_id'))
                //           ->where('model', request('model'))
                //           ->where(function ($q) use ($userIds) {
                //               foreach ($userIds as $userId) {
                //                   $q->orWhereJsonContains('user_id', $userId);
                //               }
                //           });
                // }),
                Rule::unique('permissions')->where(function ($query) {
                    $query->where('role_id', request('role_id'))
                          ->where('model', request('model'));
                    if (request('user_id')) {
                        $userIds = request('user_id');
                        $query->where(function ($q) use ($userIds) {
                            foreach ($userIds as $userId) {
                                $q->orWhereJsonContains('user_id', $userId);
                            }
                        });
                    } else {
                        $query->whereNull('user_id');
                    }
                })
            ], 
            'model' => ['required', 'string'],
            'create' => ['boolean', 'nullable'],
            'update' => ['boolean', 'nullable'],
            'delete' => ['boolean', 'nullable'],
            'title' => ['string', 'nullable'],
            'note' => 'string|nullable',
        ];
        return $rules;
    }

    /**
     * Define rules for PUT requests (updating an existing role).
     *
     * @return array
     */
    private function putRules() {
        $rules = [
            'user_id' => [ 'nullable','sometimes', 'array'], // user_id must be an array with at least one item when provide.
            'user_id.*' => ['nullable','sometimes','integer', 'numeric', 'exists:users,id'], // user_id must be valid users table IDs.
        ];
        $rules['uuid'] = ['string', 'required'];
        $rules['role_id'] = [
            'integer', 
            'numeric', 
            'required', 
            'exists:roles,id', // role must be valid roles table IDs.;
            // Rule::unique('permissions')->where(function ($query) {
            //     return $query->where('model', request('model')); // Matching the 'model' field and uniqueness (role_id + model). Can't occured twice.
            // })->ignore(Request::input('id'),'id'),

            // Rule::unique('permissions')->where(function ($query) {
            //     $userIds = request('user_id', []);
            //     $query->where('role_id', request('role_id'))
            //           ->where('model', request('model'))
            //           ->where(function ($q) use ($userIds) {
            //               foreach ($userIds as $userId) {
            //                   $q->orWhereJsonContains('user_id', $userId);
            //               }
            //           });
            // })->ignore($this->route('permission'), 'id'), // Ignore the record being updated

            Rule::unique('permissions')->where(function ($query) {
                $query->where('role_id', request('role_id'))
                      ->where('model', request('model'));
                if (request('user_id')) {
                    $userIds = request('user_id');
                    $query->where(function ($q) use ($userIds) {
                        foreach ($userIds as $userId) {
                            $q->orWhereJsonContains('user_id', $userId);
                        }
                    });
                } else {
                    $query->whereNull('user_id');
                }
            })->ignore($this->route('permission'), 'id') // Ignore the record being updated
        ]; 
        $rules['model'] = ['required', 'string'];
        $rules['create'] = ['boolean', 'nullable'];
        $rules['update'] = ['boolean', 'nullable'];
        $rules['delete'] = ['boolean', 'nullable'];
        $rules['title'] = 'string|nullable';
        $rules['title'] = 'string|nullable';
        return $rules;
    }

    /**
     * Choose rules based on request method.
     *
     * @return array
     */
    private function combinationRules() {
        if (Request::isMethod('post')) {
            $rules = $this->postRules();
            return $rules;
        }

        if (Request::isMethod('put')) {
            $rules = $this->putRules();
            return $rules;
        }
    }

    /**
     * Define the combination rules
     *
     * @return array
     */
    private function permissionRules()
    {
        $rules = $this->combinationRules();
        return $rules;
    }

    /**
     * Customize the validation messages for this request.
     *
     * @return array
     */
    public function messages(): array
    {
        return [
            'role_id.reuired' => 'The role field must be required.',
            'role_id.unique' => 'Combination of Role, Model and/or User already exists.', 
            'user_id.array' => 'The user field must be an array when provided.',
            // Additional custom messages as needed.
        ];
    }

    /**
     * Filters to be applied to the input before validation.
     *
     * @return array
     */
    public function filters(): array
    {
        return [
            'model' => 'trim', // Filter to trim and convert to lowercase.
            'title' => 'trim', // Filter to trim and convert to lowercase.
            'note' => 'trim', // Filter to trim and convert to lowercase.
            // 'name' => 'trim|capitalize', // Filter to trim and capitalize name.
        ];
    }
}
