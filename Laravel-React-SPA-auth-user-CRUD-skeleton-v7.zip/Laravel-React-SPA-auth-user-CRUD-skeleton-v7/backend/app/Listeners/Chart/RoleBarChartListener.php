<?php

namespace App\Listeners\Chart;

use Illuminate\Contracts\Queue\ShouldQueue;

use App\Services\Chart\RoleBarChartUpdateService;
use App\Services\Chart\UserPieChartUpdateService;

class RoleBarChartListener implements ShouldQueue
{
    protected $roleBarChartService;
    protected $userPieChartService;

    /**
     * Create the event listener.
     */
    public function __construct(
        RoleBarChartUpdateService $roleBarChartService, 
        UserPieChartUpdateService $userPieChartService) {
        $this->roleBarChartService = $roleBarChartService;
        $this->userPieChartService = $userPieChartService;
    }

    /**
     * Handle the event.
     */
    public function handle($event): void
    {
        // $month = now()->month;
        // $year = now()->year;

        // if ($event instanceof UserEvent) {
        //     foreach ($event->user->roles as $role) {
        //         $this->service->updateRoleBarChart($role->id, $month, $year);
        //     }
        // } elseif ($event instanceof RoleEvent) {
        //     $this->service->updateRoleBarChart($event->role->id, $month, $year);
        // }

        $this->roleBarChartService->updateRoleBarChart($event);
        $this->userPieChartService->updateUserPieChart($event);
    }
}
