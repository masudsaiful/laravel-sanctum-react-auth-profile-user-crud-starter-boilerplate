<?php

namespace App\Observers\Role;

use App\Events\Role\RoleEvent;
use App\Models\Role\Role;

class RoleObserver
{
    /**
     * Handle the Role "created" event.
     */
    public function created(Role $role): void
    {
        // if ($role->status === [1]) {
        //     RoleEvent::dispatch($role);
        // }

        // RoleEvent::dispatch($role);
    }

    /**
     * Handle the Role "updated" event.
     */
    public function updated(Role $role): void
    {
        // if ($role->isDirty('status')) {
        //     RoleEvent::dispatch($role);
        // }

        RoleEvent::dispatch($role);
    }

    /**
     * Handle the Role "deleted" event.
     */
    public function deleted(Role $role): void
    {
        RoleEvent::dispatch($role, 'deleted');
    }

    /**
     * Handle the Role "restored" event.
     */
    public function restored(Role $role): void
    {
        //
    }

    /**
     * Handle the Role "force deleted" event.
     */
    public function forceDeleted(Role $role): void
    {
        //
    }
}
