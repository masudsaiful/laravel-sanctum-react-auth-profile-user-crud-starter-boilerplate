<?php

namespace App\Providers;

use Illuminate\Support\Facades\Event;
use Illuminate\Support\ServiceProvider;
// In AppServiceProvider.php
use Laravel\Sanctum\Sanctum;

use App\Models\User\User;
use App\Models\Role\Role;
use App\Listeners\Chart\RoleBarChartListener;


class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Observer can also be registered in boot method of the specific model.
        // User::observe(UserObserver::class);
        // Role::observe(RoleObserver::class);

        // For manually event registered
        // Event::listen(
        //     UserEvent::class,
        //     UserListener::class,
        //     RoleEvent::class,
        //     RoleListener::class,
        //     RoleBarChartListener::class,
        // );

        //Sanctum::ignoreCsrfToken(true);
        // config(['session.domain' => env('SESSION_DOMAIN', '.localhost:3000')]);
    }
}
