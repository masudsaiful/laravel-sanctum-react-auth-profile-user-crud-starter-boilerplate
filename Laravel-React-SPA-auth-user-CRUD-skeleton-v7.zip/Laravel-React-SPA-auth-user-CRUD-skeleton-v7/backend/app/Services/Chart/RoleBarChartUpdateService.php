<?php

namespace App\Services\Chart;

use Illuminate\Support\Str;

use App\Models\User\User;
use App\Events\Role\RoleEvent;
use App\Events\User\UserEvent;
use App\Models\Chart\RoleBarChart;
use App\Models\Chart\UserBarChart;
use App\Events\Chart\RoleBarChartDetachEvent;



class RoleBarChartUpdateService
{
    /**
     * Function to update role_bar_charts table.
     *
     * @var array<int, int, int>
     */
    public function updateRoleBarChart($event)
    {
        if ($event instanceof RoleEvent) {
            $this->handleRoleEvent($event);
        } elseif ($event instanceof UserEvent) {
            $this->handleUserEvent($event);
        } elseif ($event instanceof RoleBarChartDetachEvent) {
            $this->handleUserDetachEvent($event);
        }
    }

    /**
     * Handle RoleEvent by updating the role chart for role-based events.
     */
    protected function handleRoleEvent(RoleEvent $event)
    {
        // role_bar_charts table update if role enabled, updated and has attached users
        // Though status field is json array field type, use [] and whereJsonContains
        $role = $event->role;
        if ($role->users()->exists()) {
            if ($role->status === [1]) {
                $this->updateBulkRoleStatus($role->id, 'active');

                $userCount = $this->getActiveUserCountForRoleOfCurrDate($role);

                if ($userCount > 0) {
                    $this->storeRoleData($role->id, date('Y'), date('m'), 'active', $userCount);
                } else {
                    $this->storeRoleData($role->id, date('Y'), date('m'), 'nouser', 0);
                }

            } elseif ($role->status === [2]) {
                $this->updateBulkRoleStatus($role->id, 'disable');
            }

        } else {
            // Role deleted
            if ($event->action === 'deleted') {
                $this->updateBulkRoleStatus($role->id, 'delete');
            }
        }
    }

    /**
     * Handle UserEvent by updating the role chart for user-based events.
     */
    protected function handleUserEvent(UserEvent $event)
    {
        $user = $event->user;
        if ($event->action === 'saved') {
            // role_bar_charts table update if user hase status and user has attached role
            // Though status field is json array field type, use [] and whereJsonContains
            if ($user->roles()->exists() && $user->status === [1]) {
                foreach ($user->roles as $role) {
                    if ($role->status === [1]) {
                        $userCount = $this->getActiveUserCountForRoleOfCurrDate($role);
                        if ($userCount > 0) {
                            $this->storeRoleData($role->id, date('Y'), date('m'), 'active', $userCount);
                        }
                    }
                }  
            }
        }

        // Updating user_bar_charts table through user event
        if ($event->action === 'saved' || $event->action === 'deleted') {
            $userCounts = $this->getUserTypeCountForUserOfCurrDate($user);
            foreach ($userCounts as $key => $value) {
                // Laravel Str helper
                // Replace underscores with spaces
                // Capitalize the first letter of each word
                $userType = Str::of($key)->replace('_', ' ')->title(); 
                $this->storeUserData(date('Y'), date('m'), $userType, $value);
            }
        }

        // role_bar_charts table update if user hase status and user has attached role
        // Though status field is json array field type, use [] and whereJsonContains
        // $user = $event->user;
        // if ($user->status === [1] && $user->roles()->exists()) {
        //     foreach ($user->roles as $role) {
        //         if ($role->status === [1] && $role->users()->exists()) {
        //             $userCount = $role->users()->whereJsonContains('status', 1)->count();
        //             $this->storeRoleData($role->id, date('Y'), date('m'), $userCount);
        //         } else {
        //             $this->storeRoleData($role->id, date('Y'), date('m'), 0);
        //         }
                
        //         // // Check if the user event is a delete event
        //         // if ($user->wasDeleted) {
        //         //     // Adjust count for deleted user if status enabled only
        //         //     $userCount = max(0, $userCount - 1);
        //         // }

        //         // $this->storeRoleData($role->id, date('Y'), date('m'), $userCount);
        //     }
        // } else {
        //     foreach ($user->roles as $role) {
        //         if ($role->status === [1] && $role->users()->exists()) {
        //             $userCount = $role->users()->whereJsonContains('status', 1)->count();
        //             $this->storeRoleData($role->id, date('Y'), date('m'), $userCount);
        //         } else {
        //             $this->storeRoleData($role->id, date('Y'), date('m'), 0);
        //         }
        //     }
        // }
    }

    /**
     * Handle UserEvent by updating the role chart for user-based events.
     */
    protected function handleUserDetachEvent(RoleBarChartDetachEvent $event)
    {
        // Only status enabled data will be populated in role_bar_charts table
        // Though status field is json array field type, use [] and whereJsonContains
        $user = $event->user;
        if ($user->roles()->exists() && $user->status === [1]) {
            foreach ($user->roles as $role) {
                if ($role->status === [1]) {
                    $userCount = $this->getActiveUserCountForRoleOfCurrDate($role);
                    $userCount = max(0, $userCount - 1);
                    
                    $status = $userCount > 0 ? 'active' : 'nouser';
                    $this->storeRoleData($role->id, now()->year, now()->month, $status, $userCount);
                }
            }
        }
    }

    /**
     * Store or update the role chart data based on the role, year, and month.
     */
    protected function storeRoleData(int $roleId, string $year, string $month, string $status, int $userCount)
    {
        RoleBarChart::updateOrCreate(
            ['role_id' => $roleId, 'year' => $year, 'month' => $month],
            ['user_count' => $userCount, 'status' => $status]
        );
    }

    /**
     * Mass Update the role bar chart status based on the role_id.
     */
    protected function updateBulkRoleStatus(int $roleId, string $status)
    {
        RoleBarChart::where('role_id', $roleId)->update(['status' => $status]);
    }

    /**
     * Get the count of active users for a given role in the current year and month.
     */
    protected function getActiveUserCountForRoleOfCurrDate($role)
    {
        return $role->users()
            ->whereJsonContains('users.status', 1)
            ->whereYear('users.created_at', now()->year)
            ->whereMonth('users.created_at', now()->month)
            ->count();
    }

    /**
     * Store or update the chart data based on the type, year, and month.
     */
    protected function storeUserData(string $year, string $month, string $userType, int $userCount)
    {
        UserBarChart::updateOrCreate(
            ['user_type' => $userType, 'year' => $year, 'month' => $month],
            ['user_count' => $userCount]
        );
    }

    /**
     * Get the count of active users for a given user in the current year and month.
     */
    protected function getUserTypeCountForUserOfCurrDate($user)
    {
        $data = [];

        $data['active'] = User::whereJsonContains('status', 1)
            ->whereNull('deleted_at')
            ->whereYear('users.created_at', now()->year)
            ->whereMonth('users.created_at', now()->month)
            ->count();

        $data['disable'] = User::whereJsonContains('status', 2)
        ->whereNull('deleted_at')
        ->whereYear('users.updated_at', now()->year)
        ->whereMonth('users.updated_at', now()->month)
        ->count();

        $data['delete'] = User::withTrashed()
        ->whereNotNull('deleted_at')
        ->whereYear('deleted_at', now()->year)
        ->whereMonth('deleted_at', now()->month)
        ->count();

        $data['has_role'] = User::with(['roles' => function($q) {
            $q->whereJsonContains('status', 1);
        }])->whereNull('deleted_at')
        ->whereJsonContains('status', 1)
        ->whereYear('users.created_at', now()->year)
        ->whereMonth('users.created_at', now()->month)
        ->whereHas('roles', function($q) {
            $q->whereJsonContains('status', 1);
        })
        ->count();

        return $data;
    }
}
