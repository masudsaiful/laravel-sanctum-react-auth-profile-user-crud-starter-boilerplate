<?php

namespace App\Services\Chart;

use Illuminate\Support\Str;

use App\Models\User\User;
use App\Events\User\UserEvent;
use App\Models\Chart\UserPieChart;
use App\Events\Chart\RoleBarChartDetachEvent;



class UserPieChartUpdateService
{
    /**
     * Function to update role_bar_charts table.
     *
     * @var array<int, int, int>
     */
    public function updateUserPieChart($event)
    {
        if ($event instanceof UserEvent) {
            $this->handleUserEvent($event);
        }
    }

    /**
     * Handle UserEvent by updating the role chart for user-based events.
     */
    protected function handleUserEvent(UserEvent $event)
    {
        $user = $event->user;
        if ($event->action === 'saved' || $event->action === 'deleted') {
            $userCount = $this->getUserCount($user);
            $totalUsers = $userCount['total_users'];

            $deletedUsers = $userCount['deleted_users'];
            $deletedUserPercent = number_format((($deletedUsers * 100) / $totalUsers), 2);
            $deletedEnableUserPercent = number_format((($userCount['deleted_enable_users'] * 100) / $deletedUsers), 2);
            $deletedDisableUserPercent = number_format((($userCount['deleted_disable_users'] * 100) / $deletedUsers), 2);

            $existingUsers = $userCount['existing_users'];
            $existingUserPercent = number_format((($existingUsers * 100) / $totalUsers), 2);
            $existingEnableUserPercent = number_format((($userCount['existing_enable_users'] * 100) / $existingUsers), 2);
            $existingDisableUserPercent = number_format((($userCount['existing_disable_users'] * 100) / $existingUsers), 2);

            if ($totalUsers > 0) {
                $this->storeUserPieChartData(
                    $totalUsers, 
                    $deletedUsers, 
                    $existingUsers,
                    $deletedUserPercent,
                    $existingUserPercent,
                    $deletedEnableUserPercent,
                    $existingEnableUserPercent,
                    $deletedDisableUserPercent,
                    $existingDisableUserPercent,
                );
            }
        }
    }

    /**
     * Store or update the users to the user_pie_charts table.
     */
    protected function storeUserPieChartData(
        int $totalUsers, 
        int $deletedUsers, 
        int $existingUsers, 
        string $deletedUserPercent, 
        string $existingUserPercent, 
        string $deletedEnableUserPercent, 
        string $existingEnableUserPercent,
        string $deletedDisableUserPercent, 
        string $existingDisableUserPercent,
        )
    {
        UserPieChart::updateOrCreate(
            [
                'deleted_users' => $deletedUsers, 
                'existing_users' => $existingUsers, 
                'deleted_user_percent' => $deletedUserPercent,
                'existing_user_percent' => $existingUserPercent,
                'deleted_enable_user_percent' => $deletedEnableUserPercent,
                'existing_enable_user_percent' => $existingEnableUserPercent,
                'deleted_disable_user_percent' => $deletedDisableUserPercent,
                'existing_disable_user_percent' => $existingDisableUserPercent,
            ],
            ['total_users' => $totalUsers]
        );
    }

    /**
     * Get the count of the users as different states
     */
    protected function getUserCount($user)
    {
        $data = [];

        $data['total_users'] = User::withTrashed()->count();

        $data['deleted_users'] = User::withTrashed()
            ->whereNotNull('deleted_at')
            ->count();

        $data['existing_users'] = User::whereNull('deleted_at')
        ->count();

        $data['deleted_enable_users'] = User::withTrashed()
        ->whereNotNull('deleted_at')
        ->whereJsonContains('status', 1)
        ->count();

        $data['deleted_disable_users'] = User::withTrashed()
        ->whereNotNull('deleted_at')
        ->whereJsonContains('status', 2)
        ->count();

        $data['existing_enable_users'] = User::whereJsonContains('status', 1)
        ->whereNull('deleted_at')
        ->count();

        $data['existing_disable_users'] = User::whereJsonContains('status', 2)
        ->whereNull('deleted_at')
        ->count();

        return $data;
    }
}
