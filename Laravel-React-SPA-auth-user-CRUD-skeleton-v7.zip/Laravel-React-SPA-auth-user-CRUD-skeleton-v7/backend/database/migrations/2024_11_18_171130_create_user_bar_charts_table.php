<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_bar_charts', function (Blueprint $table) {
            $table->id();
            $table->string('user_type')->index();
            $table->integer('user_count')->default(0)->index();
            $table->unsignedTinyInteger('month')->nullable(); // nullable if only year-based data
            $table->year('year');
            $table->string('status')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_bar_charts');
    }
};
