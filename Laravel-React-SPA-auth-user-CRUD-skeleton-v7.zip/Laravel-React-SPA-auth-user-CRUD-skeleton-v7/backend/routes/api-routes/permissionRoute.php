<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Permission\PermissionController;

Route::middleware('auth:sanctum')
    ->namespace('Permission')
    ->group(function () {
        Route::apiResource('permissions', PermissionController::class);
    });
