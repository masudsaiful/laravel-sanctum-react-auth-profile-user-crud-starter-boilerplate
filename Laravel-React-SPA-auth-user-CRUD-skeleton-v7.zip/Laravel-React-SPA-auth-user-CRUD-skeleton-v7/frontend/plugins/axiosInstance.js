import axios from 'axios';
import apiUrl from "utilities/apiUrl"
import { logout } from 'auths/services/authService';

// Global lock to prevent repeated requests
// Specifically will effect disabled users to get logout automatically
let isCriticalErrorHandled = false; 

const axiosInstance = axios.create({
    // Adjust based of backend URL
    baseURL: `${apiUrl}/api`, 
    withCredentials: true,
    headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
    },
});

// Before request send axios intercept to config 
axiosInstance.interceptors.request.use(
    async (config) => {
        // Dynamically set base URL for CSRF token request
        if (config.url === '/sanctum/csrf-cookie') {
            config.baseURL = `${apiUrl}`;
        }
        
        const token = localStorage.getItem('auth_token');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Intercept incoming responses (optional: to handle errors globally)
axiosInstance.interceptors.response.use(
    (response) => {
        // Reset the lock on successful requests
        isCriticalErrorHandled = false;
        // Return response if successful
        return response;
    },

    // (error) => {
    //     // Handle common errors, e.g., 401 unauthorized
    //     if (error.response && error.response.status === 401) {
    //         console.error('Unauthorized: Redirecting to login.');
    //         // Handle logout or redirect here
    //     }
    //     return Promise.reject(error);
    // }

    async (error) => {
        const status = error.response?.status;

        // Handle critical errors
        if (status === 401 || status === 403) {
            if (!isCriticalErrorHandled) {
                console.error("Unauthorized or Forbidden: Logging out and redirecting to login.");
                // Set lock to prevent further requests
                isCriticalErrorHandled = true; 

                // Handle logout or redirection
                // Assuming logout function clears auth tokens
                await logout(); 
                window.location.href = "/auth/login";
            }
            // Suppress further errors related to unauthorized requests
            return Promise.reject(error);
        }

        // // Log other errors (optional)
        // if (!isCriticalErrorHandled) {
        //     console.error("Request failed:", error.response?.data || error.message);
        // }

        // Ensure error is propagated for specific handling
        return Promise.reject(error); 
    }
);

export default axiosInstance;
export {axios};
