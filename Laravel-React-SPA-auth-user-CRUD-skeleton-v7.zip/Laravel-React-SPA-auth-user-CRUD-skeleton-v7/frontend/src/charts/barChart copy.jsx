import React, { useState, useRef, useEffect } from "react"

import {Box, Button, Paper, Typography, Alert, CircularProgress} from '@mui/material';
import SaveAsTwoToneIcon from '@mui/icons-material/SaveAsTwoTone';
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
import HighlightOutlinedIcon from '@mui/icons-material/HighlightOutlined';
import RunningWithErrorsIcon from '@mui/icons-material/RunningWithErrors';
import CCMuiPieChart from "./mui-customization/ccMuiPieChart";
import { 
  ccBgColor,
  ccVar7Color,
  CCButtonSky,
  ccBgVar1Color,
} from "components/mui-customizations/styleCustomization";
import CCMuiBarChart from "charts/mui-customization/ccMuiBarChart";

import axiosInstance from "plugins/axiosInstance";
import { useError } from "errors/errorHook";
import ChartFields from "charts/chartFields";
import wordsUpperCase from "utilities/wordsUpperCase";


// Init chart states
const initChartStates = {
  type: ['roles'],
  period: [1],
  particulars: [],
  years: [],
}

// Init errors
const initErrors = {
  errors: {
    type: '',
    period: '',
  }
}

const BarChart = () => {
  // Error state
  const [errorState, setErrorState] = useState(initErrors);

  // Error context errors to display 
  const {ccGetError} = useError();

  // Chart state
  const [chartState, setChartState] = useState(initChartStates);

  // Show, hide datas
  const [showAllDynamicItems, setShowAllDynamicItems] = useState(false);
  const [showAllYears, setShowAllYears] = useState(false);
  const [showLoading, setShowLoading] = useState(false);

  // From API record states
  const [dataset, setDataset] = useState([]);
  const [isDataset, setIsDataset] = useState(false);

  const handleSubmit = async (e = null) => {
    if (e) e.preventDefault(); // Only prevent default if event exists
  
    // Check for validation errors
    if (Object.keys(errorState.errors).filter((key) => errorState.errors[key]).length > 0) {
      await ccGetError(errorState);
      setIsDataset(false);
    } else {
      try {
        setShowLoading(true);
        const result = await axiosInstance.post(`/${chartState.type[0]}/bar/charts`, chartState);
        if (result.data.status === "success") {
          setDataset(result.data.dataset);
          setIsDataset(true);
        } else {
          await ccGetError(result);
        }
      } catch (error) {
        await ccGetError(error);
      } finally {
        setShowLoading(false); // Ensure loading spinner is hidden
      }
    }
  };

  const handleCancel = () => {
    setChartState ( prevState => ({
      ...prevState,
      ...initChartStates,
    }));
    setShowAllDynamicItems(false);
    setShowAllYears(false);
    setErrorState(initErrors);
    setIsDataset(false);
  }

  // Fetch data when the component loads (default values)
  useEffect(() => {
    handleSubmit();
  }, []);

  return (
    <ChartFields 
      initChartStates={initChartStates}
      errorState={errorState} 
      setErrorState={setErrorState}
      chartState={chartState} 
      setChartState={setChartState}
      showAllDynamicItems={showAllDynamicItems}
      setShowAllDynamicItems={setShowAllDynamicItems}
      showAllYears={showAllYears}
      setShowAllYears={setShowAllYears}
      setIsDataset={setIsDataset}
    >
      {/* Save, Cancel Button */}
      <Box 
        sx={{
          gridColumn: {
            xs: 'span 12',
            sm: 'span 12',
            md: 'span 3',
            lg: 'span 3',
            xl: 'span 3',
          // textAlign: 'center'
          }
        }}
      >
        <CCButtonSky 
          startIcon={<SaveAsTwoToneIcon />}
          endIcon=""
          onClick={handleSubmit}
          sx={{
            ml: 0,
            px: 1.5,
          }}
        >
          Submit
        </CCButtonSky>

        <Button 
          startIcon={<CancelOutlinedIcon />}
          sx={{
            px: 1.5,
            ml: 1,
            color: 'white',
            bgcolor: ccVar7Color, 
            ":hover": {
              backgroundColor: ccBgColor,
            },
          }}
          onClick={handleCancel}
        >
          Cancel
        </Button>
      </Box>
      {/* End Save, Cancel Button */}

      {/* Chart dataset */}
      <Box 
        sx={{
          gridColumn: {
            xs: 'span 12',
            sm: 'span 12',
            md: 'span 3',
            lg: 'span 3',
            xl: 'span 3',
          },
        }}
      >
        {isDataset && dataset && dataset.length > 0 && (
          <Paper 
            elevation={3}
            sx={{
              padding: "10px",
              background: ccBgVar1Color,
              mt:3
            }}
          >
            <Typography 
              variant="subtitle2" 
              textAlign="center"
              color={ccBgColor}
              mt={0.5}
            >
              {
              `${wordsUpperCase(chartState.type[0]) || ''} based  ${chartState.period && chartState.period[0] === 1 ? ' monthly' : ' yearly'} users`
              } 
            </Typography>
            <Typography 
              variant="body2" 
              textAlign="center"
              color={ccBgColor}
              mb={3}
              fontSize={12}   
            >
              (
                <HighlightOutlinedIcon 
                  sx={{ 
                    fontSize: 14, 
                    verticalAlign: 'middle', 
                    color:ccVar7Color,
                    mr: 0.5,
                  }} 
                /> 
                Datas, based on availability, based on {new Date().getFullYear()} if no year selected.)
            </Typography>
            <CCMuiBarChart dataset={dataset} />
          </Paper>
        )}

        {/* Circular Progress Loader */}
        {showLoading && (
          <Box
            display="flex"
            justifyContent="center"
            alignItems="center"
          >
            <CircularProgress sx={{ color: '#7fafcc' }} />
          </Box>
          // <Typography 
          //   variant="subtitle1" 
          //   textAlign="center"
          //   mt={5}
          //   p={1}
          //   color={ccVar7Color}
          //   border={1}
          // >
          //   <RunningWithErrorsIcon                   
          //     sx={{ 
          //       fontSize: 20, 
          //       verticalAlign: 'middle', 
                
          //       mr: 0.5,
          //     }}  
          //   />
          //   No dataset found
          // </Typography>

        )}
      </Box>
    </ChartFields>
  )
}

export default BarChart;