import * as React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Slider from '@mui/material/Slider';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import { PieChart } from '@mui/x-charts/PieChart';

// Define the color palette
const colorPalette = [
  '#219B9D', '#9EDF9C', '#7ED4AD', '#4CC9FE', '#E4B1F0', '#A594F9', '#CCD5AE', '#95D2B3',
];

// Data
const deletedUsersType = [
  { label: 'Deleted Enable', value: 70.48 },
  { label: 'Deleted Disable', value: 28.8 },
];

const existingUsersType = [
  { label: 'Existing Enable', value: 72.72 },
  { label: 'Existing Disable', value: 16.38 },
];

const users = [
  { label: 'Deleted Users', value: 59.12 },
  { label: 'Existing Users', value: 40.88 },
];

const normalize = (v, v2) => Number.parseFloat(((v * v2) / 100).toFixed(2));

const deletedExistingUsers = [
  ...deletedUsersType.map((v) => ({
    ...v,
    label: v.label,
    value: normalize(v.value, users[0].value),
  })),
  ...existingUsersType.map((v) => ({
    ...v,
    label: v.label,
    value: normalize(v.value, users[1].value),
  })),
  ...users.map((v) => ({
    ...v,
    label: v.label,
    value: v.value,
  })),
];

const valueFormatter = (item) => `${item.value}%`;

const size = { height: 400 };

const CCMuiPieChart = () => {
  const [radius, setRadius] = React.useState(50);
  const [itemNb, setItemNb] = React.useState(5);
  const [skipAnimation, setSkipAnimation] = React.useState(false);

  const handleItemNbChange = (event, newValue) => {
    if (typeof newValue !== 'number') return;
    setItemNb(newValue);
  };

  const handleRadius = (event, newValue) => {
    if (typeof newValue !== 'number') return;
    setRadius(newValue);
  };

  return (
    <Box sx={{ width: '100%' }}>
      <PieChart
        margin={{ top: 80 }}
        {...size}
        series={[
          {
            data: deletedExistingUsers.slice(0, itemNb),
            innerRadius: radius,
            arcLabel: (params) => params.label ?? '',
            arcLabelMinAngle: 20,
            valueFormatter,
            color: colorPalette, // Apply color palette here
          },
        ]}
        skipAnimation={skipAnimation}
        slotProps={{
          legend: {
            direction: 'row',
            position: { vertical: 'top', horizontal: 'middle' },
            padding: 0,
            itemGap: 10,
            markGap: 5,
            itemMarkWidth: 20,
            itemMarkHeight: 13,
            itemNumber: 20,
            labelStyle: { fontSize: 16 },
          },
        }}
      />
      <FormControlLabel
        checked={skipAnimation}
        control={
          <Checkbox onChange={(event) => setSkipAnimation(event.target.checked)} />
        }
        label="skipAnimation"
        labelPlacement="end"
      />
      <Typography id="input-item-number" gutterBottom>
        Number of items
      </Typography>
      <Slider
        value={itemNb}
        onChange={handleItemNbChange}
        valueLabelDisplay="auto"
        min={1}
        max={6}
        aria-labelledby="input-item-number"
      />
      <Typography id="input-radius" gutterBottom>
        Radius
      </Typography>
      <Slider
        pl={2}
        value={radius}
        onChange={handleRadius}
        valueLabelDisplay="auto"
        min={15}
        max={100}
        aria-labelledby="input-radius"
      />
    </Box>
  );
};

export default CCMuiPieChart;
