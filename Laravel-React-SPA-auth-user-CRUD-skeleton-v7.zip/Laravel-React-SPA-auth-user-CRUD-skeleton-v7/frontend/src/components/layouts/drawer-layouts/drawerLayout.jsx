import React, { useState } from 'react';
import { styled, useTheme } from '@mui/material/styles';
import MuiAppBar from '@mui/material/AppBar';
import MenuIcon from '@mui/icons-material/Menu';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import {
  Grid,
  Box,
  Drawer,
  Typography,
  IconButton,
  CssBaseline,
  Toolbar,
  CircularProgress,
} from "@mui/material";
import {
  ccBgColor,
  ccBgVar1Color,
  ccAreaBgColor,
  ccCommonGap,
  ccVar2CommonGap,
  ccVar3CommonGap,
} from "components/mui-customizations/styleCustomization";

import { useAuth } from 'auths/hooks/authHook';
import Content from 'components/layouts/content';
import Footer from 'components/layouts/footer';
import Header from 'components/layouts/header';
import Menu from "components/layouts/menu";

// Define drawer widths based on breakpoints
const drawerWidths = {
  xs: 160,
  sm: 180,
  md: 200,
  lg: 220,
  xl: 220,
};

// Optimized function to calculate drawer width dynamically
const getDrawerWidth = (theme) => {
  const width = theme.breakpoints.values;
  const screenWidth = window.innerWidth;

  if (screenWidth < width.sm) return drawerWidths.xs; // Extra small
  if (screenWidth < width.md) return drawerWidths.sm; // Small
  if (screenWidth < width.lg) return drawerWidths.md; // Medium
  if (screenWidth < width.xl) return drawerWidths.lg; // Large
  if (screenWidth >= width.xl) return drawerWidths.xl; // Large
  return drawerWidths.md; // Extra large and above
};

// Styled main content area
const Main = styled('main', { shouldForwardProp: (prop) => prop !== 'open' })(
  ({ theme, open }) => ({
    flexGrow: 1,
    padding: theme.spacing(12.5, 0, 2, 0),
    marginLeft: open ? 0 : `-${getDrawerWidth(theme)}px`,
    transition: theme.transitions.create(['margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    ...(open && {
      width: `calc(100% - ${getDrawerWidth(theme)}px)`, // Open state
      transition: theme.transitions.create(['margin'], {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
      marginLeft: 0,
    }),
  })
);

// Styled AppBar
const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== 'open',
})(({ theme, open }) => ({
  transition: theme.transitions.create(['margin', 'width'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    width: `calc(100% - ${getDrawerWidth(theme)}px)`,
    marginLeft: `${getDrawerWidth(theme)}px`,
    transition: theme.transitions.create(['margin', 'width'], {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

// Drawer header styling
const DrawerHeader = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: theme.spacing(0, 1),
  ...theme.mixins.toolbar,
  justifyContent: 'flex-end',
}));

const DrawerLayout = () => {
  const { isProfile, profileLoading } = useAuth();
  const theme = useTheme();
  const [open, setOpen] = useState(true);

  const handleDrawerOpen = () => setOpen(true);
  const handleDrawerClose = () => setOpen(false);

  if (profileLoading) {
    return (
      <>
        <CssBaseline />
        <Box
          display="flex"
          justifyContent="center"
          alignItems="center"
          height="100vh"
          bgcolor={ccBgColor}
        >
          <CircularProgress sx={{ color: ccAreaBgColor }} />
        </Box>
      </>
    );
  }

  return (
    <>
      <CssBaseline />
      <Box sx={{ display: 'flex', minHeight: '100vh' }} bgcolor={ccBgColor}>
        {/* Header and Drawer Menu */}
        {isProfile && (
          <>
            <AppBar 
              position="fixed" 
              open={open} 
              sx={{ 
                bgcolor: 'transparent', 
                boxShadow: 'unset' 
              }}
            >
              <Header>
                <Toolbar sx={{ flexGrow: 1, pl: '12px!important' }}>
                  <IconButton
                    color="inherit"
                    aria-label="open drawer"
                    onClick={handleDrawerOpen}
                    edge="start"
                    sx={{ mr: 2, ...(open && { display: 'none' }) }}
                  >
                    <MenuIcon />
                  </IconButton>
                  <Typography variant="h6" noWrap component="div">
                    {/* Persistent Drawer */}
                  </Typography>
                </Toolbar>
              </Header>
            </AppBar>

            <Drawer
              sx={{
                width: getDrawerWidth(theme),
                flexShrink: 0,
                '& .MuiDrawer-paper': {
                  width: getDrawerWidth(theme),
                  boxSizing: 'border-box',
                  bgcolor: ccBgVar1Color,
                },
              }}
              variant="persistent"
              anchor="left"
              open={open}
            >
              <DrawerHeader
                sx={{
                  minHeight: "0px!important"
                }}
              >
                <IconButton   
                  onClick={handleDrawerClose}
                  sx={{
                    py:0.3
                  }}
                >
                  {theme.direction === 'ltr' ? <ChevronLeftIcon /> : <ChevronRightIcon />}
                </IconButton>
              </DrawerHeader>
              <Menu />
            </Drawer>
          </>
        )}

        {/* Main Content */}
        <Main open={open}>
          <DrawerHeader />
          <Grid 
            container 
            spacing={ccCommonGap}
          >
            <Grid 
              item xs={12} 
              mb={ccVar3CommonGap}
            >
              <Grid
                item
                pr={{ 
                  xs:ccVar2CommonGap,
                  sm: ccCommonGap, 
                  md: ccCommonGap, 
                  lg: ccCommonGap, 
                  xl: ccCommonGap,
                }}
                pl={{
                  xs:ccVar2CommonGap,
                  sm: ccCommonGap,
                }}
                xs={12}
                sm={12}
                md={12}
                lg={12}
                xl={12}
              >
                <Content />
              </Grid>
            </Grid>
          </Grid>
        </Main>
        {/* Content */}
        {/* Footer conent */}
        {isProfile && (
          <AppBar 
            position="fixed" 
            open={open} 
            sx={{ 
              alignItems: 'center' 
            }}
          >
            <Footer />
          </AppBar>
        )}
        {/* End footer content */}
      {/* </Container> */}
      </Box>
    </>
  );
};

export default DrawerLayout;
