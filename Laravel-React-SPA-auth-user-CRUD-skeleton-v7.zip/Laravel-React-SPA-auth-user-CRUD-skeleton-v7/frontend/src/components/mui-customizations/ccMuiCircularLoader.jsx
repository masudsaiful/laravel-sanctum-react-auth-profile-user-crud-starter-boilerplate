import { CircularProgress, CssBaseline, Box } from "@mui/material"
import { ccAreaBgColor, ccBgColor } from "./styleCustomization";

const CCMuiCircularLoader = (props) => {

  return (
    <Box
      display="flex"
      justifyContent="center"
      alignItems="center"
      bgcolor={ccBgColor}
      {...props}
    >
      <CircularProgress 
        sx={{ 
          color: ccAreaBgColor,
          ...props.sx
        }} 
      />
    </Box>
  )
}

export {CCMuiCircularLoader};