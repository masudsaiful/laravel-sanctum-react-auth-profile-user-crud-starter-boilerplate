import { memo, useCallback } from 'react';

import { Box, Chip, MenuItem, Select } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import { ccVar2Color, ccLargeFontColor } from "components/mui-customizations/styleCustomization";

import CCMuiTooltip from 'components/mui-customizations//ccMuiTooltip';

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

function getStyles(currentItemValue, selectedItemsValue, theme) {
  return {
    fontWeight:
      selectedItemsValue.indexOf(currentItemValue) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}

const CCMuiMultiSelectAutoComplete = memo(({ ...props }) => {
  const theme = useTheme();

  const ccMultiSelectStyle = useCallback((props) => {
    return {
      fieldset: {
        borderColor: ccVar2Color + "!important",
        color: ccVar2Color + "important",
      },
      label: {
        color: ccVar2Color,
        "&:hover": {
          color: ccLargeFontColor + "!important",
        },
      },
      ...props.sx,
    };
  }, [props.sx]);

  const renderValue = (selected) => (
    <>
    {/* <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
      {selected.map((selectedValue) => (
        props.items.filter(itemValue => itemValue.id === selectedValue).map(itemValue => (
          <Chip key={itemValue.id} label={itemValue.value} sx={{ height: "23px" }} />
        ))
      ))}
    </Box> */}
    <CCMuiTooltip content={props.items.filter(filterItem => selected.includes(filterItem.id))} title="Selected item(s)" />
    </>
  );

  return (
    <Select
      onChange={props.onChange}
      renderValue={renderValue}
      MenuProps={MenuProps}
      sx={ccMultiSelectStyle(props)}
      {...props}
    >
      {props.placeholder && (
        <MenuItem disabled value="" sx={{ color: 'green' }}>
          <em>{props.placeholder}</em>
        </MenuItem>
      )}
      {props.items.map((currentItem) => (
        <MenuItem
          key={`${currentItem.id}-${currentItem.value}`} // Ensure each MenuItem has a unique key
          value={currentItem.id}
          style={getStyles(currentItem.id, props.value, theme)}
        >
          {currentItem.value}
        </MenuItem>
      ))}
      {props.children}
    </Select>
  );
});

export default CCMuiMultiSelectAutoComplete;
