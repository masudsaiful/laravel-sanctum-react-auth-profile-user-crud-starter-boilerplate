import { memo, useCallback } from 'react';

import { Box, Chip, MenuItem, Select } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import { ccVar2Color, ccLargeFontColor } from "components/mui-customizations/styleCustomization";

import CCMuiTooltip from 'components/mui-customizations//ccMuiTooltip';


const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;

const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

function getStyles(currentItemValue, selectedItemsValue, theme) {
  return {
    fontWeight:
      [selectedItemsValue].indexOf(currentItemValue) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
    backgroundColor: [selectedItemsValue].indexOf(currentItemValue) !== -1 ? 'lightblue' : 'transparent', // Add background color on selection
  };
}


const CCMuiSingleSelectAutoComplete = memo(({ ...props }) => {
  const theme = useTheme();

  const ccSingleSelectStyle = useCallback((props) => {
    return {
      fieldset: {
        borderColor: ccVar2Color + "!important",
        color: ccVar2Color + "important",
      },
      label: {
        color: ccVar2Color,
        "&:hover": {
          color: ccLargeFontColor + "!important",
        },
      },
      ...props.sx,
    };
  }, [props.sx]);

  const renderValue = (selected) => (
    <>
    {/* <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
      {props.items.filter(itemValue => itemValue.id === (Number(selected) || String(selected))).map(itemValue => (
        <Chip key={itemValue.id} label={itemValue.value} sx={{ height: "23px", backgroundColor: 'lightgray' }} />  // Add background color to Chip
      ))}
    </Box> */}
    <CCMuiTooltip content={props.items.filter(itemValue => itemValue.id === (Number(selected) || String(selected)))} title="Selected item(s)" />
    </>
  );

  return (
    <Select
      {...props}
      onChange={props.onChange}
      renderValue={renderValue}
      MenuProps={MenuProps}
      sx={ccSingleSelectStyle(props)}
    >
      {props.items.map((currentItem) => (
        <MenuItem
          key={`${currentItem.id}-${currentItem.value}`}  // Ensure each MenuItem has a unique key
          value={currentItem.id}
          style={getStyles(currentItem.id, props.value, theme)} // Apply custom styles based on selection
        >
          {currentItem.value}
        </MenuItem>
      ))}
      {props.children}
    </Select>
  );
});

export default CCMuiSingleSelectAutoComplete;
