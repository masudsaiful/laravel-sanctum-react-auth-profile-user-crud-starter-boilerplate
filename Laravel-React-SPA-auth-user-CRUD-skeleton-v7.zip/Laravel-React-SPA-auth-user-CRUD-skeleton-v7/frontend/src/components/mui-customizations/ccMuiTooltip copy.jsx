import * as React from 'react';
import { styled } from '@mui/material/styles';
import { tooltipClasses } from '@mui/material/Tooltip';
import { Tooltip, Divider, Button, Box, Paper, List, ListItem, ListItemText } from '@mui/material';
import Typography from '@mui/material/Typography';

import { 
  ccBgVar2Color, 
  ccBgColor, 
  ccCloudySky,
} from 'components/mui-customizations/styleCustomization';

// Styled tooltip
const HtmlTooltip = styled(({ className, ...props }) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: `${ccBgVar2Color}`,
    color: `${ccBgColor}`,
    maxWidth: 220,
    fontSize: theme.typography.pxToRem(12),
    border: `1px solid ${ccBgColor}`,
  },
}));

const CCMuiTooltip = ({ content, title }) => {
  const positionRef = React.useRef({ x: 0, y: 0 });
  const popperRef = React.useRef(null);
  const areaRef = React.useRef(null);

  const handleMouseMove = (event) => {
    positionRef.current = { x: event.clientX, y: event.clientY };
    if (popperRef.current) {
      popperRef.current.update();
    }
  };

  // Safeguard against mapping content
  const contentListItems = content.map((item) => (
    <ListItem 
      alignItems="flex-start" 
      dense 
      disablePadding 
      disableGutters 
      divider 
      key={item.id}
      sx={{ py: 0, my: 0 }}
    >
      <ListItemText sx={{ py: 0, my: 0 }}>
        <Typography variant="subtitle2" sx={{ py: 0, my: 0 }}>
          {(item?.name ?? '') || (item?.value ?? '') || (item?.title ?? '')}
        </Typography>
      </ListItemText>
    </ListItem>
  ));

  return (
    <HtmlTooltip
      title={
        <>
          <Typography variant="h6" color={ccBgColor} sx={{ fontSize: '0.9rem' }}>{title}</Typography>
          <Divider />
          <List disablePadding>{contentListItems}</List>
        </>
      }
      placement="top"
      arrow
      slotProps={{
        popper: {
          popperRef,
          anchorEl: {
            getBoundingClientRect: () => {
              if (areaRef.current) {
                const rect = areaRef.current.getBoundingClientRect();
                return new DOMRect(
                  positionRef.current.x,
                  rect.top,
                  0,
                  0
                );
              }
              return new DOMRect(0, 0, 0, 0);
            },
          },
        },
      }}
    >
      <Box
        sx={{
          display: 'inline-flex',
          flexDirection: 'row',
        }}
      >
        {content.map((item) => (
          <Paper
            key={item.id}
            ref={areaRef}
            onMouseMove={handleMouseMove}
            sx={{ 
              display: 'flex',
              alignSelf: 'center',
              justifyContent: 'center',
              flexGrow: 1,
              lineHeight: 'normal',
              bgcolor: `${ccCloudySky}c9`, 
              color: 'primary.contrastText',
              px: 1,
              py: 0,
              fontSize: '0.75rem',
            }}
          >
            {(item?.title ?? '') || (item?.name ?? '') || (item?.value ?? '')}
          </Paper>
        ))}
      </Box>
    </HtmlTooltip>
  );
};

export default CCMuiTooltip;
