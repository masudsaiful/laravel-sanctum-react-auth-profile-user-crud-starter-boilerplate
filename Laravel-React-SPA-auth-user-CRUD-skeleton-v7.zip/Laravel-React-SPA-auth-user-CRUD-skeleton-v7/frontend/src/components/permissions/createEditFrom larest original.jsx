import React, {useEffect, useState, useCallback, useMemo, lazy, memo } from "react"
import { useNavigate } from "react-router-dom";

import {Box, Button} from '@mui/material';
import SaveAsTwoToneIcon from '@mui/icons-material/SaveAsTwoTone';
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
import { 
  ccBgColor,
  ccSubBgColor,
  ccBgVar1Color,
  ccBgVar2Color,
  ccVar7Color,
  ccLargeFontColor,
  CCButtonSky,
  CCButtonGreen,
} from "components/mui-customizations/styleCustomization";

import {v4 as uuidv4} from 'uuid';

import axiosInstance from "plugins/axiosInstance";
import { useRole } from "components/roles/roleContext";
import { useRoleDispatch } from "components/roles/roleContext";
import { useError } from "errors/errorHook";
import wordsUpperCase from "utilities/wordsUpperCase";
import wordsSeperateByUpperCase from "utilities/wordsSeperateByUpperCase";
import { swalLWithZIndexAlert } from "components/swal-customizations/styleCustomization";
import Swal from "sweetalert2";
import { CCMuiCircularLoader } from "components/mui-customizations/ccMuiCircularLoader";

const PermissionFields = lazy(() => import("components/permissions/permissionFields"));

const v4Uuid = uuidv4();

// Init permission states
const initPermissionStates = [{
  id: '',
  uuid: v4Uuid,
  role_id: "",
  model: "",
  user_id: [],
  create: false,
  update: false,
  delete: false,
  title: "",
  note: "",
}]

// Init permission states
const initErrors = [{
  uuid: v4Uuid,
  user_id: '',
  role_id: '',
  model: "",
}]

const CreateEditForm = memo(() => {
  // Initial repeatable permission states
  const [permissionStates, setPermissionStates] = useState(initPermissionStates);
  
  // Initial repeatable error states
  const [errorStates, setErrorStates] = useState(initErrors);

  // Permission state datas
  const [roles, setRoles] = useState([]);
  const [models, setModels] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);

  // Error context to display errors
  const {ccGetError} = useError();

  // Generating repeatable states form while adding permissions
  // Generating corresponding error states while adding permissions
  // Ensure each time new uuid while adding permissions
  const handleAddPermission = () => {
    const v4Uuid = uuidv4();
    setPermissionStates((prev) => [
      ...prev,
      {
        id: '',
        uuid: v4Uuid,
        title: "",
        note: "",
        create: false,
        update: false,
        delete: false,
        role_id: "",
        model: "",
        user_id: [],
      },
    ]);

    setErrorStates((prev) => [
      ...prev,
      {
        uuid: v4Uuid,
        user_id: '',
        role_id: '',
        model: "",
      },
    ]);
  };

  // Submit permission
  // const handleSubmitPermission = (uuid) => {
  //   const findPermission = [...permissionStates];
  //   const locatePermission = findPermission.find(item=>item.uuid === uuid);
  //   console.log("Submitting Permission:", locatePermission);
  // };

  const handleEditPermission = useCallback(async (uuid) => {
    // Fetch errors if any otherwise triggering to submit
    const findError = [...errorStates];
    const locateError = findError.find(item=>item.uuid === uuid);

    if (Object.keys(locateError).filter(key => key != 'uuid' && locateError[key]).length > 0) {
      await ccGetError({errors: locateError});
      setLoading(false)

    } else {
      try {
        const findPermission = [...permissionStates];
        const locatePermission = findPermission.find(item=>item.uuid === uuid);
        // console.log('masudpermission', locatePermission)
        const result = await axiosInstance.put(`/permissions/${locatePermission.id}`, locatePermission)
        if(result.data.status === "success" ) {
          swalLWithZIndexAlert.fire({
            title: `${wordsUpperCase(result.data.status)}!`, 
            text: result.data.message, 
            icon: "success",
            iconColor: ccLargeFontColor,
            color: ccLargeFontColor,
            confirmButtonColor: ccLargeFontColor,
            background: ccBgVar1Color,
            timer: 1500,
          })
        } else {
          await ccGetError(result)
        }
      } catch (error) {
        await ccGetError(error)
      }
    }
  }, [permissionStates])

  const handleCreatePermission = async (uuid) => {
    // Fetch errors if any otherwise triggering to submit
    const findError = [...errorStates];
    const locateError = findError.find(item=>item.uuid === uuid);

    if (Object.keys(locateError).filter(key => key != 'uuid' && locateError[key]).length > 0) {
      await ccGetError({errors: locateError});
      setLoading(false);

    } else {
      try {
        const findPermission = [...permissionStates];
        const locatePermission = findPermission.find(item=>item.uuid === uuid);
        // console.log('masudpermission', locatePermission)
        const result = await axiosInstance.post('/permissions', locatePermission)
        if(result.data.status === "success" ) {
          swalLWithZIndexAlert.fire({
            title: `${wordsUpperCase(result.data.status)}!`, 
            text: result.data.message, 
            icon: "success",
            iconColor: ccLargeFontColor,
            color: ccLargeFontColor,
            confirmButtonColor: ccLargeFontColor,
            background: ccBgVar1Color,
            timer: 1500,
          }).then(() => {
            fetchDatas(); // Refreshing datas after created permission
          })
        } else {
          console.log(result)
          await ccGetError(result)
        }
      } catch (error) {
        console.log(error)
        await ccGetError(error)
      }
    }
  }

  const fetchDatas = useCallback(async () => {
    try {
      setLoading(true);
      const [rolesResponse, permissionsResponse, usersResponse] = await Promise.all([
        axiosInstance.get("/roles"),
        axiosInstance.get("/permissions"),
        axiosInstance.get("/users"),
      ]);

      rolesResponse && rolesResponse.data && rolesResponse.data.allRoles && (
        setRoles(
          rolesResponse?.data?.allRoles?.map((role) => ({
            id: role.id,
            label: role.title,
            value: role.title,
          })) || []
        )
      );

      setModels(
        permissionsResponse.data.permissionModels.modelNames.map((model) => ({
          id: model,
          label: model,
          value: wordsSeperateByUpperCase(model),
        }) || [])
      );

      usersResponse && usersResponse.data && usersResponse.data.allUsers && (
        setUsers(
          usersResponse.data.allUsers.map((user) => ({
            id: user.id,
            label: user.name,
            value: user.name,
          }) || [])
        )
      );

      // Set permission states with proper mapping for relational data
      if (permissionsResponse.data.permissions?.length > 0) {
        const formattedPermissions = permissionsResponse.data.permissions.map((permission) => ({
          id: permission.id || "",
          uuid: permission.uuid || v4Uuid,
          role_id: permission.role_id || "",
          model: permission.model || "",
          user_id: permission.user_id || [],
          create: permission.create || false,
          update: permission.update || false,
          delete: permission.delete || false,
          title: permission.title || "",
          note: permission.note || "",
        }));

        const formattedErrors = permissionsResponse.data.permissions.map((permission) => ({
          uuid: permission.uuid || v4Uuid,
          user_id: "",
          role_id: "",
          model: "",
        }));

        // Update state
      setPermissionStates(formattedPermissions);
      setErrorStates(formattedErrors);
      } else {
        await ccGetError({errors: 'no permissons data found in response'});
      }

    } catch (error) {
      await ccGetError(error);
    } finally {
      setLoading(false);
    }
  }, [ccGetError]); // Recreate the callback when contextual changes

  // Memoized roles, models, and users
  // useMemo prevents unnecessary re-renders
  // will not recalculate unless their dependency changes
  const memoizedRoles = useMemo(() => roles, [roles]);
  const memoizedModels = useMemo(() => models, [models]);
  const memoizedUsers = useMemo(() => users, [users]);

  // Load permission state datas
  useEffect(() => {
    // const fetchDatas = async () => {
    //   try {
    //     const [rolesResponse, permissionsResponse, usersResponse] = await Promise.all([
    //       axiosInstance.get("/roles"),
    //       axiosInstance.get("/permissions"),
    //       axiosInstance.get("/users"),
    //     ]);

    //     setRoles(
    //       rolesResponse.data.allRoles.map((role) => ({
    //         id: role.id,
    //         label: role.title,
    //         value: role.title,
    //       }))
    //     );

    //     setModels(
    //       permissionsResponse.data.permissionModels.modelNames.map((model) => ({
    //         id: model,
    //         label: model,
    //         value: wordsSeperateByUpperCase(model),
    //       }))
    //     );

    //     setUsers(
    //       usersResponse.data.allUsers.map((user) => ({
    //         id: user.id,
    //         label: user.name,
    //         value: user.name,
    //       }))
    //     );

    //     // Set permission states with proper mapping for relational data
    //     if (permissionsResponse.data.permissions?.length > 0) {
    //       const formattedPermissions = permissionsResponse.data.permissions.map((permission) => ({
    //         id: permission.id || "",
    //         uuid: permission.uuid || v4Uuid,
    //         role_id: permission.role_id || "",
    //         model: permission.model || "",
    //         user_id: permission.user_id || [],
    //         create: permission.create || false,
    //         update: permission.update || false,
    //         delete: permission.delete || false,
    //         title: permission.title || "",
    //         note: permission.note || "",
    //       }));

    //       const formattedErrors = permissionsResponse.data.permissions.map((permission) => ({
    //         uuid: permission.uuid || v4Uuid,
    //         user_id: "",
    //         role_id: "",
    //         model: "",
    //       }));

    //       // Update state
    //     setPermissionStates(formattedPermissions);
    //     setErrorStates(formattedErrors);
    //     } else {
    //       await ccGetError({errors: 'no permissons data found in response'});
    //     }

    //   } catch (error) {
    //     await ccGetError(error);
    //   }
    // };
    fetchDatas();
  }, [fetchDatas]);


  if (loading) {
    return (
      <CCMuiCircularLoader 
        width="100%" 
        bgcolor="none" 
        sx={{color: `${ccLargeFontColor}`}} 
      />
    )
  }

  return (
    <PermissionFields
      roles={memoizedRoles}
      models={memoizedModels}
      users={memoizedUsers}
      permissionStates={permissionStates}
      setPermissionStates={setPermissionStates}
      errorStates={errorStates}
      setErrorStates={setErrorStates}
      handleCreatePermission={handleCreatePermission}
      handleEditPermission={handleEditPermission}
    >
      {/* Save, Cancel Button */}
      <Box sx={{gridColumn: 'span 18'}}>
        <CCButtonGreen 
          startIcon={<SaveAsTwoToneIcon />}
          endIcon=""
          onClick={handleAddPermission}
          sx={{ ml: 0, mb: 1 }}
        >
          Add Permission
        </CCButtonGreen>
      </Box>
    </PermissionFields>
  )
});

export default CreateEditForm;