import React, {useEffect, useState, useCallback, useMemo, lazy, memo, Suspense } from "react"
import { useNavigate } from "react-router-dom";

import {Box, Button} from '@mui/material';
import SaveAsTwoToneIcon from '@mui/icons-material/SaveAsTwoTone';
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
import { 
  ccBgColor,
  ccSubBgColor,
  ccBgVar1Color,
  ccBgVar2Color,
  ccVar7Color,
  ccLargeFontColor,
  CCButtonSky,
  CCButtonGreen,
} from "components/mui-customizations/styleCustomization";
import { CCMuiCircularLoader } from "components/mui-customizations/ccMuiCircularLoader";

import {v4 as uuidv4} from 'uuid';
import { swalLWithZIndexAlert } from "components/swal-customizations/styleCustomization";
import Swal from "sweetalert2";

import axiosInstance from "plugins/axiosInstance";
import { useRole } from "components/roles/roleContext";
import { useUser } from "components/users/userContext";
import { useError } from "errors/errorHook";
import wordsUpperCase from "utilities/wordsUpperCase";
import wordsSeperateByUpperCase from "utilities/wordsSeperateByUpperCase";
import isEmptyUniversalCheck from "utilities/isEmptyUniversalCheck";
import PermissionFields from "./permissionFields";


const v4Uuid = uuidv4();

// Init permission states
const initPermissionStates = [{
  id: '',
  uuid: v4Uuid,
  role_id: "",
  model: "",
  user_id: [],
  create: false,
  update: false,
  delete: false,
  title: "",
  note: "",
}]

// Init permission states
const initErrors = [{
  uuid: v4Uuid,
  user_id: '',
  role_id: '',
  model: "",
}]

const CreateEditForm = memo(() => {
  const {fetchAllUsers, allUsers} = useUser();
  const {fetchAllRoles, allRoles} = useRole();
  const {ccGetError} = useError();

  // Initial repeatable permission states
  const [permissionStates, setPermissionStates] = useState(initPermissionStates);
  // Initial repeatable error states
  const [errorStates, setErrorStates] = useState(initErrors);
  const [loading, setLoading] = useState(false);

  const [models, setModels] = useState([]);



  // Generating repeatable states form while adding permissions
  // Generating corresponding error states while adding permissions
  // Ensure each time new uuid while adding permissions
  const handleAddPermission = () => {
    const v4Uuid = uuidv4();
    setPermissionStates((prev) => [
      ...prev,
      {
        id: '',
        uuid: v4Uuid,
        title: "",
        note: "",
        create: false,
        update: false,
        delete: false,
        role_id: "",
        model: "",
        user_id: [],
      },
    ]);

    setErrorStates((prev) => [
      ...prev,
      {
        uuid: v4Uuid,
        user_id: '',
        role_id: '',
        model: "",
      },
    ]);
  };

  const handleRemoveExceptNew = () => {
    // Derive filtered permissions locally
    const filteredPermissions = permissionStates.filter((item) =>
      isEmptyUniversalCheck(item.id)
    );
    const permissionUuids = filteredPermissions.map((item) => item.uuid);

    // Update both states using local variables
    setPermissionStates(filteredPermissions);
    setErrorStates((prevErrors) =>
      prevErrors.filter((item) => permissionUuids.includes(item.uuid))
    );

    // Log for debugging
    // console.log('Filtered Permissions:', filteredPermissions);
    // console.log('Updated Error States:', errorStates);
  };

  const handleEditPermission = useCallback(async (uuid) => {
    // Fetch errors if any otherwise triggering to submit
    const findError = [...errorStates];
    const locateError = findError.find(item=>item.uuid === uuid);

    if (Object.keys(locateError).filter(key => key != 'uuid' && locateError[key]).length > 0) {
      await ccGetError({errors: locateError});
      setLoading(false)

    } else {
      try {
        const findPermission = [...permissionStates];
        const locatePermission = findPermission.find(item=>item.uuid === uuid);
        // console.log('masudpermission', locatePermission)
        const result = await axiosInstance.put(`/permissions/${locatePermission.id}`, locatePermission)
        if(result.data.status === "success" ) {
          swalLWithZIndexAlert.fire({
            title: `${wordsUpperCase(result.data.status)}!`, 
            text: result.data.message, 
            icon: "success",
            iconColor: ccLargeFontColor,
            color: ccLargeFontColor,
            confirmButtonColor: ccLargeFontColor,
            background: ccBgVar1Color,
            timer: 1500,
          })
        } else {
          await ccGetError(result)
        }
      } catch (error) {
        await ccGetError(error)
      }
    }
  }, [permissionStates, errorStates, ccGetError])

  const handleCreatePermission = useCallback(async (uuid) => {
    // Fetch errors if any otherwise triggering to submit
    const findError = [...errorStates];
    const locateError = findError.find(item=>item.uuid === uuid);

    if (Object.keys(locateError).filter(key => key != 'uuid' && locateError[key]).length > 0) {
      await ccGetError({errors: locateError});
      setLoading(false);

    } else {
      try {
        const findPermission = [...permissionStates];
        const locatePermission = findPermission.find(item=>item.uuid === uuid);
        // console.log('masudpermission', locatePermission)
        const result = await axiosInstance.post('/permissions', locatePermission)
        if(result.data.status === "success" ) {
          swalLWithZIndexAlert.fire({
            title: `${wordsUpperCase(result.data.status)}!`, 
            text: result.data.message, 
            icon: "success",
            iconColor: ccLargeFontColor,
            color: ccLargeFontColor,
            confirmButtonColor: ccLargeFontColor,
            background: ccBgVar1Color,
            timer: 1500,
          }).then(async () => {
            await fetchDatas();
          });
        } else {
          console.log(result)
          await ccGetError(result)
        }
      } catch (error) {
        console.log(error)
        await ccGetError(error)
      }
    }
  }, [permissionStates, errorStates, ccGetError]);

  const fetchDatas = useCallback(async () => {
    setLoading(true);
    try {
      // For Race Conditions or Timing Issues problems
      // Ensure both all are resolving before proceeding
      await Promise.all([fetchAllUsers(), fetchAllRoles()]);
      await Promise.all([allUsers, allRoles]);

      const response = await axiosInstance.get("/permissions");

      // setModels(
      //   await response?.data?.permissionModels?.modelNames?.map((model) => ({
      //     id: model,
      //     label: model,
      //     value: wordsSeperateByUpperCase(model),
      //   }))
      // );

      setModels(await response?.data?.permissionModels?.modelNames);

      setPermissionStates(
        response?.data?.permissions?.map((permission) => ({
          id: permission.id || "",
          uuid: permission.uuid || v4Uuid,
          role_id: permission.role_id || "",
          model: permission.model || "",
          user_id: permission.user_id || [],
          create: permission.create || false,
          update: permission.update || false,
          delete: permission.delete || false,
          title: permission.title || "",
          note: permission.note || "",
        }))
      );

      setErrorStates(
        response?.data?.permissions?.map((permission) => ({
          uuid: permission.uuid || v4Uuid,
          user_id: "",
          role_id: "",
          model: "",
        }))
      );

      // const [rolesResponse, permissionsResponse, usersResponse] = await Promise.all([
      //   axiosInstance.get("/roles"),
      //   axiosInstance.get("/permissions"),
      //   axiosInstance.get("/users"),
      // ]);

      // const permissionsResponse = await axiosInstance.get("/permissions");

      // setModels(
      //   permissionsResponse?.data?.permissionModels?.modelNames?.map((model) => ({
      //     id: model,
      //     label: model,
      //     value: wordsSeperateByUpperCase(model),
      //   }) || [])
      // );

      // setModels(
      //   fetchAllModels.map((model) => ({
      //     id: model,
      //     label: model,
      //     value: wordsSeperateByUpperCase(model),
      //   }) || [])
      // );

      // rolesResponse && rolesResponse.data && rolesResponse.data.allRoles && (
      //   setRoles(
      //     rolesResponse?.data?.allRoles?.map((role) => ({
      //       id: role.id,
      //       label: role.title,
      //       value: role.title,
      //     })) || []
      //   )
      // );

      // setRoles(
      //   allRoles?.map((role) => ({
      //     id: role.id,
      //     label: role.title,
      //     value: role.title,
      //   })) || []
      // )

      // usersResponse && usersResponse.data && usersResponse.data.allUsers && (
      //   setUsers(
      //     usersResponse.data.allUsers.map((user) => ({
      //       id: user.id,
      //       label: user.name,
      //       value: user.name,
      //     }) || [])
      //   )
      // );

      // setUsers(
      //   allUsers?.map((user) => ({
      //     id: user.id,
      //     label: user.name,
      //     value: user.name,
      //   }) || [])
      // )

      // Set permission states with proper mapping for relational data
      // if (fetchAllPermissions.length > 0) {
      //   const formattedPermissions = fetchAllPermissions.map((permission) => ({
      //     id: permission.id || "",
      //     uuid: permission.uuid || v4Uuid,
      //     role_id: permission.role_id || "",
      //     model: permission.model || "",
      //     user_id: permission.user_id || [],
      //     create: permission.create || false,
      //     update: permission.update || false,
      //     delete: permission.delete || false,
      //     title: permission.title || "",
      //     note: permission.note || "",
      //   }));

      //   const formattedErrors = fetchAllPermissions.map((permission) => ({
      //     uuid: permission.uuid || v4Uuid,
      //     user_id: "",
      //     role_id: "",
      //     model: "",
      //   }));

      //   // Update state
      // setPermissionStates(formattedPermissions);
      // setErrorStates(formattedErrors);
      // } else {
      //   await ccGetError({errors: 'no permissons data found in response'});
      // }
    } catch (error) {
      await ccGetError(error);
    } finally {
      setLoading(false);
    }
  }, [fetchAllRoles, fetchAllUsers]); // Recreate the callback when contextual changes

  // Refresh Handler
  const handleRefresh = useCallback(() => {
    fetchDatas();
  }, [fetchDatas]);

  // Memoized roles, models, and users
  // useMemo prevents unnecessary re-renders
  // will not recalculate unless their dependency changes
  // const memoizedRoles = useMemo(() => roles, [roles]);
  // const memoizedModels = useMemo(() => models, [models]);
  // const memoizedUsers = useMemo(() => users, [users]);

  const memoizedRoles = useMemo(
    () =>
      allRoles?.map((role) => ({
        id: role.id,
        label: role.title,
        value: role.title,
      })) || []
    [allRoles]
  );

  const memoizedUsers = useMemo(
    () =>
      allUsers?.map((user) => ({
        id: user.id,
        label: user.name,
        value: user.name,
        rolesOfThisUser: user?.roles?.map(role=>role.id),
      })) || [],
    [allUsers]
  );

  // Load permission state datas
  useEffect(() => {
    // const fetchDatas = async () => {
    //   try {
    //     const [rolesResponse, permissionsResponse, usersResponse] = await Promise.all([
    //       axiosInstance.get("/roles"),
    //       axiosInstance.get("/permissions"),
    //       axiosInstance.get("/users"),
    //     ]);

    //     setRoles(
    //       rolesResponse.data.allRoles.map((role) => ({
    //         id: role.id,
    //         label: role.title,
    //         value: role.title,
    //       }))
    //     );

    //     setModels(
    //       permissionsResponse.data.permissionModels.modelNames.map((model) => ({
    //         id: model,
    //         label: model,
    //         value: wordsSeperateByUpperCase(model),
    //       }))
    //     );

    //     setUsers(
    //       usersResponse.data.allUsers.map((user) => ({
    //         id: user.id,
    //         label: user.name,
    //         value: user.name,
    //       }))
    //     );

    //     // Set permission states with proper mapping for relational data
    //     if (permissionsResponse.data.permissions?.length > 0) {
    //       const formattedPermissions = permissionsResponse.data.permissions.map((permission) => ({
    //         id: permission.id || "",
    //         uuid: permission.uuid || v4Uuid,
    //         role_id: permission.role_id || "",
    //         model: permission.model || "",
    //         user_id: permission.user_id || [],
    //         create: permission.create || false,
    //         update: permission.update || false,
    //         delete: permission.delete || false,
    //         title: permission.title || "",
    //         note: permission.note || "",
    //       }));

    //       const formattedErrors = permissionsResponse.data.permissions.map((permission) => ({
    //         uuid: permission.uuid || v4Uuid,
    //         user_id: "",
    //         role_id: "",
    //         model: "",
    //       }));

    //       // Update state
    //     setPermissionStates(formattedPermissions);
    //     setErrorStates(formattedErrors);
    //     } else {
    //       await ccGetError({errors: 'no permissons data found in response'});
    //     }

    //   } catch (error) {
    //     await ccGetError(error);
    //   }
    // };
    fetchDatas();
  }, [fetchDatas]);


  if (loading) {
    return (
      <CCMuiCircularLoader 
        width="100%" 
        bgcolor="none" 
        sx={{color: `${ccLargeFontColor}`}} 
      />
    )
  }

  return (
    <PermissionFields
      roles={memoizedRoles}
      models={models}
      users={memoizedUsers}
      permissionStates={permissionStates}
      setPermissionStates={setPermissionStates}
      errorStates={errorStates}
      setErrorStates={setErrorStates}
      handleCreatePermission={handleCreatePermission}
      handleEditPermission={handleEditPermission}
    >
      {/* Save, Cancel Button */}
      <Box 
        sx={{
          gridColumn: 'span 18'
        }}
      >
        <CCButtonGreen 
          size="small"
          startIcon={<SaveAsTwoToneIcon />}
          endIcon=""
          onClick={handleAddPermission}
          sx={{ ml: 0, mr: 1, mb: 1}}
        >
          Add Permission
        </CCButtonGreen>

        <CCButtonSky
          size="small"
          startIcon={<SaveAsTwoToneIcon />}
          endIcon=""
          onClick={handleRefresh}
          sx={{ ml: 0, mr: 1, mb: 1}}
        >
          Refresh
        </CCButtonSky>

        <Button 
          size="small"
          startIcon={<CancelOutlinedIcon />}
          sx={{
            mb: 1,
            color: 'white',
            bgcolor: ccVar7Color, 
            ":hover": {
              backgroundColor: ccBgColor,
            },
          }}
          onClick={handleRemoveExceptNew}
        >
          Remove Except New
        </Button>
      </Box>
    </PermissionFields>
  )
});

export default CreateEditForm;