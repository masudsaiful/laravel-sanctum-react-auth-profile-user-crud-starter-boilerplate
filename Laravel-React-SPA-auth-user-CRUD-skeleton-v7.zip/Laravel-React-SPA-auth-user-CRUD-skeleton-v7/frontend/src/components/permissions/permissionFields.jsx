import React, { useState, useEffect, memo, useCallback } from "react";

import { useTheme } from '@mui/material/styles';
import {
  Box,
  Button,
  FormControl,
  FormHelperText,
  InputLabel,
  OutlinedInput,
  Checkbox,
  FormGroup,
  FormControlLabel,
} from "@mui/material";
import SaveAsTwoToneIcon from '@mui/icons-material/SaveAsTwoTone';
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
import CCMuiSingleSelectAutoComplete from "components/mui-customizations/ccMuiSingleSelectAutoComplete";
import CCMuiMultiSelectAutoComplete from "components/mui-customizations/ccMuiMultiSelectAutoComplete";
import { 
  CCAuthTextField, 
  CCMuiTextArea, 
  ccVar2Color,
  CCButtonSky,
  ccBgColor,
  ccVar7Color,
  CCDividerHorizontal,
  ccLargeFontColor,
  ccVar5Color,
} from "components/mui-customizations/styleCustomization";

import axiosInstance from "plugins/axiosInstance";
import isEmptyUniversalCheck from "utilities/isEmptyUniversalCheck";
import wordsUpperCase from "utilities/wordsUpperCase";

const PermissionFields = memo(({
  children,
  roles,
  models,
  users,
  permissionStates, 
  setPermissionStates,
  errorStates,
  setErrorStates,
  handleCreatePermission,
  handleEditPermission,
}) => {
  
  const theme = useTheme();
  const [submitOnOfBasedOnRoleMatch, SetSubmitOnOfBasedOnRoleMatch] = useState(null)
  const [submitOnOfBasedOnUserMatch, SetSubmitOnOfBasedOnUserMatch] = useState(null)

  const handleRemovePermission = (uuid) => {
    setPermissionStates((prev) => prev.filter((item, i) => item.uuid !== uuid));
  };

  // const handlePermissionChange = (index, field, value) => {
  //   const updatedPermissions = [...permissionStates];
  //   updatedPermissions[index][field] = value;
  //   setPermissionStates(updatedPermissions);
  // };

  // const debounce = (func, delay) => {
  //   let timeout;
  //   return (...args) => {
  //     clearTimeout(timeout);
  //     timeout = setTimeout(() => func(...args), delay);
  //   };
  // };
  
  // const debouncedHandleChange = React.useCallback(debounce((event) => {
  //   handlePermissionChange(uuid, name, event.target.value);
  // }, 200), []);

  // Checking non empty value and update corresponding errors if found while field changes
  const handlePermissionChange = useCallback((uuid, field, value) => {
    const updatedPermissions = [...permissionStates];
    const updatedErrors = [...errorStates];
  
    const permissionIndex = updatedPermissions.findIndex(item => item.uuid === uuid);
    const errorIndex = updatedErrors.findIndex(item => item.uuid === uuid);
  
    if (permissionIndex !== -1) {
      updatedPermissions[permissionIndex][field] = value;
    }
    if (errorIndex !== -1) {
      updatedErrors[errorIndex][field] = '';
    }

    if (field === 'role_id' || field === 'model') {
      if (isEmptyUniversalCheck(value)) {
        updatedErrors[errorIndex][field] = `${wordsUpperCase(field)} must be selected`;
      } 
    }
      
    // Role validation
    if (field === 'role_id') {
      // Current permission states collection based on selected users
      const selectedUsers = users.filter(user => updatedPermissions[permissionIndex].user_id.includes(user.id));

      // Current permission states collection that have no role_id assigned 
      const roleMismatch = selectedUsers.some(user => !user.rolesOfThisUser.includes(value));
  
      // If not role_id assigned to user found error set
      if (roleMismatch) {
        updatedErrors[errorIndex][field] = `Unassigned ${wordsUpperCase(field)}`;
        SetSubmitOnOfBasedOnRoleMatch(uuid);

        updatedErrors[errorIndex]['user_id'] = 'User has no such role';
        SetSubmitOnOfBasedOnUserMatch(uuid);

      } else {
        updatedErrors[errorIndex][field] = ""
        SetSubmitOnOfBasedOnRoleMatch(null);

        updatedErrors[errorIndex]['user_id'] = "";
        SetSubmitOnOfBasedOnUserMatch(null);
      }
    }

    // User validation
    if (field === 'user_id') {
      // Current permission states collection based on selected users
      const selectedUsers = users.filter(user => value.includes(user.id));

      // Current permission states selected role collection
      const roleId = updatedPermissions[permissionIndex].role_id;

      // Current permission states collection that have not assigned the selected role
      const userMismatch = selectedUsers.some(user => !user.rolesOfThisUser.includes(roleId));
  
      // If not role_id assigned to user found error set
      if (userMismatch) {
        updatedErrors[errorIndex][field] = `${wordsUpperCase(field)} has no such role`;
        SetSubmitOnOfBasedOnUserMatch(uuid);

        updatedErrors[errorIndex]['role_id'] = `Unassigned role`;
        SetSubmitOnOfBasedOnRoleMatch(uuid);
      } else {
        updatedErrors[errorIndex][field] = ""
        SetSubmitOnOfBasedOnUserMatch(null);

        updatedErrors[errorIndex]['role_id'] = '';
        SetSubmitOnOfBasedOnRoleMatch(null);
      }
    }

    setPermissionStates(updatedPermissions);
    setErrorStates(updatedErrors);

    // setPermissionStates((prev) => {
    //   const updated = [...prev];
    //   const index = updated.findIndex(item => item.uuid === uuid);
    //   if (index !== -1) updated[index][field] = value;
    //   return updated;
    // });
  
    // setErrorStates((prev) => {
    //   const updated = [...prev];
    //   const index = updated.findIndex(item => item.uuid === uuid);
    //   if (index !== -1) updated[index][field] = isEmptyUniversalCheck(value)
    //     ? `${wordsUpperCase(field)} must be selected`
    //     : '';
    //   return updated;
    // });

    // const locatePermission = updatedPermission.map((item,index) => {
    //   if ( item.uuid === uuid) {
    //     if (field === 'user_id' || field === 'model') {
    //       // alert(updateError.find((e,i)=>e.uuid === uuid).)

    //       updateError.find((e,i)=> {
    //         if(e.uuid === uuid) {
    //           return updateError[i][field] = '';
    //         } {
    //           return e;
    //         }
    //       });
    //       setErrorStates(updateError);

    //       if (isEmptyUniversalCheck(value)) {
    //         updateError.find((e,i)=> {
    //           if(e.uuid === uuid) {
    //             return updateError[i][field] = `${wordsUpperCase(field)} must be selected`;
    //           } {
    //             return e;
    //           }
    //         });
    //         setErrorStates(updateError);
    //         return updatedPermission[index][field] = value;
    //       } else {
    //         updateError.find((e,i)=> {
    //           if(e.uuid === uuid) {
    //             return updateError[i][field] = '';
    //           } {
    //             return e;
    //           }
    //         });
    //         setErrorStates(updateError);
    //         return updatedPermission[index][field] = value;
    //       }
    //     } else {
    //       return updatedPermission[index][field] = value;
    //     }
    //   } else {
    //     return item;
    //   }
    // });
  }, [permissionStates, errorStates, users]);

  // const handleCreatePermission = (uuid) => {
  //   const permission = permissionStates[uuid];
  //   console.log("Submitting Permission:", permission);
  //   showSnackbar("Permission submitted successfully!");
  // };

  const renderSelectField = (uuid, name, label, items, value, error="") => (
    <FormControl 
      sx={{ 
        gridColumn: {
          xs: "span 6",
          sm: "span 6",
          md: 'span 4',
          lg: 'span 2',
        }
      }} 
      size="small" 
      required 
      error={!!error}
    >
      <InputLabel id={`${name}-${uuid}-label`} sx={{ color: ccVar2Color }}>{label}</InputLabel>
      <CCMuiSingleSelectAutoComplete
        name={`${name}-${uuid}`}
        value={value}
        id={`${name}-${uuid}`}
        labelId={`${name}-${uuid}-label`}
        onChange={(event, newValue) => handlePermissionChange(uuid, name, event.target.value)}
        input={<OutlinedInput id={`${name}-${uuid}-select`} label={label} />}
        items={items}
      />
      <FormHelperText sx={{ mx: 0, color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  );

  const renderMultiSelectField = (uuid, name, label, items, value = [], error = "") => (
    <FormControl 
      sx={{ 
        gridColumn: {
          xs: "span 6",
          sm: "span 6",
          md: 'span 4',
          lg: 'span 2',
        }
      }} 
      size="small" 
      error={!!error}
    >
      <InputLabel id={`${name}-${uuid}-label`} sx={{ color: ccVar2Color }}>{label}</InputLabel>
      <CCMuiMultiSelectAutoComplete
        name={`${name}-${uuid}`}
        value={value}
        id={`${name}-${uuid}`}
        labelId={`${name}-${uuid}-label`}
        onChange={(event) => handlePermissionChange(uuid, name, event.target.value)}
        input={<OutlinedInput id={`${name}-${uuid}-select`} label={label} />}
        items={items} // Ensure items are passed correctly
        multiple
      />
      <FormHelperText sx={{ color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  );
  
  const renderCheckbox = (uuid, name, label, type="checkbox", value="", error = "") => (
    <FormControl 
      sx={{ 
        ml:0.25,
        gridColumn: {
          xs: "span 6",
          sm: "span 6",
          md: 'span 2',
          lg: 'span 1',
        },
      }} 
      size="small" 
      error={!!error}
    >
      <FormGroup>
        <FormControlLabel
          control={
            <Checkbox
              size="small"
              sx={{ 
                '& .MuiSvgIcon-root': { fontSize: 18 }, 
                pr: 0,
                mr: 0,
              }}
              type={type}
              name={`${name}-${uuid}`}
              id={`${name}-${uuid}`}
              label={label}
              checked={Boolean(value)}
              onChange={(event) =>
                handlePermissionChange(uuid, name, event.target.checked)
              }
              color="primary"
            />
          }
          label={label}
        />
      </FormGroup>
      <FormHelperText sx={{ color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  );

  const renderTextField = (uuid, name, label, type="", value="", error = "") => (
    <FormControl 
      sx={{ 
        gridColumn: {
          xs: "span 9",
          sm: "span 9",
          md: 'span 5',
          lg: 'span 2',
        }
      }} 
      size="small" 
      error={!!error}
    >
      <CCAuthTextField
        type="text"
        name={`${name}-${uuid}`}
        id={`${name}-${uuid}`}
        label={label}
        value={value}
        placeholder={`Enter ${label.toLowerCase()}`}
        onChange={(event) => handlePermissionChange(uuid, name, event.target.value)}
        autoComplete="off"
      />
      <FormHelperText sx={{ color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  );

  const renderTextarea = (uuid, name, label, type="", value = "", error = "") => (
    <FormControl 
      size="small"
      sx={{ 
        gridColumn: {
          xs: "span 9",
          sm: "span 9",
          md: 'span 5',
          lg: 'span 2',
        }
      }} 
      error={!!error}
    >
      <CCMuiTextArea
        size="small"
        name={`${name}-${uuid}`}
        id={`${name}-${uuid}`}
        label={label}
        minRows={2.5}
        placeholder={`Enter ${label.toLowerCase()}`}
        value={value}
        onChange={(event) => handlePermissionChange(uuid, name, event.target.value)}
      />
      <FormHelperText sx={{ mx: 0, color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  );

  return (
    <>
      <Box
        component="form"
        sx={{
          display: 'grid',
          gridTemplateColumns: 'repeat(18, 1fr)',    
          gap: 0.5,
          width: '100%',
        }}
        noValidate
        autoComplete="off"
      >
        {children}
        <CCDividerHorizontal
          sx={{ 
            pb:1.5,
            mb:2,
            gridColumn: 'span 18',
            borderBottomColor: `${ccLargeFontColor}80`,
          }}
        />

        {permissionStates.map((permission, index) => (
          <React.Fragment key={permission.uuid}>
            {renderSelectField(permission.uuid, "role_id", "Roles", roles, permission.role_id, errorStates.find(e=>e.uuid === permission.uuid).role_id)}
            {renderSelectField(permission.uuid, "model", "Models", models, permission.model,  errorStates.find(e=>e.uuid === permission.uuid).model)}
            {renderMultiSelectField(permission.uuid, "user_id", "User(s)", users, permission.user_id,  errorStates.find(e=>e.uuid === permission.uuid).user_id)}
            {renderCheckbox(permission.uuid, "create", "Cre", 'checkbox', permission.create,  errorStates.find(e=>e.uuid === permission.uuid).create)}
            {renderCheckbox(permission.uuid, "update", "Upd", 'checkbox', permission.update,  errorStates.find(e=>e.uuid === permission.uuid).update)}
            {renderCheckbox(permission.uuid, "delete", "Del", 'checkbox', permission.delete,  errorStates.find(e=>e.uuid === permission.uuid).delete)}
            {renderTextField(permission.uuid, "title", "Title", 'text', permission.title,  errorStates.find(e=>e.uuid === permission.uuid).title)}
            {renderTextarea(permission.uuid, "note", "Note", 'text', permission.note,  errorStates.find(e=>e.uuid === permission.uuid).note)}

            <Box
              display="flex"
              flexDirection="row"
              justifyContent="flex-end"
              alignItems="center"
              sx={{ 
                gridColumn: {
                  xs: "span 18",
                  sm: "span 18",
                  md: 'span 8',
                  lg: 'span 5',
                  xl: 'span 5', 
                },
              }}
            >
              { 
                submitOnOfBasedOnRoleMatch === permission.uuid ||
                submitOnOfBasedOnUserMatch === permission.uuid
                ?
                  ''
                : 
                <CCButtonSky 
                  size="small"
                  startIcon={<SaveAsTwoToneIcon />}
                  endIcon=""
                  onClick={() => (
                    isEmptyUniversalCheck(permission.id)
                    ? handleCreatePermission(permission.uuid)
                    : handleEditPermission(permission.uuid)
                  )}
                  sx={{ 
                    ml: 0,
                    mr: 0.25,
                    px: 0.5,
                  }}
                >
                  {
                    isEmptyUniversalCheck(permission.id)
                    ? 'Create'
                    : 'Update'
                  }
                </CCButtonSky>
              }

              <Button 
                size="small"
                startIcon={<CancelOutlinedIcon />}
                sx={{
                  px: 0.5,
                  mr: 0.25,
                  color: 'white',
                  bgcolor: ccVar7Color, 
                  ":hover": {
                    backgroundColor: ccBgColor,
                  },
                }}
                onClick={() => handleRemovePermission(permission.uuid)}
              >
                Remove
              </Button>

              <Button 
                size="small"
                startIcon={<CancelOutlinedIcon />}
                sx={{
                  color: 'white',
                  bgcolor: ccVar5Color, 
                  ":hover": {
                    backgroundColor: ccBgColor,
                  },
                }}
                onClick={() => handleRemovePermission(permission.uuid)}
              >
                Del
              </Button>
            </Box>

            <CCDividerHorizontal
              sx={{ 
                pb:1.5,
                mb:1.5,
                gridColumn: 'span 18',
                borderBottomColor: `${ccLargeFontColor}80`,
              }}
            />
          </React.Fragment>
        ))}
      </Box>
    </>
  );
});

export default PermissionFields;
