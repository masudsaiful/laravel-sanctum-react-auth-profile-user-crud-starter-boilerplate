import { useState, useEffect, useCallback, memo } from "react";
import { Box, Stack, Alert, Typography } from "@mui/material";
import { 
  ccVar1CommonGap,
  ccVar2CommonGap,
  ccVar7Color,
  ccVar5Color,
  ccVar6Color,
 } from "components/mui-customizations/styleCustomization";

import axiosInstance from "plugins/axiosInstance";
import useCurrentPages from "components/layouts/hooks/currentPagesHook";

const PermissionService = memo(({ children }) => {
  const {currentFirstPath} = useCurrentPages()
  const [permissionDataset, setPermissionDataset] = useState([]);
  const [profileId, setProfileId] = useState(0);

  // const fetchDatas = useCallback(async () => {
  //   try {
  //     const response = await axiosInstance.get("/auth/profile");
  //     setProfile(response.data.profile); // Update profile
  //   } catch (error) {
  //     console.log("Error fetching profile:", error);
  //   }
  // }, []);

  useEffect(() => {
    // fetchDatas(); // Call fetch on mount
    const fetchDatas = async () => {
      try {
        const response = await axiosInstance.get("/auth/profile");
        // Permission Datas
        setPermissionDataset(response?.data?.permissionDataset);
        // Profile Id
        setProfileId(response?.data?.profile?.id);
      } catch (error) {
        console.log("Error fetching profile:", error);
      }
    }
    fetchDatas();
  }, []);

  // useEffect(() => {
  //   if (profile?.roles) {
  //     const tmp = profile.roles.map(role => 
  //       role.permissions.filter(permission => permission.model === 'RoleBarChart')
  //     );
  //     setIsRoleBarChart(tmp);
  //   }
  // }, [profile]);

  const contentAccessPermission = permissionDataset.some(p=>p.model === currentFirstPath && p.create === 1)
  
  if (Number(profileId) === 1) {
    return (
      <Box>
        {children}
      </Box>
    )
  } else if (contentAccessPermission) {
    return (
      <Box>
        {children}
      </Box>
    )
  } else {
    return (
      <Stack 
        direction="column" 
        justifyContent="center" 
        alignItems="center" 
        sx={{ textAlign: 'center' }}
        spacing={{
          xs: ccVar1CommonGap,
          sm: ccVar1CommonGap,
          md: ccVar2CommonGap,
          xl: ccVar2CommonGap,
          lg: ccVar2CommonGap,
        }}
      >
        <Alert 
          variant="filled" 
          severity="error" 
          sx={{
            alignSelf: 'stretch', 
            display: 'flex', // Ensure flex layout for internal content
            justifyContent: 'center', // Center items horizontally
            alignItems: 'center', // Center items vertically
            textAlign: 'center', // Center text alignment
            backgroundColor: ccVar7Color, // Set custom background color

          }}
        >
          <Typography variant="subtitle1">
          Access denied 
          </Typography>
        </Alert>
      </Stack>
    )
  }
});

export default PermissionService;
