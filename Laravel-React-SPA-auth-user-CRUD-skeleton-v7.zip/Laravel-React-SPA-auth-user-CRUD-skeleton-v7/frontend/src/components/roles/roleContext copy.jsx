import React, { createContext, useContext, useState, useCallback, useEffect, useReducer, useRef } from "react";
import axiosInstance from "plugins/axiosInstance";
import { axios } from "plugins/axiosInstance";
import { useError } from "errors/errorHook";

const RoleContext = createContext('');
const RoleDispatchContext = createContext('');

const useRole = () => {
  return useContext(RoleContext);
};

const useRoleDispatch = () => {
  return useContext(RoleDispatchContext);
};

const initRole = {
  id: '',
  title: '',
  name: '',
  status: [],
};

const roleReducer = (role, action) => {
  switch (action.type) {
    case 'set':
      return action.role;
    case 'created':
      return [
        ...role, 
        { 
          name: action.name, 
          username: action.username, 
          email: action.email, 
          password: action.password, 
          password_confirmation: action.password_confirmation 
        }
      ];
    case 'changed':
      if (role.id === action.role.id) {
        return action.role;
      } else {
        return role;
      }
    default:
      throw Error('Unknown action: ' + action.type);
  }
};

const RoleProvider = (props) => {
  const [allPagingRoles, setAllPagingRoles] = useState([]);
  const [allRoles, setAllRoles] = useState([]);
  const [pageSize, setPageSize] = useState(20);
  const [rowCount, setRowCount] = useState(0);
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(false);
  const [sortModel, setSortModel] = useState([]);
  const [filterModel, setFilterModel] = useState({
    items: [],
  });

  const pageRef = useRef(0);
  const pageSizeRef = useRef(20);

  const { ccGetError } = useError();

  // Fetches paginated data with sorting and filtering
  const fetchAllRoles = useCallback(async (signal) => {
    setLoading(true);
    try {
      const result = await axiosInstance.get("/roles", {
        params: {
          page: pageRef.current + 1,
          pageSize: pageSizeRef.current,
          sortModel: JSON.stringify(sortModel),
          filterModel: JSON.stringify(filterModel),
        },
        signal,
      });

      if (result.data.status === 'success') {
        setAllPagingRoles(await formatDatasWithSrl(result.data.role));
        setAllRoles(await formatDatasWithSrl(result.data.allRoles));
        setRowCount(result.data.total);
        setPageRef(result.data.current_page - 1);
      } else {
        await ccGetError(result);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
        console.log("Fetch canceled:", error.message);
      } else {
        await ccGetError(error);
      }
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, sortModel, filterModel]);

  // Handle fetch with AbortController
  useEffect(() => {
    const controller = new AbortController();
    fetchAllRoles(controller.signal);

    return () => {
      controller.abort(); // Cancel the fetch when the component unmounts
    };
  }, [fetchAllRoles]);

  const [role, roleDispatch] = useReducer(roleReducer, initRole);

  return (
    <RoleContext.Provider
      value={{
        role,
        allRoles,
        allPagingRoles,
        rowCount,
        page,
        pageSize,
        loading,
        sortModel,
        filterModel,
        setAllPagingRoles,
        setPage,
        setPageRef,
        setPageSize,
        setPageSizeRef,
        setSortModel,
        setFilterModel,
        fetchAllRoles,
        initRole,
      }}
    >
      <RoleDispatchContext.Provider value={roleDispatch}>
        {props.children}
      </RoleDispatchContext.Provider>
    </RoleContext.Provider>
  );
};

export { RoleProvider, useRole, useRoleDispatch };
