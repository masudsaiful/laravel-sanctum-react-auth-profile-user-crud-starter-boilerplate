const isEmptyUniversalCheck = input => {
  return (
    input === null ||                 // Check for null
    input === undefined ||            // Check for undefined
    (typeof input === 'string' && input.trim() === '') || // Empty string (trimmed)
    (typeof input === 'object' && !Object.keys(input || {}).length) || // Empty object
    (Array.isArray(input) && input.length === 0) // Empty array
  );
}

export default isEmptyUniversalCheck;