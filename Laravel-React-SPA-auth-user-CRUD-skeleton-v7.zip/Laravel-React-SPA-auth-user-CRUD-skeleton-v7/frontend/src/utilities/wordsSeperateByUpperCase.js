
const wordsSeperateByUpperCase = param =>{
  // Step 1: Remove non-alphabetic characters (except letters and spaces)
  let formatted = param.replace(/[^a-zA-Z]/g, ' ');

  // Step 2: Add a space between lowercase and uppercase letters (except for the first letter)
  formatted = formatted.replace(/([a-z])([A-Z])/g, '$1 $2');

  // Step 3: Capitalize the first letter of each word
  formatted = formatted.split(' ').map(word => {
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
  }).join(' ');

  // Step 4: Replace multiple spaces with a single space and trim the string
  return formatted.replace(/\s+/g, ' ').trim();
}

export default wordsSeperateByUpperCase;