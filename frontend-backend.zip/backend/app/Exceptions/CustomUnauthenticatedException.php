<?php

namespace App\Exceptions;

use Exception;

class CustomUnauthenticatedException extends Exception
{
  protected $details;

  public function __construct($details = [
    "status" => "custom failed",
    "message" => "Custom exception occurred"
  ], $code = 401)
  {
    // Ensure details is an array
    if (is_string($details)) {
      $details = ["message" => $details];
    }

    $this->details = $details;
    $this->code = $code;

    parent::__construct(json_encode($details), $code);
  }

  public function render($request)
  {
    return response()->json([
      'status' => $this->details['status'],
      'message' => $this->details['message'],
      'errors' => $this->details,
    ], $this->code);
  }
}
