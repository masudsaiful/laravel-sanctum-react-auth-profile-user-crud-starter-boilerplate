<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Models\User\User;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Exceptions\CustomUnauthenticatedException;

class ProfileController extends Controller
{
    /**
     * Handle unauthenticated user.
     * Dependencies to Authenticate Middleware
     * Dependencies to CustomUnauthenticateException
     * Dpendencies to Exceptions Handler
     */

    public function profile()
    {
        // if(Auth::user()) {
        //     return response()->json(Auth::user());
        // } else {
        //     return null;
        // }

        if (!Auth::check()) {
            throw new CustomUnauthenticatedException([
                'status' => 'profile controller failed', 
                'message' => 'Profile controller exception occured, auth check failed'
            ], 401);
        }

        $user = Auth::user();

        // Lazy eager loading after retrieved User
        // $user->load('roles'); 

        // Ensure $user is an instance of the User model
        if (!$user instanceof User) {
            throw new CustomUnauthenticatedException([
                'status' => 'profile controller failed', 
                'message' => 'Profile controller exception occured, auth user instance of user model check failed'
            ], 500);
        }

        // Decode status field from dB json format to PHP assoc array
        if (is_string($user->status)) {
            $user->status = json_decode($user->status, true);
        }

        // Exclude password and other sensitive fields
        $user->makeHidden(['password', 'remember_token']);

        // lazy eager loading of selected fields of roles table 
        $user->load('roles:id,name,title,created_by');

        return response()->json([
            'status' => 'success',
            'message' => 'Found profile',
            'profile' => $user, 
        ], 200);
    }
}