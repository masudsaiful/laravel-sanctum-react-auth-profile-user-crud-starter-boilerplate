<?php

namespace App\Http\Controllers\Role;

use App\Exceptions\CustomUnauthenticatedException;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Illuminate\Http\Request;
use App\Http\Requests\Role\RoleRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use App\Models\Role\Role;

class RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $page = $request->input('page', 1);
        $pageSize = $request->input('pageSize', 50);

        $cacheKey = "roles_page_{$page}_pageSize_{$pageSize}";

        if (Cache::has($cacheKey)) {
            return Cache::get($cacheKey);
        }

        $query = Role::query();

        // Sorting
        if ($request->has('sortModel')) {
            foreach ($request->sortModel as $sort) {
                $query->orderBy($sort['field'], $sort['sort']);
            }
        }

        // Filtering
        if ($request->has('filterModel')) {
            foreach ($request->filterModel as $filter) {
                $query->where($filter['field'], 'like', '%' . $filter['value'] . '%');
            }
        }

        $roles = $query->paginate($pageSize);

        $response = [
            'data' => $roles->items(),
            'total' => $roles->total(),
            'current_page' => $roles->currentPage(),
            'last_page' => $roles->lastPage(),
        ];

        Cache::put($cacheKey, $response, 60); // Cache for 60 minutes

        return response()->json($response);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(RoleRequest $request)
    {
        // $request->validate([
        //     'name' => 'required|string|max:255',
        //     'rolename' => 'required|string|max:255|unique:roles',
        //     'email' => 'required|string|email|max:255|unique:roles',
        //     'password' => 'required|string|min:8|confirmed',
        // ]);

        DB::beginTransaction();
        try {
            //Insert data into roles table
            $role = new Role();

            // Handle status field
            $status = $request->input('status');
            if (is_array($status)) {
                $status = $status[0]; // or any appropriate serialization method
            }
            
            $roleFillableData = collect($request->only($role->getFillable()))->except('status')->merge(['status' => $status])->all();
            $createdByFillableData = collect(['created_by' => Auth::id()])->only($role->getFillable());
            $roleData = $createdByFillableData->merge($roleFillableData)->all();
            $role->fill($roleData)->save();
            $role->save();
            // $roleFillableData = $request->only($role->getFillable());
            // $role->fill($roleFillableData)->save();
            // $role->save();

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'Role has been created',
                'role' => $role,
            ], 201);

        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomUnauthenticatedException([
                'status' => 'failed',
                'message' => 'Role can\'t be created, '. $e->getMessage(),
            ], 422);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(RoleRequest $request, string $id)
    {
        // $request->validate([
        //     'name' => 'required|string|max:255',
        //     'rolename' => 'required|string|max:255|unique:roles',
        //     'email' => ['required', 'string', 'email', 'max:255', 'unique:roles', Rule::unique('roles','email')->ignore($request->input('id'),'id')],
        //     'password' => 'string|min:8|confirmed',
        // ]);

        DB::beginTransaction();
        try {
            $role = Role::whereId($id)->firstOrFail();

            // Handle array status field
            $status = $request->input('status');
            if (is_array($status)) {
                $status = $status[0]; // or any appropriate serialization method
            }

            $roleFillableData = collect($request->only($role->getFillable()))->except('status')->merge(['status' => $status])->all();
            $createdByFillableData = collect(['created_by' => Auth::id()])->only($role->getFillable());
            $roleData = $createdByFillableData->merge($roleFillableData)->all();
            $role->fill($roleData);
            $role->save();
            // $roleFillableData = $request->only($role->getFillable());
            // $role->fill($roleFillableData);
            // $role->save();

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'Role has been updated',
                'role' => $role,
            ], 201);

        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomUnauthenticatedException([
                'status' => 'failed',
                'message' => 'Role can\'t be updated, '. $e->getMessage(),
            ], 422);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
