<?php

namespace App\Http\Controllers\User;

use App\Exceptions\CustomUnauthenticatedException;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Illuminate\Http\Request;
use App\Http\Requests\User\UserRequest;
use Illuminate\Support\Facades\DB;
use App\Models\User\User;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            $page = $request->input('page', 1);
            $pageSize = $request->input('pageSize', 20);
    
            // $cacheKey = "users_page_{$page}_pageSize_{$pageSize}";
    
            // if (Cache::has($cacheKey)) {
            //     return Cache::get($cacheKey);
            // }
    
            $query = User::query()->with('roles');
            $query->where('id', '!=', Auth::id())
                  ->where('username', '!=', 'superAdmin');
    
            // // Sorting
            // if ($request->has('sortModel')) {
            //     $sortModel = json_decode($request->sortModel, true);
            //     foreach ($sortModel as $sort) {
            //         $query->orderBy($sort['field'], $sort['sort']);
            //     }
            // }
    
            // Override sorting if sortModel is provided and is a non-empty array
            if ($request->has('sortModel')) {
                $sortModel = json_decode($request->sortModel, true);
                
                // Check if sortModel is a non-empty array
                if (is_array($sortModel) && count($sortModel) > 0) {
                    foreach ($sortModel as $sort) {
                        if (isset($sort['field']) && isset($sort['sort'])) {
                            $query->orderBy($sort['field'], $sort['sort']);
                        }
                    }
                }else {
                    // Default sorting: latest to oldest
                    $query->orderBy('created_at', 'desc');
                }
            }

            // Filtering
            // if ($request->has('filterModel')) {
            //     $filterModel = json_decode($request->filterModel, true);
            //     if (isset($filterModel['items'])) {
            //         foreach ($filterModel['items'] as $filter) {
            //             $query->where($filter['field'], 'like', '%' . $filter['value'] . '%');
            //         }
            //     }
            // }
    
            if ($request->has('filterModel')) {
                $filterModel = json_decode($request->filterModel, true);
                if (isset($filterModel['items'])) {
                    foreach ($filterModel['items'] as $filter) {
                        if (isset($filter['field']) && isset($filter['value'])) {  // Check if keys exist
                            $query->where($filter['field'], 'like', '%' . $filter['value'] . '%');
                        }
                    }
                }
            }
            
            $users = $query->paginate($pageSize, ['*'], 'page', $page);
    
            // $response = [
            //     'data' => $users->items(),
            //     'total' => $users->total(),
            //     'current_page' => $users->currentPage(),
            //     'last_page' => $users->lastPage(),
            // ];
    
            // Cache::put($cacheKey, $response, 60); // Cache for 60 minutes
    
            // return response()->json($response);
    
            return response()->json([
                'status' => 'success',
                'message' => 'User(s) has been loaded',
                'user' => $users->items(),
                'total' => $users->total(),
                'current_page' => $users->currentPage(),
                'last_page' => $users->lastPage(),
            ], 200);

        } catch (\Throwable $e) {
            throw new CustomUnauthenticatedException([
                'status' => 'failed',
                'message' => 'User can\'t be loaded, '. $e->getMessage(),
            ], 422);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(UserRequest $request)
    {
        // $request->validate([
        //     'name' => 'required|string|max:255',
        //     'username' => 'required|string|max:255|unique:users',
        //     'email' => 'required|string|email|max:255|unique:users',
        //     'password' => 'required|string|min:8|confirmed',
        // ]);

        /*
        * Status field is cast at user model
        */

        DB::beginTransaction();
        try {
            //Insert data into users table
            $user = new User();

            // // Handle status field
            // $status = $request->input('status');
            // if (is_array($status)) {
            //     $status = $status[0]; // or any appropriate serialization method
            // }

            $userFillableData = collect($request->only($user->getFillable()));
            $createdByFillableData = collect(['created_by' => Auth::id()])->only($user->getFillable());
            $userData = $createdByFillableData->merge($userFillableData)->all();
            $user->fill($userData)->save();

            // Attaching with additional data in 'created_by' column
            $user->roles()->syncWithPivotValues($request->roles, ['created_by' => 1]);
            $user->save();
            // $userFillableData = $request->only($user->getFillable());
            // $user->fill($userFillableData)->save();
            // $user->save();

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'User has been created',
                'user' => $user,
            ], 201);

        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomUnauthenticatedException([
                'status' => 'failed',
                'message' => 'User can\'t be created, '. $e->getMessage(),
            ], 422);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        try {
            $user = User::whereId($id)->firstOrFail();
            // lazy eager loading of selected fields of roles table 
            $user->load('roles:id,name,title,created_by');

            return response()->json([
                'status' => 'success',
                'message' => 'User has been loaded',
                'user' => $user,
            ], 201);

        } catch (\Throwable $e) {
            throw new CustomUnauthenticatedException([
                'status' => 'failed',
                'message' => 'User can\'t be loaded, '. $e->getMessage(),
            ], 422);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UserRequest $request, string $id)
    {
        // $request->validate([
        //     'name' => 'required|string|max:255',
        //     'username' => 'required|string|max:255|unique:users',
        //     'email' => ['required', 'string', 'email', 'max:255', 'unique:users', Rule::unique('users','email')->ignore($request->input('id'),'id')],
        //     'password' => 'string|min:8|confirmed',
        // ]);

        DB::beginTransaction();
        try {
            $user = User::whereId($id)->firstOrFail();

            // // Handle array status field
            // $status = $request->input('status');
            // if (is_array($status)) {
            //     $status = $status[0]; // or any appropriate serialization method
            // }

            $userFillableData = collect($request->only($user->getFillable()));
            $createdByFillableData = collect(['created_by' => Auth::id()])->only($user->getFillable());
            $userData = $createdByFillableData->merge($userFillableData)->all();
            $user->fill($userData);

            // Attaching with additional data in 'created_by' column
            $user->roles()->syncWithPivotValues($request->roles, ['created_by' => 1]);
            $user->save();
            // $userFillableData = $request->only($user->getFillable());
            // $user->fill($userFillableData);
            // $user->save();

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'User has been updated',
                'user' => $user,
            ], 201);

        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomUnauthenticatedException([
                'status' => 'failed',
                'message' => 'User can\'t be updated, '. $e->getMessage(),
            ], 422);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        DB::beginTransaction();
        try {
            $user = User::findOrFail($id);
            $user->delete();
    
            DB::commit();
    
            return response()->json([
                'status' => 'success',
                'message' => 'User has been deleted',
            ], 200);
    
        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomUnauthenticatedException([
                'status' => 'failed',
                'message' => 'User can\'t be deleted, '. $e->getMessage(),
            ], 422);
        }


        // DB::beginTransaction();
        // try {
        //     $user = User::findOrFail($id);
        //     $user->delete();
    
        //     DB::commit();
    
        //     // Get the total number of users after deletion
        //     $totalUsers = User::where('id', '!=', Auth::id())
        //         ->where('username', '!=', 'SuperAdmin')
        //         ->count();
        //     $currentPage = request()->input('page', 1);
        //     $pageSize = request()->input('pageSize', 20);
    
        //     // Calculate the correct page number after deletion
        //     $totalPages = ceil($totalUsers / $pageSize);
        //     $correctPage = min($currentPage, $totalPages);
    
        //     return response()->json([
        //         'status' => 'success',
        //         'message' => 'User has been deleted',
        //         'page' => $correctPage,
        //     ], 200);
    
        // } catch (\Throwable $e) {
        //     DB::rollback();
        //     throw new CustomUnauthenticatedException([
        //         'status' => 'failed',
        //         'message' => 'User can\'t be deleted, '. $e->getMessage(),
        //     ], 422);
        // }

        // DB::beginTransaction();
        // try {
        //     $user = User::findOrFail($id);
        //     $user->delete();
    
        //     DB::commit();
    
        //     // Calculate the current page after deletion
        //     $currentPage = (int) request()->input('page', 1);
        //     $totalUsers = User::count();
        //     $totalPages = ceil($totalUsers / request()->input('pageSize', 10));

        //     // Set the page to the previous page if necessary
        //     if ($currentPage > $totalPages) {
        //         $currentPage = $totalPages;
        //     }
    
        //     return response()->json([
        //         'status' => 'success',
        //         'message' => 'User has been deleted',
        //         'page' => $currentPage,
        //     ], 200);
    
        // } catch (\Throwable $e) {
        //     DB::rollback();
        //     throw new CustomUnauthenticatedException([
        //         'status' => 'failed',
        //         'message' => 'User can\'t be deleted, '. $e->getMessage(),
        //     ], 422);
        // }
    }
}
