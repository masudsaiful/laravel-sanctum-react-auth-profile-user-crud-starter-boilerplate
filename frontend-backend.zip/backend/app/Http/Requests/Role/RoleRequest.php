<?php

namespace App\Http\Requests\Role;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;

class RoleRequest extends FormRequest
{
    /**
     * Determine if the role is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return $this->roleRules();
    }

    private function postRules() {
        $rules = [
            'title' => 'required|string|max:255|unique:roles,title',
            'name' => 'required|string|max:255|unique:roles,name',
            'status' => ['required', 'array'],
            'status.*' => ['integer', 'numeric'],
        ];
        return $rules;
    }

    private function putRules() {
        $rules = [];
        $rules['title'] = ['required', 'string', 'max:255', Rule::unique('roles','title')->ignore(Request::input('id'),'id')];
        $rules['name'] = ['required', 'string', 'max:255', Rule::unique('roles','name')->ignore(Request::input('id'),'id')];
        $rules['status'] = ['required', 'array'];
        $rules['status.*'] = ['integer', 'numeric'];
        return $rules;
    }

    private function combinationRules() {
        if (Request::isMethod('post')) {
            $rules = $this->postRules();
            return $rules;
        }

        if (Request::isMethod('put')) {
            $rules = $this->putRules();
            return $rules;
        }
    }

    private function roleRules()
    {
        $rules = $this->combinationRules();
        return $rules;
    }
}
