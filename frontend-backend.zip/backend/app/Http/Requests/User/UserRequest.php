<?php

namespace App\Http\Requests\User;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;

class UserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return $this->userRules();
    }

    private function postRules() {
        $rules = [
            'name' => 'required|string|max:255',
            'username' => 'required|string|max:255|unique:users,username',
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
            'status' => ['required', 'array'],
            'status.*' => ['integer', 'numeric'],
            'password' => 'required|string|min:8|confirmed',
        ];
        return $rules;
    }

    private function putRules() {
        $rules = [
            'name' => 'required|string|max:255',
        ];
        $rules['username'] = ['required', 'string', 'max:255', Rule::unique('users','username')->ignore(Request::input('id'),'id')];
        $rules['email'] = ['required', 'string', 'email', 'max:255', Rule::unique('users','email')->ignore(Request::input('id'),'id')];
        $rules['status'] = ['required', 'array'];
        $rules['status.*'] = ['integer', 'numeric'];
        $rules['password'] = 'nullable|sometimes|string|min:8|confirmed';
        return $rules;
    }

    private function combinationRules() {
        if (Request::isMethod('post')) {
            $rules = $this->postRules();
            return $rules;
        }

        if (Request::isMethod('put')) {
            $rules = $this->putRules();
            return $rules;
        }
    }

    private function userRules()
    {
        $rules = $this->combinationRules();
        return $rules;
    }
}
