import React, { 
  createContext, 
  useState, 
  useEffect, 
  useCallback 
} from "react";
import {
  login as loginService,
  register as registerService,
  logout as logoutService,
  getProfile,
} from "auths/services/authService";
import { useError } from "errors/errorHook";




const AuthContext = createContext("");

const AuthProvider = ({ children }) => {
  const [profile, setProfile] = useState(null);
  const [isProfile, setIsProfile] = useState(false);
  const [profileLoading, setProfileLoading] = useState(true);

  const fetchProfile = useCallback(async () => {
    // try {
    //   const response = await getProfile();
    //   setProfile(response);
    //   setIsProfile(true);
    // } catch (error) {
    //   setProfile(null);
    //   setIsProfile(false);
    // } finally {
    //   setProfileLoading(false);
    // }

    try {
      const response = await getProfile();
      setProfile(response.data.profile);
      setIsProfile(true);
      return response;
    } catch (error) {
      setProfile(null);
      setIsProfile(false);
      return error;
    } finally {
      setProfileLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchProfile();
    // console.log('profile2', profile)
  }, [fetchProfile]);

  // const handleLogin = async (credentials) => {
  //   try {
  //     const response = await loginService(credentials);
  //     if (response && response.data && typeof response.data.user !== 'undefined' ) {
  //       setProfile(response.data.user);
  //       setIsProfile(true);
  //       return response;
  //     } else {
  //       setProfile(null);
  //       setIsProfile(false);
  //       return response;
  //     }
  //   } catch (error) {
  //     setProfile(null);
  //     setIsProfile(false);
  //     return error;
  //   }
  // };
  
  const handleLogin = async (credentials) => {
    try {
      const response = await loginService(credentials);
      if (response && response.data && typeof response.data.user !== 'undefined' ) {
        await fetchProfile();
        return response;
      } else {
        setProfile(null);
        setIsProfile(false);
        return response;
      }
    } catch (error) {
      setProfile(null);
      setIsProfile(false);
      return error;
    }
  };

  // const handleRegister = async (data) => {
  //   try {
  //     const registeredUser = await registerService(data);
  //     return registeredUser;
  //   } catch (error) {
  //     // ccGetError(error.response.data.errors)
  //     // console.log('only message', ccShowError)
  //     // console.log('only message1', ccError)
  //     // throw new Error("Registration failed");
  //     // showError('Failed to register');
  //     // console.log('error', error)
  //     // console.log('only message', error.message)
  //     // console.log('response message', error.response.data.message)
  //     // console.log('response errors', error.response.data.errors)
  //     // console.log('response status', error.response.status)
  //     // console.log('response status text', error.response.statusText)
  //     await ccGetError(error);
  //   }
  // };

  const handleRegister = async (data) => {
    try {
      const response = await registerService(data);
      return response;
    } catch (error) {
      return error
    }
  };

  const handleSetEditedProfile = async (profileData) => {
    try {
      const response = await profileData
      setProfile(response);
      setIsProfile(true);
      return response;
    } catch (error) {
      setProfile(null);
      setIsProfile(false);
      return error;
    }
  };

  const handleLogout = async () => {
    try {
      // console.log("Calling logout service...");
      await logoutService();
      // console.log("Logout service called");
      setProfile(null);
      setIsProfile(false);
    } catch (error) {
      // console.error("Logout failed:", error);
      // showError('Logout failed');
    }
  };

  return (
    <AuthContext.Provider
      value={{
        profile,
        isProfile,
        profileLoading,
        handleLogin,
        handleRegister,
        handleLogout,
        // handleGetProfile,
        fetchProfile,
        handleSetEditedProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
export {AuthContext};
