import React from "react";
import { DataGrid, gridClasses } from "@mui/x-data-grid";
import { styled } from "@mui/material/styles";
import Button from "@mui/material/Button";
import DeleteIcon from "@mui/icons-material/Delete";
import { 
  ccVar1Color, 
  ccVar4Color,
  ccBgColor,
} from 'components/mui-customizations/styleCustomization';

const StripedStyledDataGrid = styled(DataGrid)(({ theme }) => ({
  [`& .${gridClasses.row}.even`]: {
    backgroundColor: ccVar4Color + "26",
    "&:hover": {
      backgroundColor: ccVar1Color + "a3",
      "@media (hover: none)": {
        backgroundColor: ccVar1Color,
      },
    },
    "&.Mui-selected": {
      backgroundColor: ccVar1Color,
      "&:hover": {
        backgroundColor: ccVar1Color + "a3",
        "@media (hover: none)": {
          backgroundColor: ccVar1Color + "a3",
        },
      },
    },
  },
  "& .MuiDataGrid-container--top [role=row]": {
    backgroundColor: "#009dff",
    color: "#ffffff",
    borderTopLeftRadius: "5px",
    borderTopRightRadius: "5px",
    "& .MuiDataGrid-columnHeaderTitle, & .MuiIconButton-root, & .MuiSvgIcon-root": {
      color: "#ffffff",
    },
  },
  "& .MuiDataGrid-columnHeader:focus, & .MuiDataGrid-columnHeader:focus-within": {
    outline: "none",
  },
  "& .MuiDataGrid-row:hover": {
    backgroundColor: ccVar1Color + "a3",
  },
  "& .Mui-selected": {
    backgroundColor: ccVar1Color + "a3!important",
  },
  "& .Mui-selected:hover": {
    backgroundColor: ccVar1Color + "!important",
  },
  "& .MuiDataGrid-cell--selected": {
    backgroundColor: "red !important",
    color: "#ffffff !important",
  },
  "& .MuiDataGrid-footerContainer": {
    backgroundColor: ccVar4Color + "61",
    borderBottomLeftRadius: "5px",
    borderBottomRightRadius: "5px",
  },
}));

const CustomPagination = () => null;

const CCDataGrid = ({
  rows,
  columns,
  rowCount,
  pageSize,
  page,
  setPage,
  setPageSize,
  sortModel,
  setSortModel,
  filterModel,
  setFilterModel,
  loading,
  selectedIds,
  setSelectedIds,
  onBulkDelete,
}) => {
  return (
    <>
      {selectedIds.length > 0 && (
        <Button
          variant="contained"
          color="secondary"
          startIcon={<DeleteIcon />}
          onClick={onBulkDelete}
          sx={{
            mb: 2,
            color: 'white',
            ":hover": {
              backgroundColor: ccBgColor,
            },
          }}
        >
          Delete Selected
        </Button>
      )}
      <StripedStyledDataGrid
        rows={rows}
        columns={columns}
        pagination
        paginationMode="server"
        rowCount={rowCount}
        pageSize={pageSize}
        paginationModel={{ pageSize: pageSize, page: page }}
        pageSizeOptions={[5, 10, 15, 20, 100]}
        onPaginationModelChange={(newPaginationModel) => {
          if (!loading) {
            setPage(newPaginationModel.page);
            setPageSize(newPaginationModel.pageSize);
          }
        }}
        sortingMode="server"
        sortModel={sortModel}
        onSortModelChange={(model) => setSortModel(model)}
        filterMode="server"
        filterModel={filterModel}
        onFilterModelChange={(model) => setFilterModel(model)}
        loading={loading}
        getRowClassName={(params) =>
          params.indexRelativeToCurrentPage % 2 === 0 ? 'even' : 'odd'
        }
        checkboxSelection
        onRowSelectionModelChange={(newSelectionModel) => {
          setSelectedIds(newSelectionModel);
        }}
        disableSelectionOnClick
        disableRowSelectionOnClick
        autoHeight
        components={{
          Pagination: CustomPagination, // Hide default pagination controls
        }}
      />
    </>
  );
};

export default CCDataGrid;
