import React, {useEffect, useState, } from "react"
import { useNavigate } from "react-router-dom";
import {Box, Button} from '@mui/material';
import SaveAsTwoToneIcon from '@mui/icons-material/SaveAsTwoTone';
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
import Swal from "sweetalert2";
import axiosInstance from "plugins/axiosInstance";
import RoleFields from "components/roles/roleFields";
import { useRole } from "components/roles/roleContext";
import { useRoleDispatch } from "components/roles/roleContext";
import { useError } from "errors/errorHook";
import wordsUpperCase from "utilities/wordsUpperCase";
import { 
  ccBgColor,
  ccVar7Color,
  CCButtonSky,
  ccLargeFontColor,
  ccBgVar1Color,
} from "components/mui-customizations/styleCustomization";




const initErrors = {
  errors: {
    title: '',
    name: '',
    status: '',
  }
}

const CreateEditForm = ({option, roleData}) => {
  // Initial error state set
  const [errorState, setErrorState] = useState(initErrors);

  // Handle and setting role in role context
  const {role, initRole, handleEditedRole, handleGetRole} = useRole();

  // Dispatch from role context
  const dispatch = useRoleDispatch();

  // Displaying error
  const {ccGetError} = useError();

  const navigate = useNavigate();

  // Set role data to role cotext in edit mode
  if (option === 'edited') {
    useEffect(() => {
      handleEditedRole(roleData);
    }, [roleData]);
  }

  const handleSubmitEdited = async () => {
    try {
      const result = await axiosInstance.put(`/roles/${role.id}`, role)
      if(result.data.status === "success" ) {
        handleGetRole();
        Swal.fire({
          title: `${wordsUpperCase(result.data.status)}!`, 
          text: result.data.message, 
          icon: "success",
          iconColor: ccLargeFontColor,
          color: ccLargeFontColor,
          confirmButtonColor: ccLargeFontColor,
          background: ccBgVar1Color,
        })
      } else {
        await ccGetError(result)
      }
    } catch (error) {
      await ccGetError(error)
    }
  }

  const handleSubmitCreated = async () => {
    try {
      const result = await axiosInstance.post('/roles', role)
      if(result.data.status === "success" ) {
        Swal.fire({
          title: `${wordsUpperCase(result.data.status)}!`, 
          text: result.data.message, 
          icon: "success",
          iconColor: ccLargeFontColor,
          color: ccLargeFontColor,
          confirmButtonColor: ccLargeFontColor,
          background: ccBgVar1Color,
          timer: 1500,
        }).then(result => {
          navigate("/role/list")
        })
      } else {
        await ccGetError(result)
      }
    } catch (error) {
      await ccGetError(error)
    }
  }

  const handleSubmit = async (e) => {
    dispatch({
      type: "set",
      role: role,
    })
    if (Object.keys(errorState.errors).filter(key => errorState.errors[key]).length > 0) {
      await ccGetError(errorState)
    } else {
      e.preventDefault();
      option === 'edited' && handleSubmitEdited()
      option === 'created' && handleSubmitCreated()
    }
  };

  const handleCancleEdited = () => {
    dispatch({ 
      type: 'changed', 
      role: roleData 
    });
    setErrorState(initErrors);
  }

  const handleCancleCreated = () => {
    dispatch({ 
      type: 'changed', 
      role: initRole, 
    });
    setErrorState(initErrors);
  }

  const handleCancel = () => {{ 
    option === 'edited' && handleCancleEdited()
    option === 'created' && handleCancleCreated()
  }};

  return (
    <RoleFields 
      errorState={errorState} 
      setErrorState={setErrorState}
      option={option}
    >
      {/* Save, Cancel Button */}
      <Box sx={{gridColumn: 'span 3', mt: 2}}>
        <CCButtonSky 
          startIcon={<SaveAsTwoToneIcon />}
          endIcon=""
          onClick={handleSubmit}
          sx={{ ml: 0 }}
        >
          Create
        </CCButtonSky>

        <Button 
          startIcon={<CancelOutlinedIcon />}
          sx={{
            px: 1.5,
            ml: 2,
            color: 'white',
            bgcolor: ccVar7Color, 
            ":hover": {
              backgroundColor: ccBgColor,
            },
          }}
          onClick={handleCancel}
        >
          Cancel
        </Button>
      </Box>
      {/* End Save, Cancel Button */}
    </RoleFields>
  )
}

export default CreateEditForm