import React, {createContext, useContext, useReducer} from "react"




const userReducer = (role, action) => {
  switch (action.type) {
    case 'set': {
      return action.role;
    }

    case 'created': {
      return [...userCreateEdit, {
        name: action.name,
        username: action.username,
        email: action.email,
        password: action.password,
        password_confirmation: action.password_confirmation,
      }];
    }

    case 'changed': {
      if (role.id === action.role.id) {
        return action.role;
      }else {
        return role;
      }
    }

    default: {
      throw Error('Unknown action: ' + action.type);
    }
  }
}

const RoleContext = createContext('')
const RoleDispatchContext = createContext('')

const useRole = () => {
  return useContext(RoleContext);
}
const useRoleDispatch = () => {
  return useContext(RoleDispatchContext);
}

const initRole = {
  id: '',
  title: '',
  name: '',
  status: [],
};

const RoleProvider = (props) => {
  const handleSetRole = (roleData) => {
    if (roleData) {
      dispatch({ 
        type: 'set', 
        role: {
          ...role,
          ...roleData,
        }
      });
    } 
    // else {
    //   dispatch({ type: 'set', user: initialUser });
    // }
  };

  const [role, dispatch] = useReducer(userReducer, initRole)

  return (
    <RoleContext.Provider value={{role, initRole, handleSetRole}}>
      <RoleDispatchContext.Provider value={dispatch}>
        {props.children}
      </RoleDispatchContext.Provider>
    </RoleContext.Provider>
  )
}

export 
{
  RoleProvider, 
  useRole, 
  useRoleDispatch,
};