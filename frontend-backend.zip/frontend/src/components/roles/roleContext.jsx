import {
  createContext, 
  useContext, 
  useState, 
  useCallback, 
  useEffect, 
  useReducer,
  useRef,
} from "react"
import { useError } from "errors/errorHook";
import axiosInstance from "plugins/axiosInstance";




const roleReducer = (role, action) => {
  switch (action.type) {
    case 'set': {
      return action.role;
    }

    case 'created': {
      return [...userCreateEdit, {
        name: action.name,
        username: action.username,
        email: action.email,
        password: action.password,
        password_confirmation: action.password_confirmation,
      }];
    }

    case 'changed': {
      if (role.id === action.role.id) {
        return action.role;
      }else {
        return role;
      }
    }

    default: {
      throw Error('Unknown action: ' + action.type);
    }
  }
}

const RoleContext = createContext('')
const RoleDispatchContext = createContext('')
const useRole = () => {
  return useContext(RoleContext);
}
const useRoleDispatch = () => {
  return useContext(RoleDispatchContext);
}

const initRole = {
  id: '',
  title: '',
  name: '',
  status: [],
};

const RoleProvider = (props) => {
  const [allRoles, setAllRoles] = useState([]);
  const [pageSize, setPageSize] = useState(20); // Default page size to 20
  const [rowCount, setRowCount] = useState(0);
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(false);
  const [sortModel, setSortModel] = useState([]);
  const [filterModel, setFilterModel] = useState({
    items: [],
  });
  const pageRef = useRef(0);
  const pageSizeRef = useRef(20);

  const setPageRef = (newPage) => {
    pageRef.current = newPage;
    setPage(newPage);
  };

  const setPageSizeRef = (newPageSize) => {
    pageSizeRef.current = newPageSize;
    setPageSize(newPageSize);
  };

  // Displaying error
  const {ccGetError} = useError();

  const fetchAllRoles = useCallback(async () => {
    setLoading(true);
    try {
      const result = await axiosInstance.get("/roles", {
        params: {
          page: pageRef.current + 1,
          pageSize: pageSizeRef.current,
          sortModel: JSON.stringify(sortModel),
          filterModel: JSON.stringify(filterModel),
        },
      });

      if (result.data.status === 'success') {
        const rolesWithSrl = result.data.role.map((role, index) => ({
          ...role,
          srl: pageRef.current * pageSizeRef.current + index + 1,
        }));
        setAllRoles(rolesWithSrl);
        setRowCount(result.data.total);
        setPageRef(result.data.current_page -1);
      } else {
        await ccGetError(result)
      }
    } catch (error) {
      await ccGetError(error)
    } finally {
      setLoading(false);
    }

  }, [page, pageSize, sortModel, filterModel]);

  useEffect(() => {
    fetchAllRoles();
  }, [fetchAllRoles]);

  const handleSetEditedRole = (roleData) => {
    if (roleData) {
      dispatch({ 
        type: 'set', 
        role: {
          ...role,
          ...roleData,
        }
      });
    }
  };

  const [role, dispatch] = useReducer(roleReducer, initRole)

  return (
    <RoleContext.Provider value={{
      role, 
      allRoles,
      rowCount,
      page,
      pageSize,
      loading,
      sortModel,
      filterModel,
      setAllRoles,
      setPage,
      setPageRef,
      setPageSize,
      setPageSizeRef,
      setSortModel,
      setFilterModel,
      fetchAllRoles,
      initRole, 
      handleSetEditedRole
    }}>
      <RoleDispatchContext.Provider value={dispatch}>
        {props.children}
      </RoleDispatchContext.Provider>
    </RoleContext.Provider>
  )
}

export 
{
  RoleProvider, 
  useRole, 
  useRoleDispatch,
};