import React, { useState, useEffect } from "react";
import { Box, FormControl, FormHelperText, MenuItem, InputLabel, OutlinedInput, Select, Chip} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import { useRole, useRoleDispatch } from "components/roles/roleContext";
import { CCAuthTextField, ccVar2Color, ccLargeFontColor } from "components/mui-customizations/styleCustomization";




const roleRegex = /^(?! )[A-Za-z]{2,}(?: [A-Za-z]{2,})*(?<! )$/;
const validateRole = value => roleRegex.test(value);

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

const selectItems = [
  { id: 1, value: 'Enable' },
  { id: 2, value: 'Disable' },
];

function getStyles(currentItemValue, selectedItemsValue, theme) {
  return {
    fontWeight:
    selectedItemsValue.indexOf(currentItemValue) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}

const RoleFields = ({ children, errorState, setErrorState, option }) => {

  // Role data from context to be set in the form
  const { role } = useRole();

  // Form data changes to dispatch to role context
  const dispatch = useRoleDispatch();

  // Role errors initial blank settings based on role dependency
  useEffect(() => {
    setErrorState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
      }
    }));
  }, [role]);

  // Logs of form state
  useEffect(() => {
    // console.log('role', role)
    // console.log('rolestate', roleState)
  }, [errorState]);



  // Error states update and dispatch fields changes to user context
  const handleFieldChange = event => {
    const { name, value } = event.target;

    const error = value.trim() === "" ? `Required ${name} field` : !validateRole(value) ? `Invalid ${name} format` : "" 

    dispatch({
      type: 'changed', 
      role: { 
        ...role, 
        [name]: value 
      } 
    });

    setErrorState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
        [name]: error
      }
    }));
  };

  const renderTextField = (name, label, type = "text", value = "", error = "") => (
    <FormControl sx={{ gridColumn: "span 1" }} error={!!error}>
      <CCAuthTextField
        name={name}
        label={label}
        type={type}
        value={value}
        id={name}
        placeholder={`Enter role ${label.toLowerCase()}`}
        required
        onChange={handleFieldChange}
        autoComplete="off"
      />
      <FormHelperText>{error}</FormHelperText>
    </FormControl>
  );

  const theme = useTheme();
  const [selectedItems, setSelectedItems] = useState([]);

  const handleSelectOptionChange = (event) => {
    const { name, value } = event.target;

    let error = '';
    let valueType = [];

    if (Array.isArray(value)) {
      if (value.includes("")) {
        if (value.length === 1) {
          error = `Required valid ${name} to select`;
        }
        valueType = [];
      } else {
        valueType = value;
        error = '';
      }
    } else {
      if (value === "") {
        if (selectedItems.length === 0) {
          error = `Required valid ${name} to select`;
        }
        valueType = [];
      } else {
        valueType = [value];
        error = '';
      }
    }

    setSelectedItems(valueType);

    setErrorState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
        [name]: error
      }
    }));
  };

  const renderSelectOption = (name, label, items, value = [], error = "") => (
    <FormControl sx={{ gridColumn: "span 1" }} size="small" required error={false}>
      <InputLabel id={`${name}-label`} sx={{ color: ccVar2Color }}>{label}</InputLabel>
      <Select
        name={name}
        value={value}
        id={name}
        labelId={`${name}-label`}
        multiple
        onChange={handleSelectOptionChange}
        input={<OutlinedInput id={`${name}-select`} label={label} />}
        renderValue={(selected) => (
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
            {selected.map((selectedValue) => (
              items.filter(itemValue => itemValue.id === selectedValue).map(itemValue => (
                <Chip key={itemValue.id} label={itemValue.value} sx={{ height:"23px" }} />
              ))
            ))}
          </Box>
        )}
        MenuProps={MenuProps}
        sx={{
          fieldset: {
            borderColor: ccVar2Color + "!important",
            color: ccVar2Color + "important",
          },
          label: {
            color: ccVar2Color,
            "&:hover": {
              color: ccLargeFontColor + "!important",
            },
          },
        }}
      >
        {/* Use for single select, comment out for multi select */}
        <MenuItem value="">
          <em>None</em>
        </MenuItem>
        {items.map((currentItem) => (
          <MenuItem
            key={currentItem.id}
            value={currentItem.id}
            style={getStyles(currentItem.id, value, theme)} 
          >
            {currentItem.value}
          </MenuItem>
        ))}
      </Select>
      <FormHelperText sx={{ color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  )

  return (
    <Box
      component="form"
      sx={{
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: 2,
        width: '100%',
      }}
      noValidate
      autoComplete="off"
    >
      {renderTextField('title', 'Title', 'text', role.title, errorState.errors.title)}
      {renderTextField('name', 'Name', 'text', role.name, errorState.errors.name)}
      {renderSelectOption('state', 'State', selectItems, selectedItems, errorState.errors.state)}
      {children}
    </Box>
  );
};

export default RoleFields;
