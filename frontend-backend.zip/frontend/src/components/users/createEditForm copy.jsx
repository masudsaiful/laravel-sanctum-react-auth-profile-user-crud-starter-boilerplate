import React, { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom";
import {Box, Button} from '@mui/material';
import SaveAsTwoToneIcon from '@mui/icons-material/SaveAsTwoTone';
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
import Swal from "sweetalert2";
import axiosInstance from "plugins/axiosInstance";
import UserFields from "components/users/userFields";
import { useUser } from "components/users/userContext";
import { useAuth } from "auths/hooks/authHook";
import { useUserDispatch } from "components/users/userContext";
import { useError } from "errors/errorHook";
import wordsUpperCase from "utilities/wordsUpperCase";
import useCurrentPages from "../layouts/hooks/currentPagesHook";
import { 
  ccBgColor,
  ccVar7Color,
  CCButtonSky,
  ccLargeFontColor,
  ccBgVar1Color,
} from "components/mui-customizations/styleCustomization";




// Initial null error object
const initErrors = {
  errors: {
    name: '',
    username: '',
    email: '',
    status: '',
    password: '',
    passwordConfirmation: ''
  }
}

const CreateEditForm = ({option, id}) => {
  // Initial errors state set
  const [formState, setFormState] = useState(initErrors);

  // Handling and setting edited user in user context
  const {user, initUser, handleSetEditedUser} = useUser();

  // Handling and setting edited profile in auth context
  const {fetchProfile, profile, handleSetEditedProfile} = useAuth();

  // User context dispatch
  const dispatch = useUserDispatch();

  // Error context errors to display 
  const {ccGetError} = useError();

  const navigate = useNavigate();

  // Current page start path
  const {currentFirstPath} = useCurrentPages();

  // Edited user state from API
  const [editedUser, setEditedUser] = useState(null)

  // Error object properties only truthy
  // const newFormStateObj = Object.
  // keys(formState.errors).
  // filter(key => formState.errors[key]).
  // reduce((obj, key) => {
  //   obj[key] = formState.errors[key]
  //   return obj
  // }, {})

  // Getting and setting edited user from API
  const handleGetEditedUser = async () => {
    try {
      const result = await axiosInstance.get(`/users/${id}`)
      if(result.data.status === "success" ) {
        setEditedUser(result.data.user)
      } else {
        setEditedUser('')
        await ccGetError(result)
      }
    } catch (error) {
      setEditedUser('')
      await ccGetError(error)
    }
  }

  const handleSubmitEdited = async () => {
    try {
      const result = await axiosInstance.put(`/users/${user.id}`, user)
      if(result.data.status === "success" ) {
        currentFirstPath === 'profile' ? await handleSetEditedProfile(result.data.user) : setEditedUser(result.data.user);
        Swal.fire({
          title: `${wordsUpperCase(result.data.status)}!`, 
          text: result.data.message, 
          icon: "success",
          iconColor: ccLargeFontColor,
          color: ccLargeFontColor,
          confirmButtonColor: ccLargeFontColor,
          background: ccBgVar1Color,
        })
      } else {
        await ccGetError(result)
      }
    } catch (error) {
      await ccGetError(error)
    }
  }

  const handleSubmitCreated = async () => {
    try {
      const result = await axiosInstance.post('/users', user)
      if(result.data.status === "success" ) {
        Swal.fire({
          title: `${wordsUpperCase(result.data.status)}!`, 
          text: result.data.message, 
          icon: "success",
          iconColor: ccLargeFontColor,
          color: ccLargeFontColor,
          confirmButtonColor: ccLargeFontColor,
          background: ccBgVar1Color,
          timer: 1500,
        }).then(result => {
          navigate("/user/list")
        })
      } else {
        await ccGetError(result)
      }
    } catch (error) {
      await ccGetError(error)
    }
  }

  const handleCancleEdited = () => {
    if (id) {
      dispatch({ 
        type: 'changed', 
        user: editedUser 
      });
    } else {
      dispatch({ 
        type: 'changed', 
        user: profile 
      });
    }
    setFormState(initErrors);
  }

  const handleCancleCreated = () => {
    dispatch({ 
      type: 'changed', 
      user: initUser, 
    });
    setFormState(initErrors);
  }

  useEffect(() => {
    if (option === 'edited') {
      if (id) {
        const fetchEditedUser = async () => {
          await handleGetEditedUser();
        };
        fetchEditedUser();
      } else {
        fetchProfile();
      }
    }
  }, []);

  useEffect(() => {
    if (option === 'edited') {
      if (id) {
        if (editedUser !== null) {
          handleSetEditedUser(editedUser);
        }
      } else {
        if (profile) {
          handleSetEditedUser(profile);
        }
      }
    }
  }, [editedUser, profile]);

  const handleSubmit = async (e) => {
    dispatch({
      type: "set",
      user: user,
    })
    // if (Object.keys(newFormStateObj).length > 0) {
    if (Object.keys(formState.errors).filter(key => formState.errors[key]).length > 0) {
      // await ccGetError({errors:newFormStateObj})
      await ccGetError(formState)
    } else {
      e.preventDefault();
      option === 'edited' && handleSubmitEdited()
      option === 'created' && handleSubmitCreated()
    }
  };

  const handleCancel = () => {{ 
    option === 'edited' && handleCancleEdited()
    option === 'created' && handleCancleCreated()
  }};

  return (
    <UserFields 
      formState={formState} 
      setFormState={setFormState}
      option={option}
    >
      {/* Save, Cancel Button */}
      <Box sx={{gridColumn: 'span 3', mt: 2}}>
        <CCButtonSky 
          startIcon={<SaveAsTwoToneIcon />}
          endIcon=""
          onClick={handleSubmit}
          sx={{ ml: 0 }}
        >
          {option === 'edited' ?  'Save Changes'  : 'Create'}
        </CCButtonSky>

        <Button 
          startIcon={<CancelOutlinedIcon />}
          sx={{
            px: 1.5,
            ml: 2,
            color: 'white',
            bgcolor: ccVar7Color, 
            ":hover": {
              backgroundColor: ccBgColor,
            },
          }}
          onClick={handleCancel}
        >
          Cancel
        </Button>
      </Box>
      {/* End Save, Cancel Button */}
    </UserFields>
  )
}

export default CreateEditForm