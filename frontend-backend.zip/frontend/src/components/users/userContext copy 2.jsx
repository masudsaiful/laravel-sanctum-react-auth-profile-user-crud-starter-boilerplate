import React, { createContext, useContext, useReducer, useCallback, useState } from "react";
import axiosInstance from "plugins/axiosInstance"; // Ensure this import is correct

// Define the userReducer and context as before
const userReducer = (user, action) => {
  switch (action.type) {
    case 'set':
      return action.user;
    case 'created':
      return [...user, action.newUser];
    case 'changed':
      return user.map(u => u.id === action.user.id ? action.user : u);
    default:
      throw Error('Unknown action: ' + action.type);
  }
};

const UserContext = createContext();
const UserDispatchContext = createContext();

const useUser = () => useContext(UserContext);
const useUserDispatch = () => useContext(UserDispatchContext);

const UserProvider = (props) => {
  const [user, dispatch] = useReducer(userReducer, []);
  const [loading, setLoading] = useState(false);
  const [rowCount, setRowCount] = useState(0);

  const fetchUsers = useCallback(async (page, pageSize, sortModel, filterModel) => {
    setLoading(true);
    try {
      const result = await axiosInstance.get("/users", {
        params: {
          page: page + 1,
          pageSize,
          sortModel: JSON.stringify(sortModel),
          filterModel: JSON.stringify(filterModel),
        },
      });
      const usersWithSrl = result.data.data.map((user, index) => ({
        ...user,
        srl: page * pageSize + index + 1,
      }));
      dispatch({ type: 'set', user: usersWithSrl });
      setRowCount(result.data.total);
    } catch (error) {
      console.error(error);
    }
    setLoading(false);
  }, []);

  return (
    <UserContext.Provider value={{ user, fetchUsers, loading, rowCount }}>
      <UserDispatchContext.Provider value={dispatch}>
        {props.children}
      </UserDispatchContext.Provider>
    </UserContext.Provider>
  );
}

export { UserProvider, useUser, useUserDispatch };
