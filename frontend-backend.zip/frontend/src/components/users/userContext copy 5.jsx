import {
  createContext, 
  useContext, 
  useState, 
  useCallback, 
  useEffect, 
  useReducer
} from "react"
import { useError } from "errors/errorHook";
import axiosInstance from "plugins/axiosInstance";




const userReducer = (user, action) => {
  switch (action.type) {
    case 'set': {
      return action.user;
    }

    case 'created': {
      return [...userCreateEdit, {
        name: action.name,
        username: action.username,
        email: action.email,
        password: action.password,
        password_confirmation: action.password_confirmation,
      }];
    }

    case 'changed': {
      if (user.id === action.user.id) {
        return action.user;
      }else {
        return user;
      }
    }

    default: {
      throw Error('Unknown action: ' + action.type);
    }
  }
}

const UserContext = createContext('')
const UserDispatchContext = createContext('')
const useUser = () => {
  return useContext(UserContext);
}
const useUserDispatch = () => {
  return useContext(UserDispatchContext);
}

const initUser = {
  id: '',
  name: '',
  username: '',
  email: '',
  status: [],
  password: '',
  password_confirmation: '',
};

const UserProvider = (props) => {
  const [allUsers, setAllUsers] = useState([]);
  const [pageSize, setPageSize] = useState(20); // Default page size to 20
  const [rowCount, setRowCount] = useState(0);
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(false);
  const [sortModel, setSortModel] = useState([]);
  const [filterModel, setFilterModel] = useState({
    items: [],
  });

  // Displaying error
  const {ccGetError} = useError();

  const fetchAllUsers = useCallback(async (page = 0) => {
    setLoading(true);
    try {
      const result = await axiosInstance.get("/users", {
        params: {
          page,
          pageSize,
          sortModel: JSON.stringify(sortModel),
          filterModel: JSON.stringify(filterModel),
        },
      });
      
      if (result.data.status === 'success') {
        const usersWithSrl = result.data.user.map((user, index) => ({
          ...user,
          srl: current_page * pageSize + index + 1,
        }));
        setAllUsers(usersWithSrl);
        setRowCount(result.data.total);
        setPage(page);
      } else {
        await ccGetError(result)
      }
    } catch (error) {
      await ccGetError(error)
    } finally {
      setLoading(false);
    }
  }, [pageSize, sortModel, filterModel]);

  useEffect(() => {
    fetchAllUsers(page);
  }, [fetchAllUsers, page]);

  const handleSetEditedUser = (userData) => {
    if (userData) {
      dispatch({ 
        type: 'set', 
        user: {
          ...user,
          ...userData,
        }
      });
    } 
  };

  const [user, dispatch] = useReducer(userReducer, initUser)

  return (
    <UserContext.Provider value={{
      user, 
      allUsers,
      rowCount,
      page,
      pageSize,
      loading,
      sortModel,
      filterModel,
      setAllUsers,
      setPage,
      setPageSize,
      setSortModel,
      setFilterModel,
      fetchAllUsers,
      initUser, 
      handleSetEditedUser
    }}>
      <UserDispatchContext.Provider value={dispatch}>
        {props.children}
      </UserDispatchContext.Provider>
    </UserContext.Provider>
  )
}

export 
{
  UserProvider, 
  useUser, 
  useUserDispatch,
};