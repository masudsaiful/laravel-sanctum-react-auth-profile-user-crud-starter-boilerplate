import React, {createContext, useContext, useReducer} from "react"
// import { useAuth } from "auths/hooks/authHook"
// import { useLocation } from "react-router-dom";




const userReducer = (user, action) => {
  switch (action.type) {
    case 'set': {
      return action.user;
    }

    case 'created': {
      return [...userCreateEdit, {
        name: action.name,
        username: action.username,
        email: action.email,
        password: action.password,
        password_confirmation: action.password_confirmation,
      }];
    }

    case 'changed': {
      if (user.id === action.user.id) {
        return action.user;
      }else {
        return user;
      }
    }

    default: {
      throw Error('Unknown action: ' + action.type);
    }
  }

}

const UserContext = createContext('')
const UserDispatchContext = createContext('')

const useUser = () => {
  return useContext(UserContext);
}
const useUserDispatch = () => {
  return useContext(UserDispatchContext);
}

const initialUser = {
  id: '',
  name: '',
  username: '',
  email: '',
  status: [],
  password: '',
  password_confirmation: '',
};

const UserProvider = (props) => {
  // const location = useLocation();
  // const {profile} = useAuth();

  // let initialUsers = ''
  // if (location.pathname === '/profile') {
  //   initialUsers =  [{
  //     "id": 3,
  //     "name": "saifulmasud1",
  //     "username": "saifulmasu1",
  //     "email": "saifulmasud1@gmail.com",
  //   }]
  // } else {
  //   initialUsers = [profile];
  // }

  const handleUser = (userData) => {
    if (userData) {
      dispatch({ 
        type: 'set', 
        user: {
          ...user,
          ...userData,
        }
      });
    } 
    // else {
    //   dispatch({ type: 'set', user: initialUser });
    // }
  };

  const [user, dispatch] = useReducer(userReducer, initialUser)

  return (
    <UserContext.Provider value={{user, initialUser, handleUser}}>
      <UserDispatchContext.Provider value={dispatch}>
        {props.children}
      </UserDispatchContext.Provider>
    </UserContext.Provider>
  )
}

export 
{
  UserProvider, 
  useUser, 
  useUserDispatch,
};