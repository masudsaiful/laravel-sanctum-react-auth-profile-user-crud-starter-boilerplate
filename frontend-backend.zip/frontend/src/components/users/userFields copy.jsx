import React, { useState, useEffect, } from "react";
import { useTheme } from '@mui/material/styles';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { useUser, useUserDispatch } from "components/users/userContext";
import { CCAuthTextField, ccVar2Color } from "components/mui-customizations/styleCustomization";
import CCSingleSelect from "components/mui-customizations/singleSelectCustomization";
import { 
  Box, 
  FormControl, 
  FormHelperText, 
  InputLabel, 
  OutlinedInput, 
  InputAdornment, 
  IconButton 
} from '@mui/material';




// Status items
const selectItems = [
  { id: 1, value: 'Enable' },
  { id: 2, value: 'Disable' },
];

// Regex to check email
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// // Regex to check fields
// const fieldRegex = /^(?! )[A-Za-z0-9]{2,}(?: [A-Za-z0-9]{2,})*(?<! )$/;

// Regex to check fields
// First letter, no single char, at least two chars for multi words
const fieldRegex = /^[A-Za-z][A-Za-z0-9]{1,}(?: [A-Za-z0-9]{2,})*$/;

const UserFields = ({children, formState, setFormState, option}) => {
  // User data from context to be set in the form
  const { user } = useUser();
  const dispatch = useUserDispatch();

  // Selected status state
  const theme = useTheme();
  const [selectedItems, setSelectedItems] = useState('');

  // Email regex tested evaluate to true
  const validateEmail = email => emailRegex.test(email);

  // Regex tested evaluate field to true
  const validateField = value => fieldRegex.test(value);

  // Password visibility eye icon toggle
  const [showPassword, setShowPassword] = useState(false);
  const handleClickShowPassword = () => {
    return setShowPassword((show) => !show);
  }
  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  // Confirmed initial selected state and error state set
  useEffect(() => {
    if (user && user.status && Array.isArray(user.status) && user.status.length > 0) {
      setSelectedItems(user.status[0]);
    } else {
      setSelectedItems('');
    }
  
    setFormState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
      }
    }));
  }, [user]);

  // Logs of form state
  useEffect(() => {
    // console.log('user', user)
    // console.log('formstate', formState)
  }, [formState]);

  // Updated field states to user context, updated error states
  const handleFieldChange = event => {
    const { name, value } = event.target;

    // const error = 
    // name === 'email' && value.trim() === "" 
    // ? `Required ${name} field` 
    // : name === 'email' && !validateEmail(value) 
    //   ? 'Invalid email format' 
    //   : value.trim() === "" 
    //     ? `Required ${name} field` 
    //     : !validateField(value) 
    //       ? `Invalid ${name} format` 
    //       : "";


    const error = 
    name === 'email'
    ? value.trim() === "" 
      ? `Required ${name} field` 
      : !validateEmail(value) 
        ? `Invalid ${name} format` 
        : ""
    : value.trim() === "" 
      ? `Required ${name} field` 
      : !validateField(value) 
        ? `Invalid ${name} format` 
        : "";

    dispatch({
      type: 'changed', 
      user: { 
        ...user, 
        [name]: value 
      } 
    });

    setFormState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
        [name]: error
      }
    }));
  };


  // Password changes status and error update if any
  const handlePasswordChange = event => {
    const { name, value } = event.target;

    const passwordError = value.length > 0 && value.length < 8 ? 'Password must be at least 8 characters' : '';
    const passwordConfirmationError = value !== user.password_confirmation ? 'Passwords do not match' : '';

    dispatch({
      type: 'set', 
      user: { 
        ...user, 
        [name]: value,
      } 
    });

    setFormState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
        [name]: passwordError,
        passwordConfirmation: passwordConfirmationError
      }
    }));
  };

  // Confirm password changes status and error update if any
  const handlePasswordConfirmationChange = event => {
    const { name, value } = event.target;

    dispatch({
      type: 'changed', 
      user: { 
        ...user, 
        [name]: value 
      } 
    });

    setFormState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
        passwordConfirmation: value !== user.password ? 'Passwords do not match' : ''
      }
    }));
  };


  const handleSingleSelectChange = (event) => {
    const { name, value } = event.target;
    let selectedValue = value;
    let selectError = '';

    if (selectedValue === '') {
      setSelectedItems('');
      selectError = `Required valid ${name} to select`;
    } else {
      setSelectedItems(selectedValue);
      selectError = ''
    }

    // Update the user context with the selected value
    dispatch({
      type: 'changed',
      user: {
        ...user,
        [name]: selectedValue ? [selectedValue] : [], // Save as an array or an empty array
      }
    });
    
    // Update the error state with errors if any
    setFormState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
        [name]: selectError
      }
    }));
  };

  const renderTextField = (name, label, type = "text", value = "", error = "") => (
    <FormControl sx={{ gridColumn: "span 1" }} error={!!error}>
      <CCAuthTextField
        type={type === "password" ? (showPassword ? "text" : type) : type}
        name={name}
        id={name}
        label={label}
        value={type === "password" ? value ? value : "" : value}
        placeholder={`Enter ${label.toLowerCase()}`}
        required={type === "password" ? option === 'edited' ? false : true : true}
        onChange={
          name.includes("password")
            ? name === "password"
              ? handlePasswordChange
              : handlePasswordConfirmationChange
            : handleFieldChange
        }
        autoComplete={type === "password" ? "new-password" : "on"}
        endAdornment={
          type === "password" && (
            <InputAdornment position="end">
              <IconButton
                aria-label="toggle password visibility"
                onClick={handleClickShowPassword}
                onMouseDown={handleMouseDownPassword}
                edge="end"
              >
                {showPassword ? <VisibilityOff /> : <Visibility />}
              </IconButton>
            </InputAdornment>
          )
        }
      />
      <FormHelperText>{error}</FormHelperText>
    </FormControl>
  );

  const renderSelectOption = (name, label, items, value = '', error = "") => (
    <FormControl sx={{ gridColumn: "span 1" }} size="small" required error={false}>
      <InputLabel id={`${name}-label`} sx={{ color: ccVar2Color }}>{label}</InputLabel>
      <CCSingleSelect
        name={name}
        value={value}
        id={name}
        labelId={`${name}-label`}
        onChange={handleSingleSelectChange}
        input={<OutlinedInput id={`${name}-select`} label={label} />}
        items={items}
        // multiple
      />
      <FormHelperText sx={{ color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  );

  return (
    <Box
      component="form"
      sx={{
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',    
        gap: 2,
        width: '100%',
      }}
      noValidate
      autoComplete="off"
    >
      {renderTextField('name', 'Name', 'text', user.name, formState.errors.name)}
      {renderTextField('username', 'Username', 'text', user.username, formState.errors.username)}
      {renderTextField('email', 'E-mail', 'email', user.email, formState.errors.email)}
      {renderTextField('password', 'Password', 'password', user.password, formState.errors.password)}
      {renderTextField('password_confirmation', 'Password Confirmation', 'password', user.password_confirmation, formState.errors.passwordConfirmation)}
      {renderSelectOption('status', 'Status', selectItems, selectedItems, formState.errors.status)}                                                             
      {children}
    </Box>
  );
};

export default UserFields;