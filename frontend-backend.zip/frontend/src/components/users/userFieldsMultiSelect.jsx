import React, { useState, useEffect } from "react";
import { Box, FormControl, FormHelperText, InputLabel, OutlinedInput, InputAdornment, IconButton } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { useUser, useUserDispatch } from "components/users/userContext";
import { CCAuthTextField, ccVar2Color } from "components/mui-customizations/styleCustomization";
import CCMultiSelect from "components/mui-customizations/multiSelectCustomization";




// Status items
const selectItems = [
  { id: 1, value: 'Enable' },
  { id: 2, value: 'Disable' },
];

// Regex to check email
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const UserFields = ({children, formState, setFormState, option}) => {
  // User data from context to be set in the form
  const { user } = useUser();
  const dispatch = useUserDispatch();

  // Selected status state
  const theme = useTheme();
  const [selectedItems, setSelectedItems] = useState([]);

  // Password visibility eye icon toggle
  const [showPassword, setShowPassword] = useState(false);
  const handleClickShowPassword = () => {
    return setShowPassword((show) => !show);
  }
  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  // Blank email or regex tested email evaluate to true
  const validateEmail = email => emailRegex.test(email);

  // Confirmed initial selected state and error state set
  useEffect(() => {
    if (user && user.status && Array.isArray(user.status) && user.status.length > 0) {
      setSelectedItems(user.status);
      // dispatch({
      //   type: 'changed',
      //   user: {
      //     ...user,
      //     status: Array.isArray(user.status) ? user.status : [user.status]
      //   }
      // });
    } else {
      setSelectedItems([]);
    }
  
    setFormState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
      }
    }));
  }, [user]);

  // Logs of form state
  useEffect(() => {
    // console.log('user', user)
    // console.log('formstate', formState)
  }, [formState]);

  // Error states update and dispatch fields changes to user context
  const handleFieldChange = event => {
    const { name, value } = event.target;

    // const error =
    //   name === "email"
    //   ? !validateEmail(value)
    //     ? "Invalid email format"
    //     : value
    //       ? ""
    //       : `Required ${name} field`
    //   : value
    //     ? ""
    //     : `Required ${name} field`;

    // const error = name === 'email' && !validateEmail(value) ? 'Invalid email format' : '';

    const error = name === 
    'email' && value.trim() === "" ? 
    `Required ${name} field` : 
    name === 'email' && !validateEmail(value) ? 
    'Invalid email format' : 
    value.trim() === "" ? 
    `Required ${name} field` : 
    "";

    dispatch({
      type: 'changed', 
      user: { 
        ...user, 
        [name]: value 
      } 
    });

    setFormState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
        [name]: error
      }
    }));
  };


  // Password changes status and error update if any
  const handlePasswordChange = event => {
    const { name, value } = event.target;

    const passwordError = value.length > 0 && value.length < 8 ? 'Password must be at least 8 characters' : '';
    const passwordConfirmationError = value !== user.password_confirmation ? 'Passwords do not match' : '';

    dispatch({
      type: 'set', 
      user: { 
        ...user, 
        [name]: value,
      } 
    });

    setFormState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
        [name]: passwordError,
        passwordConfirmation: passwordConfirmationError
      }
    }));


  };

  // Confirm password changes status and error update if any
  const handlePasswordConfirmationChange = event => {
    const { name, value } = event.target;

    dispatch({
      type: 'changed', 
      user: { 
        ...user, 
        [name]: value 
      } 
    });

    setFormState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
        passwordConfirmation: value !== user.password ? 'Passwords do not match' : ''
      }
    }));
  };

  const handleSelectOptionChange = (event) => {
    const { name, value } = event.target;
    let selectedValue = value;
    let error = '';

    if (selectedValue === '') {
      setSelectedItems([]);
      selectedValue = []; // Set to an empty array
      error = `Required valid ${name} to select`;
    } else {
      // Ensure selectedValue is always treated as an array
      selectedValue = Array.isArray(selectedValue) ? selectedValue : [selectedValue];
      setSelectedItems(selectedValue);
    }

    // Update the user context with the selected value
    dispatch({
      type: 'changed',
      user: {
        ...user,
        [name]: selectedValue.length > 0 ? selectedValue : [], // Save as an array or an empty array
      }
    });
    
    // Update the form state with errors if any
    setFormState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
        [name]: error
      }
    }));
  };

  const renderTextField = (name, label, type = "text", value = "", error = "") => (
    <FormControl sx={{ gridColumn: "span 1" }} error={!!error}>
      <CCAuthTextField
        type={type === "password" ? (showPassword ? "text" : type) : type}
        name={name}
        id={name}
        label={label}
        value={type === "password" ? value ? value : "" : value}
        placeholder={`Enter ${label.toLowerCase()}`}
        required={type === "password" ? option === 'edited' ? false : true : true}
        onChange={
          name.includes("password")
            ? name === "password"
              ? handlePasswordChange
              : handlePasswordConfirmationChange
            : handleFieldChange
        }
        autoComplete={type === "password" ? "new-password" : "on"}
        endAdornment={
          type === "password" && (
            <InputAdornment position="end">
              <IconButton
                aria-label="toggle password visibility"
                onClick={handleClickShowPassword}
                onMouseDown={handleMouseDownPassword}
                edge="end"
              >
                {showPassword ? <VisibilityOff /> : <Visibility />}
              </IconButton>
            </InputAdornment>
          )
        }
      />
      <FormHelperText>{error}</FormHelperText>
    </FormControl>
  );

  const renderSelectOption = (name, label, items, value = '', error = "") => (
    <FormControl sx={{ gridColumn: "span 1" }} size="small" required error={false}>
      <InputLabel id={`${name}-label`} sx={{ color: ccVar2Color }}>{label}</InputLabel>
      <CCMultiSelect
        name={name}
        value={value}
        id={name}
        labelId={`${name}-label`}
        onChange={handleSelectOptionChange}
        input={<OutlinedInput id={`${name}-select`} label={label} />}
        items={items}
        multiple
      />
      <FormHelperText sx={{ color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  );

  return (
    <Box
      component="form"
      sx={{
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: 2,
        width: '100%',
      }}
      noValidate
      autoComplete="off"
    >
      {renderTextField('name', 'Name', 'text', user.name, formState.errors.name)}
      {renderTextField('username', 'Username', 'text', user.username, formState.errors.username)}
      {renderTextField('email', 'E-mail', 'email', user.email, formState.errors.email)}
      {renderTextField('password', 'Password', 'password', user.password, formState.errors.password)}
      {renderTextField('password_confirmation', 'Password Confirmation', 'password', user.password_confirmation, formState.errors.passwordConfirmation)}
      {renderSelectOption('status', 'Status', selectItems, selectedItems, formState.errors.status)}
      {children}
    </Box>
  );
};

export default UserFields;