// UserList.jsx
import React, { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import axiosInstance from "plugins/axiosInstance";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";  
import IconButton from "@mui/material/IconButton";
import { Box, Chip } from "@mui/material";
import { useError } from "errors/errorHook";
import wordsUpperCase from "utilities/wordsUpperCase";
import CCDataGrid from "components/mui-customizations/dataGridCustomization";
import { useUser } from "components/users/userContext";
import { 
  swalLoginRegisterAlert 
} from "components/swal-customizations/styleCustomization";
import { 
  ccVar7Color,
  ccVar2Color,
  ccBgVar1Color,
  ccLargeFontColor,
} from 'components/mui-customizations/styleCustomization';


const UserList = () => {
  const {
    allUsers, 
    rowCount, 
    page, 
    pageSize,   
    sortModel, 
    filterModel, 
    loading,
    setPage, 
    setPageSize,
    setSortModel,
    setFilterModel, 
    fetchAllUsers
  } = useUser();
  const [selectedIds, setSelectedIds] = useState([]);
  const { ccGetError } = useError();

  useEffect(() => {
    fetchAllUsers();
  }, [fetchAllUsers]);

  const handleDelete = async (id) => {
    try {
      swalLoginRegisterAlert.fire({
        title: 'Are you sure?', 
        text: "You won't be able to revert this!", 
        confirmButtonText: "Yes, delete it!",
        icon: "warning",
        showCancelButton: true,
        color: ccVar7Color,
        confirmButtonColor: ccVar2Color,
        cancelButtonColor: ccVar7Color,
        background: ccBgVar1Color,
      }).then(async result => {
        if (result.isConfirmed) {
          const result = await axiosInstance.delete(`/users/${id}`);
          if(result.data.status === "success" ) {
            fetchAllUsers();
            swalLoginRegisterAlert.fire({
              title: `Deleted ${wordsUpperCase(result.data.status)}!`, 
              text: result.data.message, 
              icon: "success",
              iconColor: ccVar2Color,
              color: ccVar7Color,
              confirmButtonColor: ccLargeFontColor,
              background: ccBgVar1Color,
              timer: 11500,
            });
          } else {
            await ccGetError(result);
          }
        }
      });
    } catch (error) {
      await ccGetError(error);
    }
  };

  const handleBulkDelete = async () => {
    try {
      swalLoginRegisterAlert.fire({
        title: 'Are you sure?', 
        text: "You won't be able to revert this!", 
        confirmButtonText: "Yes, delete it!",
        icon: "warning",
        showCancelButton: true,
        color: ccVar7Color,
        confirmButtonColor: ccVar2Color,
        cancelButtonColor: ccVar7Color,
        background: ccBgVar1Color,
      }).then(async result => {
        if (result.isConfirmed) {
          await Promise.all(selectedIds.map((id) => axiosInstance.delete(`/users/${id}`)));
          setSelectedIds([]);
          fetchAllUsers();
          swalLoginRegisterAlert.fire({
            title: `Deleted Success!`, 
            text: 'User(s) has been deleted', 
            icon: "success",
            iconColor: ccVar2Color,
            color: ccVar7Color,
            confirmButtonColor: ccLargeFontColor,
            background: ccBgVar1Color,
            timer: 11500,
          });
        }
      });
    } catch (error) {
      await ccGetError(error);
    }
  };

  const columns = useMemo(() => [
    { field: "srl", headerName: "SR", headerAlign: 'center', align: 'center', flex: 0.35, minWidth: 50, sortable: false, filterable: false },
    { field: "id", headerName: "ID", headerAlign: 'center', align: 'center', flex: 0.45, minWidth: 50, },
    { field: "name", headerName: "Name", headerAlign: 'center', flex: 1, minWidth: 50, editable: true },
    { field: "username", headerName: "User Name", headerAlign: 'center', flex: 1, minWidth: 50, editable: true },
    { field: "email", headerName: "Email", headerAlign: 'center', flex: 1, minWidth: 50, editable: true },
    { 
      field: "status", 
      headerName: "Status", 
      headerAlign: 'center', 
      align: 'center', 
      flex: 0.55, 
      minWidth: 50, 
      editable: true,
      renderCell: (params) => (
        params.value === 1 ? (
          <Chip 
            label="Enable"
            size="medium"
            sx={{
              backgroundColor: ccVar2Color + 'ad' ,
              color: 'white'
            }} 
            variant="outlined" 
          />
        ) : 
        <Chip 
          label="Disable"
          size="medium"
          sx={{
            backgroundColor: ccVar7Color + 'ad',
            color: 'white'
          }} 
          variant="outlined" 
        />
      )
    },
    {
      field: "actions",
      headerName: "Actions",
      headerAlign: 'center',
      align: 'center',
      flex: 0.65,
      minWidth: 50,
      renderCell: (params) => (
        <>
          <IconButton
            component={Link}
            to={`/user/edit/${params.id}`}
            color="primary"
          >
            <EditIcon />
          </IconButton>
          <IconButton
            onClick={(event) => {
              event.stopPropagation(); // Prevents the row from being selected
              handleDelete(params.id);
            }}
            color="secondary"
          >
            <DeleteIcon />
          </IconButton>
        </>
      ),
    },
  ], []);

  // Calculate the total height
  const rowHeight = 52;
  const headerHeight = 56;
  const footerHeight = 56;
  const calculatedHeight = 
    allUsers && allUsers.length > 0 
      ? selectedIds.length > 0 
        ? (allUsers.length * rowHeight) + headerHeight + footerHeight + 53 
        : (allUsers.length * rowHeight) + headerHeight + footerHeight 
      : 200;

  return (
    <Box 
      height={calculatedHeight}
      width="100%"
    >
      <CCDataGrid
        rows={allUsers}
        columns={columns}
        rowCount={rowCount}
        pageSize={pageSize}
        page={page}
        setPage={setPage}
        setPageSize={setPageSize}
        sortModel={sortModel}
        setSortModel={setSortModel}
        filterModel={filterModel}
        setFilterModel={setFilterModel}
        loading={loading}
        selectedIds={selectedIds}
        setSelectedIds={setSelectedIds}
        onBulkDelete={handleBulkDelete}
      />
    </Box>
  );
};

export default UserList;
