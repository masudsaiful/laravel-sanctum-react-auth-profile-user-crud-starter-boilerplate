import React, { useState, useEffect, useCallback, useMemo } from "react";
import { DataGrid, gridClasses } from "@mui/x-data-grid";
import { Link } from "react-router-dom";
import axiosInstance from "plugins/axiosInstance";
import { styled } from "@mui/material/styles";
import Button from "@mui/material/Button";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";  
import IconButton from "@mui/material/IconButton";
import { Box, Stack } from "@mui/material";
import { useError } from "errors/errorHook";
import wordsUpperCase from "utilities/wordsUpperCase";
import { 
  swalLoginRegisterAlert 
} from "components/swal-customizations/styleCustomization";
import { 
  ccBgColor,
  ccVar1Color, 
  ccVar4Color,
  ccVar1CommonGap,
  ccVar2CommonGap,
  ccVar7Color,
  ccVar2Color,
  ccBgVar1Color,
  ccLargeFontColor,
} from 'components/mui-customizations/styleCustomization';





const StripedStyledDataGrid = styled(DataGrid)(({ theme }) => ({
  [`& .${gridClasses.row}.even`]: {
    backgroundColor: ccVar4Color + "26",
    "&:hover": {
      backgroundColor: ccVar1Color + "a3",
      "@media (hover: none)": {
        backgroundColor: ccVar1Color,
      },
    },
    "&.Mui-selected": {
      backgroundColor: ccVar1Color,
      "&:hover": {
        backgroundColor: ccVar1Color + "a3",
        // Reset on touch devices, it doesn't add specificity
        "@media (hover: none)": {
          backgroundColor: ccVar1Color + "a3",
        },
      },
    },
  },
  "& .MuiDataGrid-container--top [role=row]": {
    backgroundColor: "#009dff",
    color: "#ffffff",
    borderTopLeftRadius: "5px",
    borderTopRightRadius: "5px",
    "& .MuiDataGrid-columnHeaderTitle, & .MuiIconButton-root, & .MuiSvgIcon-root": {
      color: "#ffffff",
    },
  },
  "& .MuiDataGrid-columnHeader:focus, & .MuiDataGrid-columnHeader:focus-within": {
    outline: "none",
  },
  "& .MuiDataGrid-row:hover": {
    backgroundColor: ccVar1Color + "a3",
  },
  "& .Mui-selected": {
    backgroundColor: ccVar1Color + "a3!important",
  },
  "& .Mui-selected:hover": {
    backgroundColor: ccVar1Color + "!important",
  },
  "& .MuiDataGrid-cell--selected": {
    backgroundColor: "red !important",
    color: "#ffffff !important",
  },
  "& .MuiDataGrid-footerContainer": {
    backgroundColor: ccVar4Color + "61",
    borderBottomLeftRadius: "5px",
    borderBottomRightRadius: "5px",
  },
}));

const RoleList = () => {
  const [roles, setRoles] = useState([]);
  const [pageSize, setPageSize] = useState(20); // Default page size to 10
  const [rowCount, setRowCount] = useState(0);
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(false);
  const [sortModel, setSortModel] = useState([]);
  const [filterModel, setFilterModel] = useState({
    items: [],
  });
  const [selectedIds, setSelectedIds] = useState([]);
  const {ccGetError} = useError();

  const fetchRoles = useCallback(async () => {
    setLoading(true);
    try {
      const result = await axiosInstance.get("/roles", {
        params: {
          page: page + 1,
          pageSize,
          sortModel: JSON.stringify(sortModel),
          filterModel: JSON.stringify(filterModel),
        },
      });
      const rolesWithSrl = result.data.data.map((role, index) => ({
        ...role,
        srl: page * pageSize + index + 1,
      }));
      setRoles(rolesWithSrl);
      setRowCount(result.data.total);
    } catch (error) {
      console.error(error);
    }
    setLoading(false);
  }, [page, pageSize, sortModel, filterModel]);

  useEffect(() => {
    fetchRoles();
  }, [fetchRoles]);

  // const handleDelete = async (id) => {
  //   try {
  //     const result = await axiosInstance.delete(`/roles/${id}`);
  //     if(result.data.status === "success" ) {
  //       fetchRoles();
  //     }else {
  //       await ccGetError(result)
  //     }
  //   } catch (error) {
  //     await ccGetError(result)
  //   }
  // };

  const handleDelete = async (id) => {
    try {
      swalLoginRegisterAlert.fire({
        title: 'Are you sure?', 
        text: "You won't be able to revert this!", 
        confirmButtonText: "Yes, delete it!",
        icon: "warning",
        // iconColor: ccVar7Color,
        showCancelButton: true,
        color: ccVar7Color,
        // iconColor: ccVar5Color,
        confirmButtonColor: ccVar2Color,
        cancelButtonColor: ccVar7Color,
        background: ccBgVar1Color,
      }).then( async result => {
        if (result.isConfirmed) {
          const result = await axiosInstance.delete(`/roles/${id}`);
          if(result.data.status === "success" ) {
            fetchRoles();
            swalLoginRegisterAlert.fire({
              title: `Deleted ${wordsUpperCase(result.data.status)}!`, 
              text: result.data.message, 
              icon: "success",
              iconColor: ccVar2Color,
              color: ccVar7Color,
              confirmButtonColor: ccLargeFontColor,
              background: ccBgVar1Color,
              timer: 11500,
            })
          } else {
            await ccGetError(result)
          }
        }
      }) 
    } catch (error) {
      await ccGetError(error)
    }
  };

  const handleBulkDelete = async () => {
    try {
      swalLoginRegisterAlert.fire({
        title: 'Are you sure?', 
        text: "You won't be able to revert this!", 
        confirmButtonText: "Yes, delete it!",
        icon: "warning",
        // iconColor: ccVar7Color,
        showCancelButton: true,
        color: ccVar7Color,
        // iconColor: ccVar5Color,
        confirmButtonColor: ccVar2Color,
        cancelButtonColor: ccVar7Color,
        background: ccBgVar1Color,
      }).then( async result => {
        if (result.isConfirmed) {
          await Promise.all(selectedIds.map((id) => axiosInstance.delete(`/roles/${id}`)));

            setSelectedIds([]);
            fetchRoles();
            swalLoginRegisterAlert.fire({
              title: `Deleted Success!`, 
              text: 'Role(s) has been deleted', 
              icon: "success",
              iconColor: ccVar2Color,
              color: ccVar7Color,
              confirmButtonColor: ccLargeFontColor,
              background: ccBgVar1Color,
              timer: 11500,
            })

        }
      }) 
    } catch (error) {
      await ccGetError(error)
    }






    // try {
    //   await Promise.all(selectedIds.map((id) => axiosInstance.delete(`/roles/${id}`)));
    //   // selectedIds.map(async (id) => (
    //   //   await axiosInstance.delete(`/roles/${id}`)
    //   // ));
    //   setSelectedIds([]);
    //   fetchRoles();
    // } catch (error) {
    //   console.error(error);
    // }
  };

  // const columns = [
  //   { field: "srl", headerName: "SR", headerAlign: 'center', align: 'center', flex: 0.35, minWidth: 50, sortable: false, filterable: false },
  //   { field: "id", headerName: "ID", headerAlign: 'center', align: 'center', flex: 0.45, minWidth: 50, },
  //   { field: "title", headerName: "Title", headerAlign: 'center', flex: 1, minWidth: 50, editable: true },
  //   { field: "name", headerName: "Name", headerAlign: 'center', flex: 1, minWidth: 50, editable: true },
  //   { field: "status", headerName: "Status", headerAlign: 'center', align: 'center', flex: 0.6, minWidth: 50, editable: true },
  //   {
  //     field: "actions",
  //     headerName: "Actions",
  //     headerAlign: 'center',
  //     align: 'center',
  //     flex: 0.65,
  //     minWidth: 50,
  //     renderCell: (params) => (
  //       <>
  //         <IconButton
  //           component={Link}
  //           to={`/role/edit/${params.id}`}
  //           color="primary"
  //         >
  //           <EditIcon />
  //         </IconButton>
  //         <IconButton
  //           onClick={(event) => {
  //             event.stopPropagation(); // Prevents the row from being selected
  //             handleDelete(params.id);
  //           }}
  //           color="secondary"
  //         >
  //           <DeleteIcon />
  //         </IconButton>
  //       </>
  //     ),
  //   },
  // ];

  const columns = useMemo(() => [
    { field: "srl", headerName: "SR", headerAlign: 'center', align: 'center', flex: 0.35, minWidth: 50, sortable: false, filterable: false },
    { field: "id", headerName: "ID", headerAlign: 'center', align: 'center', flex: 0.45, minWidth: 50, },
    { field: "title", headerName: "Title", headerAlign: 'center', flex: 1, minWidth: 50, editable: true },
    { field: "name", headerName: "Name", headerAlign: 'center', flex: 1, minWidth: 50, editable: true },
    { field: "status", headerName: "Status", headerAlign: 'center', align: 'center', flex: 0.6, minWidth: 50, editable: true },
    {
      field: "actions",
      headerName: "Actions",
      headerAlign: 'center',
      align: 'center',
      flex: 0.65,
      minWidth: 50,
      renderCell: (params) => (
        <>
          <IconButton
            component={Link}
            to={`/role/edit/${params.id}`}
            color="primary"
          >
            <EditIcon />
          </IconButton>
          <IconButton
            onClick={(event) => {
              event.stopPropagation(); // Prevents the row from being selected
              handleDelete(params.id);
            }}
            color="secondary"
          >
            <DeleteIcon />
          </IconButton>
        </>
      ),
    },
  ], []);
  
  // Calculate the total height
  const rowHeight = 52;
  const headerHeight = 56;
  const footerHeight = 56;
  const calculatedHeight = 
  roles.length > 0 
    ? selectedIds.length > 0 
      ? (roles.length * rowHeight) + headerHeight + footerHeight + 53 
      : (roles.length * rowHeight) + headerHeight + footerHeight 
    : 200;

  return (
    <Stack 
      direction="column" 
      justifyContent="flex-start" 
      alignItems="flex-start" 
      spacing={{
        xs: ccVar1CommonGap,
        sm: ccVar1CommonGap,
        md: ccVar2CommonGap,
        xl: ccVar2CommonGap,
        lg: ccVar2CommonGap,
      }}
    >
      <Box
        display="flex"
        alignSelf="stretch"
      >
        <Box 
          height={calculatedHeight}
          width="100%"
        >
          {selectedIds.length > 0 && (
            <Button
              variant="contained"
              color="secondary"
              startIcon={<DeleteIcon />}
              onClick={handleBulkDelete}
              sx={{
                mb: 2,
                color: 'white',
                ":hover": {
                  backgroundColor: ccBgColor,
                },
              }}
            >
              Delete Selected
            </Button>
          )}
          <StripedStyledDataGrid
            rows={roles}
            columns={columns}
            pagination
            paginationMode="server"
            rowCount={rowCount}
            pageSize={pageSize}
            paginationModel={{ pageSize: pageSize, page: page }}
            pageSizeOptions={[5, 10, 15, 20, 100]}
            onPaginationModelChange={(newPaginationModel) => {
              setPage(newPaginationModel.page);
              setPageSize(newPaginationModel.pageSize);
            }}
            sortingMode="server"
            sortModel={sortModel}
            onSortModelChange={(model) => setSortModel(model)}
            filterMode="server"
            filterModel={filterModel}
            onFilterModelChange={(model) => setFilterModel(model)}
            loading={loading}
            getRowClassName={(params) =>
              params.indexRelativeToCurrentPage % 2 === 0 ? 'even' : 'odd'
            }
            checkboxSelection
            onRowSelectionModelChange={(newSelectionModel) => {
              setSelectedIds(newSelectionModel);
            }}
            disableSelectionOnClick
            autoHeight
          />
        </Box>
      </Box>
    </Stack>
  );
};

export default RoleList;

