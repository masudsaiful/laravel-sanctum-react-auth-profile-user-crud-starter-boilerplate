import { createBrowserRouter } from "react-router-dom";
import rootRouter from "router/services/routerService";
import {
  authRouter, 
  userRouter, 
  roleRouter
} from "router/services/routerService";




const router = createBrowserRouter([
  ...rootRouter,
  ...userRouter,
  ...roleRouter,
  ...authRouter,
]);

export default router;

