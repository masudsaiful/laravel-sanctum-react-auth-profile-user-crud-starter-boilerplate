// This will return by default '/'
// See the vite doc https://vitejs.dev/guide/env-and-mode.html
const baseUrl = import.meta.env.BASE_URL
export default baseUrl;